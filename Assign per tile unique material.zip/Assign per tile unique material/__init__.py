bl_info = {
    "name": "Process Per Tile Materials",
    "blender": (4, 2, 0),
    "category": "Export File",
    "author": "Tech Boy JaTiX",
    "version": (1, 1, 1),
    "description": "Assign per tile unique material",
}

import bpy

# Operator to execute the material processing and deletion
class PROCESS_OT_Materials(bpy.types.Operator):
    """Operator to process materials and delete those without '_1' in name"""
    bl_idname = "object.process_materials"
    bl_label = "Process Materials"
    
    def execute(self, context):
        # Call the material processing function
        process_materials()

        # Call the delete materials function
        delete_materials_without_1()

        return {'FINISHED'}


def get_uv_tile_count(obj):
    """Determine the number of UV tiles (UDIMs) used by the object."""
    uv_layer = obj.data.uv_layers.active
    uv_tiles = set()
    for poly in obj.data.polygons:
        for loop_index in poly.loop_indices:
            if loop_index < len(uv_layer.data):  # Check if UV data exists
                uv = uv_layer.data[loop_index].uv
                # Calculate the tile coordinates by flooring the UV coordinates
                tile_x = int(uv.x)
                tile_y = int(uv.y)
                uv_tiles.add((tile_x, tile_y))

    return uv_tiles  # Return the set of used tiles

def duplicate_material(material, count):
    """Duplicate the material multiple times, appending an incrementing suffix."""
    new_materials = []
    for i in range(count):
        new_mat = material.copy()
        new_mat.name = f"{material.name}_{1001 + i}"  # Start from 1001
        new_materials.append(new_mat)
    return new_materials


def process_materials():
    """Process all materials in the scene."""
    for material in bpy.data.materials:
        print(f"Processing material: {material.name}")
        
        # Add suffix to the material name
        original_name = material.name
        
        # Find all objects using the material
        linked_objects = [obj for obj in bpy.data.objects if obj.type == 'MESH' and any(slot.material == material for slot in obj.material_slots)]
        
        # Check UV Tiles Count
        if not linked_objects:
            print(f"No objects linked to {material.name}")
            continue

        # Assuming all linked objects have a similar UV tile structure
        uv_tiles_set = set()
        for obj in linked_objects:
            uv_tiles_set.update(get_uv_tile_count(obj))

        uv_tile_count = len(uv_tiles_set)
        print(f"UV tile count for material '{material.name}': {uv_tile_count}")
        
        if uv_tile_count < 2:
            print(f"Skipping material {material.name} as it doesn't have multiple UV tiles.")
            continue
        
        # Duplicate the material slots based on UV tile count
        duplicated_materials = duplicate_material(material, uv_tile_count)
        
        # Assign new materials to linked objects
        for obj in linked_objects:
            for i, new_mat in enumerate(duplicated_materials):
                if len(obj.material_slots) <= i:
                    obj.data.materials.append(new_mat)
                else:
                    obj.material_slots[i].material = new_mat
        
        # Assign representative materials to their UV tiles
        for obj in linked_objects:
            for poly in obj.data.polygons:
                uv = obj.data.uv_layers.active.data[poly.loop_start].uv
                uv_tile_index = int(uv.x) + int(uv.y) * uv_tile_count
                poly.material_index = uv_tile_index if uv_tile_index < len(obj.material_slots) else 0
        
        print(f"Processed material {original_name} successfully!")


def delete_materials_without_1():
    """Delete materials from the scene that don't contain '_1' in their name."""
    for material in bpy.data.materials:
        if "_1" not in material.name:
            print(f"Deleting material: {material.name}")
            bpy.data.materials.remove(material)


# Panel class for the materials panel
class VIEW3D_PT_Materials(bpy.types.Panel):
    """Panel for Material"""
    bl_label = "Materials"
    bl_idname = "VIEW3D_PT_Materials"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'JaTiX Tools'

    def draw(self, context):
        layout = self.layout

        # Add a button to process materials
        layout.operator("object.process_materials", text="Process Per Tile Materials", icon='NETWORK_DRIVE')

# Registering the operator and panel
def register():
    bpy.utils.register_class(PROCESS_OT_Materials)
    bpy.utils.register_class(VIEW3D_PT_Materials)

def unregister():
    bpy.utils.unregister_class(PROCESS_OT_Materials)
    bpy.utils.unregister_class(VIEW3D_PT_Materials)

if __name__ == "__main__":
    register()
