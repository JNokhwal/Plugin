"""
    Draw functions for the UI
"""
import bpy
import math


import gpu
from gpu_extras.batch import batch_for_shader

from . import operators
from bpy_extras.view3d_utils import location_3d_to_region_2d

# Global references to the draw handle and whether the handler is running.
_draw_handle = None
_is_running = False

def circle(x, y, radius, segments):
    '''create the coordinates for a circle'''
    coords = []
    m = (1.0 / (segments - 1)) * (math.pi * 2)

    for p in range(segments):
        p1 = x + math.cos(m * p) * radius
        p2 = y + math.sin(m * p) * radius
        coords.append((p1, p2))
    return coords

def draw_circle(position, radius, segments=32):
    """draw the 2d grid point"""
    gpu.state.line_width_set(1)

    try:
        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    except ValueError:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    
    circle_co = circle(position[0], position[1], radius, segments)
    batch_circle = batch_for_shader(shader, 'TRI_FAN', {'pos' : circle_co})

    return batch_circle, shader

def draw_line(start, end, line_width=1, circle_diameter=0):
    """draw a 2d line"""
    if not (start and end):
        return

    gpu.state.line_width_set(line_width)
    
    try:
        shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    except ValueError:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')

    vector = (start - end)
    vector.normalize()
    vertices = [start - (vector * circle_diameter), end + (vector * circle_diameter)]    
    batch = batch_for_shader(shader, 'LINES', {'pos' : vertices})
    
    return batch, shader

def calc_points_2D(context, point_3d):
    """Calculate the 2d location of a 3D point for the view"""

    # Check if we are in quad view
    if context.space_data.region_quadviews:
        regions = context.area.regions
        rv3ds = context.space_data.region_quadviews

        for i, rv3d in enumerate(rv3ds):
            # Calculate the 2D coordinates for each quad view
            region = [r for r in regions if r.type == 'WINDOW' and r.width > 5][i]
            if region == context.region:
                point_2d = location_3d_to_region_2d(region, rv3d, point_3d)
                # If the point is within the region, draw it
                return point_2d
    else:
        # Regular 3D view, single region
        region = context.region
        rv3d = context.region_data
        point_2d = location_3d_to_region_2d(region, rv3d, point_3d)
        return point_2d
    
    return None

def _draw_callback_2d(context):
    """Draw callback to visualize the source and possible destination of the flowify projection."""
    if operators._is_flowify_modal_running:

        flowify_ui = context.window_manager.flowify_ui

        # Get viewport dimensions
        viewport_width = context.area.width

        # Get standard visualisation parameters
        circle_radius = viewport_width / 350
        circle_segments = 32
        line_width = 1

        source_pos_2d = None
        # If we have a name for the source grid, we are almost there to visualising it all.
        if flowify_ui.source_grid_obj_name is not None:

            user_preferences = context.preferences
            addon_prefs = user_preferences.addons[__package__].preferences

            # first try to visualise the source grid corner point.
            try:
                source_obj = bpy.data.objects[flowify_ui.source_grid_obj_name]
                eval_depsgraph = context.evaluated_depsgraph_get()
                source_obj = source_obj.evaluated_get(eval_depsgraph)
                source_vertex_a = source_obj.data.vertices[flowify_ui.source_grid_obj_vertex_a_id]
            
                global_source_position = source_obj.matrix_world @ source_vertex_a.co
                source_pos_2d = calc_points_2D(context, global_source_position)

                # Draw a small circle at the source vertex position
                circle_batch, circle_shader = draw_circle(source_pos_2d, circle_radius, circle_segments)
                circle_shader.bind()
                circle_shader.uniform_float("color", addon_prefs.confirmed_corner_color) 
                circle_batch.draw(circle_shader)

            except KeyError:
                pass

            # If there was a possible corner locator draw it with a line from the source to the possible location point, if applicable.
            if flowify_ui.possible_grid_obj_name is not None and flowify_ui.possible_grid_obj_name != flowify_ui.source_grid_obj_name:
                try:
                    possible_obj = bpy.data.objects[flowify_ui.possible_grid_obj_name]
                    eval_depsgraph = context.evaluated_depsgraph_get()
                    possible_obj = possible_obj.evaluated_get(eval_depsgraph)
                    possible_vertex = possible_obj.data.vertices[flowify_ui.possible_grid_obj_vertex_a_id]

                    global_possible_position = possible_obj.matrix_world @ possible_vertex.co
                    possible_pos_2d = calc_points_2D(context, global_possible_position)

                    # Draw a small circle at the source vertex position
                    circle_batch, circle_shader = draw_circle(possible_pos_2d, circle_radius, circle_segments)
                    circle_shader.bind()
                    circle_shader.uniform_float("color", addon_prefs.possible_corner_color)
                    circle_batch.draw(circle_shader)

                    # If both source and possible are defined, draw a line between them
                    if source_pos_2d is not None:
                        line_batch, line_shader = draw_line(source_pos_2d, possible_pos_2d, line_width*2, circle_radius)
                        line_shader.bind()
                        line_shader.uniform_float("color", addon_prefs.main_line_color) 
                        line_batch.draw(line_shader)

                    # Draw dark green lines to the other parts of the target object.
                    possible_grid_obj_points = [flowify_ui.possible_grid_obj_vertex_b_id, flowify_ui.possible_grid_obj_vertex_c_id, flowify_ui.possible_grid_obj_vertex_d_id]
                    source_grid_obj_points = [flowify_ui.source_grid_obj_vertex_b_id, flowify_ui.source_grid_obj_vertex_c_id, flowify_ui.source_grid_obj_vertex_d_id]

                    i = 0
                    # go through all point pairs to draw a line between them.
                    for possible_gird_obj_point in possible_grid_obj_points:
                        source_grid_obj_point = source_grid_obj_points[i]

                        if possible_gird_obj_point>= 0 and \
                            source_grid_obj_point >= 0:

                            possible_vertex_b = possible_obj.data.vertices[possible_gird_obj_point]
                            global_possible_position = possible_obj.matrix_world @ possible_vertex_b.co
                            possible_pos_2d = calc_points_2D(context, global_possible_position)

                            source_vertex_b = source_obj.data.vertices[source_grid_obj_point]
                        
                            global_source_position = source_obj.matrix_world @ source_vertex_b.co
                            source_pos_2d = calc_points_2D(context, global_source_position)

                            line_batch, line_shader = draw_line(source_pos_2d, possible_pos_2d, line_width, 0)
                            line_shader.bind()
                            line_shader.uniform_float("color", addon_prefs.supporting_line_color) 
                            line_batch.draw(line_shader)

                        i+=1


                except KeyError:
                    pass

def register(context):
    global _is_running
    if not _is_running:
        global _draw_handle
        global _draw_callback_2d
        _draw_handle = bpy.types.SpaceView3D.draw_handler_add(_draw_callback_2d, (context,), 'WINDOW', 'POST_PIXEL')
        _is_running = True


def unregister():
    global _is_running
    if _is_running:
        global _draw_handle
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, 'WINDOW')
        _is_running = False
