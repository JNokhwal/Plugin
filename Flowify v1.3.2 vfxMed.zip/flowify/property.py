"""
    Properties that drive the addon.
"""
import bpy
from bpy.utils import register_class, unregister_class


class FlowifyUI(bpy.types.PropertyGroup):
    """Visualisation parameters to drive the UI, set by the Flowify Operator"""
    
    # Possible name and corner vertex id of a grid object under mouse.
    possible_grid_obj_name : bpy.props.StringProperty()
    possible_grid_obj_vertex_a_id : bpy.props.IntProperty()
    possible_grid_obj_vertex_b_id : bpy.props.IntProperty()
    possible_grid_obj_vertex_c_id : bpy.props.IntProperty()
    possible_grid_obj_vertex_d_id : bpy.props.IntProperty()

    # source grid name and corner vertex id if registered by the add-on.
    source_grid_obj_name : bpy.props.StringProperty()
    source_grid_obj_vertex_a_id : bpy.props.IntProperty(default=-1)    
    source_grid_obj_vertex_b_id : bpy.props.IntProperty(default=-1)    
    source_grid_obj_vertex_c_id : bpy.props.IntProperty(default=-1)    
    source_grid_obj_vertex_d_id : bpy.props.IntProperty(default=-1)    

classes = [FlowifyUI]

def register():
    for cls in classes:
        register_class(cls)

    bpy.types.WindowManager.flowify_ui = bpy.props.PointerProperty(type=FlowifyUI)

def unregister():
    del bpy.types.WindowManager.flowify_ui

    for cls in classes:
        unregister_class(cls)