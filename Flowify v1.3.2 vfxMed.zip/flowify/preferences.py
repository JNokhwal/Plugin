"""
    User driven preferences.
"""
import bpy
from bpy.types import AddonPreferences
from bpy.props import FloatVectorProperty, IntProperty, BoolProperty
import os
from bpy.utils import register_class, unregister_class
import numpy as np


def addon_name():
    return __package__

class FlowifyPreferences(AddonPreferences):
    """Custom preferences and associated UI for add on properties."""
    # this must match the addon name, use '__package__'
    # when defining this in a submodule of a python package.
    bl_idname = addon_name()

    display_face_orientation : BoolProperty(
        name = "Display Face Orientaton",
        description="Display Face Orientation whilst using add-on",
        default=True)
    
    delete_old : BoolProperty(
        name = "Delete Old Flowify Object",
        description="Delete any existing Flowify Objects with the same name when running the add-on",
        default=False)
    
    move_objects_to_collection : BoolProperty(
        name = "Move Original Objects to Collection",
        description="Move original objects to a flowify collection for management",
        default=False)
    
    subdivide_source_grid : bpy.props.BoolProperty(
        name= "Subdivide Source Grid",
        description= "Automatically subdivide the Source Grid when running Flowify",
        default = True
    )
    
    possible_corner_color : FloatVectorProperty(name="Possible Corner Color", 
                                        description="The color to be used when hovering over a possible corner",
                                        subtype='COLOR', 
                                        default=[1.0, 1.0, 0.0, 1.0],
                                        size=4,
                                        min=0,
                                        max=1)
    
    confirmed_corner_color : FloatVectorProperty(name="Confirmed Corner Color", 
                                        description="When a corner has been confirmed the color will change to this",
                                        subtype='COLOR', 
                                        default=[0.0, 1.0, 0.0, 1.0],
                                        size=4,
                                        min=0,
                                        max=1)
    
    main_line_color : FloatVectorProperty(name="Main Line Color", 
                                        description="The color of the main line used for matching corners",
                                        subtype='COLOR', 
                                        default=[0.0, 1.0, 0.0, 1.0],
                                        size=4,
                                        min=0,
                                        max=1)
    
    supporting_line_color : FloatVectorProperty(name="Supporting Line Color", 
                                        description="The color of the supporting lines between the other matching corners",
                                        subtype='COLOR', 
                                        default=[1.0, 0.0, .7, 1.0],
                                        size=4,
                                        min=0,
                                        max=1)



    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.prop(self, 'display_face_orientation')
        col.prop(self, 'subdivide_source_grid')
        col.prop(self, 'delete_old')
        col.prop(self, 'move_objects_to_collection')
        col.separator()
        col.prop(self, 'possible_corner_color')
        col.prop(self, 'confirmed_corner_color')
        col.prop(self, 'main_line_color')
        col.prop(self, 'supporting_line_color')


    
classes = [
    FlowifyPreferences]


def register():
    for cls in classes:
        register_class(cls)


def unregister():
    for cls in classes:
        unregister_class(cls)