"""
    Main Flowify Blender Operator
"""

import bpy
from bpy.utils import register_class, unregister_class
import bmesh
import os
from mathutils import Vector
from bpy_extras.mesh_utils import edge_loops_from_edges

from . import util

# Static references to the blender file and required node group within it.
_blend_file = 'flowify.blend'
_modifier_name = "Flowify Nodes v1.1.0"

# Whether or not the modal is running or not, useful for the draw function.
_is_flowify_modal_running = False
class OBJECT_OT_Flowify(bpy.types.Operator):
    """Map an object to any quad surface with four corners"""
    bl_idname = "object.flowify"
    bl_label = "Flowify Modal Operator"
    bl_description = "Run Flowify using a Source Object with a reference Grid to map onto the Target Surface grid"
    bl_options = {'UNDO'}



    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.step = 0
        self.source_objects = []
        self.source_grid = None
        self.source_grid_vertex_a = None
        self.target_grid = None
        self.target_grid_vertex_a = None
        self.row_edges = []
        self.num_col_edges = 0
        self.valid_verts = []
        self.target_grid_type = None
        self.status_message = "Pick a corner on the flat Source Grid..."
        global _is_flowify_modal_running
        _is_flowify_modal_running = True
        self.old_orientation = False
        self.obj_check_cache = {}

    def __del__(self):
        global _is_flowify_modal_running
        _is_flowify_modal_running = False

    @classmethod
    def poll(cls, context):
        # Return False if any object is in edit mode
        return not any(obj.mode == 'EDIT' for obj in bpy.data.objects)

    def modal(self, context, event):

        if event.type in {'RIGHTMOUSE', 'ESC'} or any(obj.mode == 'EDIT' for obj in bpy.data.objects):
            context.workspace.status_text_set(None)
            self.exit_modal(context)
            self.report({'INFO'}, "FLOWIFY: Cancelled")
            return {'CANCELLED'}

        context.workspace.status_text_set('FLOWIFY: ' + self.status_message + ' ESC: Cancel')

        flowify_ui = context.window_manager.flowify_ui

        # Determine which type of check function we should perform for the object under the mouse.
        grid_check_func = None
        if self.step == 0:
            def grid_check_func(context, obj):
                if obj in self.source_objects:
                    return False
                is_flat_grid = util.is_flat_grid(context, obj)
                target_grid_type = 'GRID' if is_flat_grid else None
                return target_grid_type
        elif self.step == 1:
            def grid_check_func(context, obj):
                if obj == self.source_grid or \
                    obj in self.source_objects:
                    return False
                is_grid = util.is_grid(context, obj)
                target_grid_type = None
                if is_grid:
                    target_grid_type = 'GRID'
                elif util.is_cylinder_shape(context, obj):
                    target_grid_type =  'CYLINDER'
                return target_grid_type

        # determine of there is a valid object under the mouse we can do calculations on for Flowify.
        grid_under_mouse = None
        nearest_vertex_id = None
        self.target_grid_type = None
        objs_to_hide_map = {}
        try:
            objs_to_hide = list(set(self.source_objects + [self.source_grid, self.target_grid]))
            # objs_to_hide = []
            for o in objs_to_hide:
                if o:
                    objs_to_hide_map[o] = (o.hide_get(), o.select_get())
                    o.hide_set(True)
            result, location, _, _, obj, _ = util.get_object_under_mouse(context, event)
        finally:
            for o, (hide, select) in objs_to_hide_map.items():
                o.hide_set(hide)
                o.select_set(select)

        if result:
            # Get the grid type from the cache if we can.
            if obj in self.obj_check_cache:
                grid_type = self.obj_check_cache[obj]
            else:
                grid_type = grid_check_func(context, obj)
                self.obj_check_cache[obj] = grid_type
            if grid_type:
                eval_depsgraph = context.evaluated_depsgraph_get()
                eval_obj = obj.evaluated_get(eval_depsgraph)

                # Now we have the object, create a bmesh and find the neared corner vertex if to return.
                bm = bmesh.new()
                bm.from_mesh(eval_obj.data)
                try:
                    bm.transform(eval_obj.matrix_world)

                    # get only valid vertex indexes to look through from the original base mesh
                    bm_orig = bmesh.new()
                    bm_orig.from_mesh(obj.data)
                    valid_vert_idxs = []
                    try:
                        if grid_type == 'GRID':
                            valid_vert_idxs = [v.index for v in bm_orig.verts if len(v.link_edges) == 2]
                        else: # Cylinder case.
                            valid_vert_idxs = [v.index for v in bm_orig.verts if len(v.link_edges) == 3]
                    finally:
                        bm_orig.free()

                    bm.verts.ensure_lookup_table()
                    corner_verts = []
                    for valid_vert_index in valid_vert_idxs:
                        try:
                            corner_verts.append(bm.verts[valid_vert_index])
                        except IndexError:
                            continue

                    if corner_verts:
                        nearest_vertex = min(corner_verts, key=lambda v: (location - v.co).magnitude)
                        if nearest_vertex:
                            nearest_index = nearest_vertex.index
                            grid_under_mouse = obj
                            nearest_vertex_id = nearest_index
                            self.target_grid_type = grid_type
                finally:
                    bm.free()

        if grid_under_mouse:
            # Determine cursor cisualisation based on the step we are at.
            if self.step == 0:
                context.window.cursor_set('PAINT_CROSS')
            elif self.step == 1:
                context.window.cursor_set('CROSSHAIR')

            # Flag this potential object as a possible candidate for a grid object we can use for Flowify.
            flowify_ui.possible_grid_obj_name = grid_under_mouse.name
            flowify_ui.possible_grid_obj_vertex_a_id = nearest_vertex_id

            if self.step == 1:
                # get the second part of the grid for drawing a guideline to it.
                flowify_ui.source_grid_obj_vertex_b_id = util.get_next_side_corner_vertex(self.source_grid, self.source_grid_vertex_a)
                flowify_ui.source_grid_obj_vertex_c_id = util.get_next_side_corner_vertex(self.source_grid, flowify_ui.source_grid_obj_vertex_b_id)
                flowify_ui.source_grid_obj_vertex_d_id = util.get_next_side_corner_vertex(self.source_grid, flowify_ui.source_grid_obj_vertex_c_id)

                # Set up target grid possible locations.
                if self.target_grid_type == 'GRID':
                    # If a grid, we need to get the next side corner vertex
                    flowify_ui.possible_grid_obj_vertex_b_id = util.get_next_side_corner_vertex(grid_under_mouse, nearest_vertex_id)
                    flowify_ui.possible_grid_obj_vertex_c_id = util.get_next_side_corner_vertex(grid_under_mouse, flowify_ui.possible_grid_obj_vertex_b_id )
                    flowify_ui.possible_grid_obj_vertex_d_id = util.get_next_side_corner_vertex(grid_under_mouse, flowify_ui.possible_grid_obj_vertex_c_id )
                else:
                    # if it is a cylindrical case, find the downward vertex from the border ring to identidy the second position
                    # for UV Map generation.
                    flowify_ui.possible_grid_obj_vertex_b_id = util.get_next_side_cylinder_vertex(grid_under_mouse, nearest_vertex_id)
                    flowify_ui.possible_grid_obj_vertex_c_id = flowify_ui.possible_grid_obj_vertex_b_id
                    flowify_ui.possible_grid_obj_vertex_d_id = nearest_vertex_id

            context.area.tag_redraw()

            # if the user has actually clicked, check if we can register this grid object for Flowify processing.
            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                if self.step == 0:  # Select source grid stage
                    grid_under_mouse.select_set(True)
                    context.view_layer.objects.active = grid_under_mouse

                    # register the required variables for flowify.
                    self.source_grid_vertex_a = nearest_vertex_id
                    self.source_grid = grid_under_mouse
                    self.step = 1
                    self.obj_check_cache = {}
                    self.status_message = "Pick a corner on the Target Surface..."
                    flowify_ui.source_grid_obj_name = grid_under_mouse.name
                    flowify_ui.source_grid_obj_vertex_a_id = nearest_vertex_id
                    return {'RUNNING_MODAL'}
                elif self.step == 1:  # Select target grid stage
                    if flowify_ui.possible_grid_obj_vertex_b_id < 0:
                        self.report({'ERROR'}, "Could not find second Target Grid corner vertex.")
                        return {'CANCELLED'}

                    # set the grid as the active selected object for the user.
                    grid_under_mouse.select_set(True)
                    context.view_layer.objects.active = grid_under_mouse

                    # register the required variables for flowify and then execute flowify because we should have everything we need.
                    self.target_grid_vertex_a = nearest_vertex_id
                    self.target_grid = grid_under_mouse

                    # set up the required variables for processing, depending on the target grid type
                    if self.target_grid_type == 'GRID':
                        # get the side row edges for processing
                        self.row_edges = util.get_edge_loop(self.target_grid, self.target_grid_vertex_a, flowify_ui.possible_grid_obj_vertex_b_id)
                        if not self.row_edges:
                            self.report({'ERROR'}, "Could not find a valid path for the target vertex.")
                            return {'CANCELLED'}
                        # calculate the number of column vertices
                        num_col_vertices = int(len(self.target_grid.data.vertices) / (len(self.row_edges) + 1))
                        
                        self.num_col_edges = num_col_vertices - 1
                        self.exit_modal(context)
                        self.execute(context)
                        return {'FINISHED'}

                    else:
                        # get the number row edges from the user chosen vertex
                        self.row_edges = util.get_edge_loop(self.target_grid, self.target_grid_vertex_a, flowify_ui.possible_grid_obj_vertex_b_id)
                        if not self.row_edges:
                            self.report({'ERROR'}, "Could not find a valid path for the target vertex.")
                            return {'CANCELLED'}
                        self.num_col_edges = int(len(self.target_grid.data.vertices) / (len(self.row_edges) + 1))

                        self.exit_modal(context)
                        self.execute(context)
                        return {'FINISHED'}

                
        else:
            # if there was nothing under the mouse reset the view as per usual and pass through to support wider viewport operations.
            context.window.cursor_set('DEFAULT')
            flowify_ui.possible_grid_obj_name = ''
            flowify_ui.possible_grid_obj_vertex_a_id = -1
            flowify_ui.possible_grid_obj_vertex_b_id = -1
            flowify_ui.possible_grid_obj_vertex_c_id = -1
            flowify_ui.possible_grid_obj_vertex_d_id = -1
            context.area.tag_redraw()
            return {'PASS_THROUGH'}
        return {'PASS_THROUGH'}
    
    def reset_draw(self, context):
        """Reset any draw ui variables for flowify"""
        flowify_ui = context.window_manager.flowify_ui
        flowify_ui.possible_grid_obj_name = ''
        flowify_ui.possible_grid_obj_vertex_a_id = -1
        flowify_ui.possible_grid_obj_vertex_b_id = -1
        flowify_ui.possible_grid_obj_vertex_c_id = -1
        flowify_ui.possible_grid_obj_vertex_d_id = -1
        flowify_ui.source_grid_obj_name = ''
        flowify_ui.source_grid_obj_vertex_a_id = -1
        flowify_ui.source_grid_obj_vertex_b_id = -1
        flowify_ui.source_grid_obj_vertex_c_id = -1
        flowify_ui.source_grid_obj_vertex_d_id = -1

    def exit_modal(self, context):
        """Cleanly exit this modal operator"""
        context.window.cursor_set('DEFAULT')
        global _is_flowify_modal_running
        _is_flowify_modal_running = False
        user_preferences = context.preferences
        addon_prefs = user_preferences.addons[__package__].preferences
        if addon_prefs.display_face_orientation:
            context.space_data.overlay.show_face_orientation = self.old_orientation
        self.reset_draw(context)
        context.area.tag_redraw()
        context.workspace.status_text_set(None)


    def execute(self, context):
        # Execute the flowify operation.

        # Get the source and target grids, and the source objects
        source_objects = self.source_objects
        source_grid = self.source_grid
        target_grid = self.target_grid

        #
        # SOURCE GRID PROCESSING: Determine "Corner A" and "Corner B" so that geometry nodes can orientate the grid and the source object for mapping, and subdivide to reflect Target Grid.
        #


        source_grid_vertex_b = util.get_next_side_corner_vertex(self.source_grid, self.source_grid_vertex_a)

        if not source_grid_vertex_b >= 0:
            self.report({'ERROR'}, "Could not find second Source Grid corner vertex.")
            return {'CANCELLED'}

        # Get preferences for configuring behaviour
        user_preferences = context.preferences
        addon_prefs = user_preferences.addons[__package__].preferences


        # get the selected edges, which is our starting row for mapping, and calculate dimensions for calculations
        num_rows = len(self.row_edges) - 1

        # calculate number of columns based on the row edges
        num_cols = self.num_col_edges - 1
            
        # Create a BMesh from the source object to analyise the mesh
        if addon_prefs.subdivide_source_grid:
            mesh = source_grid.data
            source_grid_bm = bmesh.new()
            try:
                source_grid_bm.from_mesh(mesh)

                # Collect all non-corner vertices
                source_grid_bm.verts.ensure_lookup_table()
                vertices_to_dissolve = [v for v in source_grid_bm.verts if len(v.link_edges) != 2]

                # Dissolve these vertices if needed as we will be recalculating the grid for them.
                bmesh.ops.dissolve_verts(source_grid_bm, verts=vertices_to_dissolve)

                # Find the edge with both line_a_target_grid_index and line_b_target_grid_index so we can subdivide the grid in the correct manner.
                edge_with_neither = [e for e in source_grid_bm.edges if set([v.index for v in e.verts]) == set([self.source_grid_vertex_a, source_grid_vertex_b]) or len([v.index for v in e.verts if v.index in [self.source_grid_vertex_a, source_grid_vertex_b]]) == 0]

                # Find the edge with neither line_a_target_grid_index nor line_b_target_grid_index so we can subdivide the other part in the correct manner.
                edge_with_both = [e for e in source_grid_bm.edges if e not in edge_with_neither]

                # Subdivide the edges for the source grid.
                result = bmesh.ops.subdivide_edges(source_grid_bm, edges=edge_with_both, cuts=num_cols)

                # go through the result so we get the correct edges to subdivide the other way.
                for e in result['geom_inner']:
                    if isinstance(e, bmesh.types.BMEdge):
                        edge_with_neither.append(e)

                bmesh.ops.subdivide_edges(source_grid_bm, edges=edge_with_neither, cuts=num_rows)

                # Update & Free BMesh
                source_grid_bm.to_mesh(source_grid.data)
            finally:
                source_grid_bm.free()
        
        #
        # SOURCE OBJECT PROCESSING: For each Source Object, create a new object with the Geometry nodes set up that maps a source object to a target grid using a UV Map on the target grid.
        #

        # Load the node group if it is not already loaded.
        global _blend_file
        file_path = os.path.join(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'resources'), _blend_file)
        
        with bpy.data.libraries.load(file_path) as (data_from, data_to):
            data_to.node_groups = [ng for ng in data_from.node_groups if ng not in bpy.data.node_groups]

        # reset any selection so we can present to the user a set of selected results for each source object.
        for selected_object in context.selected_objects:
            selected_object.select_set(False)



        new_objs = []

        # start setting up variables for UV Map.
        x_inc = 1 / (num_cols + 1) 
        y_inc = 1 / (num_rows + 1)

        for source_object in source_objects:

            # Assign relevant vertex groups to the source grid.
            try:
                checked_verts_vg_name_a = "Flowify Group A: " + source_object.name + '-' + target_grid.name
                if checked_verts_vg_name_a not in source_grid.vertex_groups:
                     vg = source_grid.vertex_groups.new(name=checked_verts_vg_name_a)
                     checked_verts_vg_name_a = vg.name
                checked_verts_vg_A = source_grid.vertex_groups[checked_verts_vg_name_a]

                checked_verts_vg_name_b = "Flowify Group B: " + source_object.name + '-' + target_grid.name
                if checked_verts_vg_name_b not in source_grid.vertex_groups:
                    vg = source_grid.vertex_groups.new(name=checked_verts_vg_name_b)
                    checked_verts_vg_name_b = vg.name
                checked_verts_vg_B = source_grid.vertex_groups[checked_verts_vg_name_b]
            except ReferenceError:
                continue

            # assign the correct weights to denote the corner vertices for Geometry Nodes to process.
            checked_verts_vg_A.add([self.source_grid_vertex_a], 1.0, 'ADD')
            checked_verts_vg_B.add([source_grid_vertex_b], 1.0, 'ADD')

            #
            # TARGET GRID PROCESSING: Determine Grid Dimensions so that the Source Grid can be matched to it.
            #

            row_vertex_indices = []

            # Create a BMesh from the target object to analyise the mesh
            mesh = target_grid.data
            target_grid_bm = bmesh.new()
            target_grid_bm.from_mesh(mesh)
            try:
                # Check if there's a Flowify specfic UV map, if not create one
                uv_map_name = "Flowify UV Map: " + source_object.name
                if uv_map_name not in target_grid_bm.loops.layers.uv:
                    target_grid_bm.loops.layers.uv.new(uv_map_name)
                uv_layer = target_grid_bm.loops.layers.uv[uv_map_name]
                uv_layer_name = uv_layer.name
                    
                # Now we will assign a uniform UV grid like map to the target grid so the source object can be properly mapped.
                y_coord = 1
                # Go down the row of edges and for each 'right hand' face, assign uv coords.
                # and then go across from the face using loops to assign the other x coordinates.
                target_grid_bm.verts.ensure_lookup_table()
                target_grid_bm.edges.ensure_lookup_table()
                v = target_grid_bm.verts[self.target_grid_vertex_a]

                for e_index in self.row_edges:
                    e = target_grid_bm.edges[e_index]
                    
                    # get first loop.
                    for loop in [l for l in e.link_loops if l.vert == v]:
                        x_coord = 0
                        x_inc = 1

                        next_loop = loop
                        all_loops = []
                        face_count = 0
                        
                        # go along and assign each of the face loops UV coordinates.
                        while next_loop:
                            next_loop[uv_layer].uv.x = x_coord
                            next_loop[uv_layer].uv.y = y_coord
                            next_loop.tag = True

                            loop_bottom = next_loop.link_loop_next
                            loop_bottom[uv_layer].uv.x = x_coord
                            loop_bottom[uv_layer].uv.y = y_coord - y_inc
                            loop_bottom.tag = True

                            side_loop = loop_bottom.link_loop_next
                            side_loop[uv_layer].uv.x = x_coord + x_inc
                            side_loop[uv_layer].uv.y = y_coord - y_inc
                            side_loop.tag = True

                            loop_top = side_loop.link_loop_next
                            loop_top[uv_layer].uv.x = x_coord + x_inc
                            loop_top[uv_layer].uv.y = y_coord
                            loop_top.tag = True

                            all_loops.append(next_loop)
                            all_loops.append(loop_bottom)
                            all_loops.append(side_loop)
                            all_loops.append(loop_top)

                            # check whether we are at the end, which is either at a border edge
                            # or back where we started.
                            if side_loop.link_loop_radial_next != side_loop and \
                                not side_loop.link_loop_radial_next.tag:
                                next_loop = side_loop.link_loop_radial_next
                            else:
                                next_loop = None
                            
                            x_coord += x_inc
                            face_count+=1

                        for all_loop in all_loops:
                            # re-adjust the x coordinate based on what we know about the face count.
                            all_loop[uv_layer].uv.x = all_loop[uv_layer].uv.x / face_count
                            # reset loop tagging if we need to assign furthe UV Maps.
                            all_loop.tag = False
                    y_coord -= y_inc
                    v = e.other_vert(v)
                    row_vertex_indices.extend([v.index for v in e.verts])

            finally:
                # assign UV Maps to the data of the grid object so we save the UV Map.
                target_grid_bm.to_mesh(target_grid.data)
                target_grid_bm.free()

            # add a Vertex group along the side vertices for use in the node group for merging vertices, 
            # useful in cylindrical cases
            row_vertex_indices = list(set(row_vertex_indices))
            side_vertex_group_name = "Flowify Side Vertices: " + source_object.name
            if side_vertex_group_name not in target_grid.vertex_groups:
                 vg = target_grid.vertex_groups.new(name=side_vertex_group_name)
                 side_vertex_group_name = vg.name
            side_vertex_group = target_grid.vertex_groups[side_vertex_group_name]
            side_vertex_group.add(row_vertex_indices, 1.0, 'ADD')
                
            new_obj_name = source_object.name + ' Flowify'

            # delete any matching objects from previous operations to keep the scene clean
            if addon_prefs.delete_old and new_obj_name in bpy.data.objects:
                obj = bpy.data.objects[new_obj_name]
                old_data = obj.data
                bpy.data.objects.remove(obj, do_unlink=True)  # Unlink and delete the object
                # Check and delete the mesh data if it is no longer used by any other objects
                if old_data and old_data.users == 0:
                    bpy.data.meshes.remove(old_data)

            # Create the object that will be the result of the Source Object -> Target Object mapping.
            mesh = bpy.data.meshes.new(new_obj_name)
            new_obj = bpy.data.objects.new(new_obj_name, mesh)
            collection = source_object.users_collection[0] if len(source_object.users_collection) else context.collection
            collection.objects.link(new_obj)

            # TODO if we can invert the matrix in Geo Nodes in the future, we may be able to set the matrix of the object here.
            # new_obj.matrix_world = target_grid.matrix_world.copy()
            # For the moment, just changing the location appears to pass testing.
            new_obj.location = target_grid.location.copy()

            # Copy over the colour for matching visualisation
            new_obj.color = source_object.color

            # add the geometry nodes modifier that actually does the mapping of Source Object -> Target Surface
            mod = new_obj.modifiers.new(name='Flowify', type='NODES')

            # Get the node group that was loaded earlier to assign it to the modifier.
            global _modifier_name
            mod.node_group = bpy.data.node_groups[_modifier_name]
            
            # Map relevant parameters to drive the node group now we have them.
            identifier= util.get_identifier(mod, "Source Object")
            mod[identifier] = source_object

            identifier= util.get_identifier(mod, "Source Grid Object")
            mod[identifier] = source_grid

            identifier= util.get_identifier(mod, "Target Surface")
            mod[identifier] = target_grid

            identifier= util.get_identifier(mod, "UV Map")
            mod[identifier] = uv_layer_name

            identifier= util.get_identifier(mod, "Flowify Corner Group A")
            mod[identifier] = checked_verts_vg_A.name

            identifier= util.get_identifier(mod, "Flowify Corner Group B")
            mod[identifier] = checked_verts_vg_B.name

            identifier= util.get_identifier(mod, "Side Group")
            mod[identifier] = side_vertex_group.name

            # Always assign the last created object to be the active one.
            context.view_layer.objects.active = new_obj

            # Make the object selected to show the result to the user.
            new_obj.select_set(True)

            new_objs.append(new_obj)


        # show the wire to the user for reference purposes.
        source_grid.show_wire = True



        # Move original objects to collection, if needed
        if addon_prefs.move_objects_to_collection:
            current_collection = context.view_layer.active_layer_collection.collection
            collection_name = self.source_objects[0].name + " Flowify Objects" if self.source_objects else current_collection.name + " Flowify Objects"
            util.move_objects_to_collection(self.source_objects + [self.source_grid] + [self.target_grid], current_collection, collection_name)

        context.view_layer.update()

        # Check for any objects that are empty to report potential errors.
        for new_obj in new_objs:
            eval_depsgraph = context.evaluated_depsgraph_get()
            eval_obj = new_obj.evaluated_get(eval_depsgraph)
            if not len(eval_obj.data.vertices):
                self.report({'ERROR'}, "Flowify Object is empty. \nPlease check Source and Target objects for any modifiers that may have invalidated the underlying grid. The modifiers may need to be applied.")


        self.report({'INFO'}, "Flowify operation executed.")

        return {'FINISHED'}

    def invoke(self, context, event):
        # We need selected objects to assign them to source objects, so check we have some.
        if not context.selected_objects:
            self.report({'ERROR'}, "Select source object(s).")
            return {'CANCELLED'}

        # set the modal step counter to zero so we first select the source and then the target grid.
        self.step = 0

        # optionally set face orientation visualisation so the user can check they have the right face orientation for the add-on.
        user_preferences = context.preferences
        addon_prefs = user_preferences.addons[__package__].preferences
        if addon_prefs.display_face_orientation:
            self.old_orientation = context.space_data.overlay.show_face_orientation
            context.space_data.overlay.show_face_orientation = True

        # Reset the UI parameters for the add-on.
        self.reset_draw(context)

        # assign the modal handler so the modal method can run for processing.
        context.window_manager.modal_handler_add(self)

        # assign the source objects for processing by flowify.
        self.source_objects = context.selected_objects
            
        # flag that the modal is running for visualisation.
        global _is_flowify_modal_running
        _is_flowify_modal_running = True
        return {'RUNNING_MODAL'}


class OBJECT_OT_create_source_grid(bpy.types.Operator):
    """Create a Source Grid from a selected Target Surface"""
    bl_idname = "object.flowify_create_source_grid"
    bl_label = "Create Custom Plane"
    bl_options = {'REGISTER', 'UNDO'}

    width_type : bpy.props.EnumProperty(name="Width Type",
                                        description = "Type of calculation used to determine width of grid.",
                                        items= (('MAX', 'Max', 'Max Side Width'),
                                                ('AVERAGE', 'Average', 'Average Width'),
                                                ('MIN', 'Min', 'Min side Width')), default="MAX")


    length_type : bpy.props.EnumProperty(name="Length Type", 
                                        description = "Type of calculation used to determine length of grid.",
                                        items= (('MAX', 'Max', 'Max Side Width'),
                                                ('AVERAGE', 'Average', 'Average Width'),
                                                ('MIN', 'Min', 'Min side Width')), default="MAX")

    location : bpy.props.FloatVectorProperty(
            name="Location",
            description="Offset Location",
            subtype='TRANSLATION'
            )
    rotation : bpy.props.FloatVectorProperty(
            name="Rotation",
            description="Offset Rotation",
            subtype='EULER'
            )
    scale : bpy.props.FloatVectorProperty(
            name="Scale",
            description="Offset Scale",
            subtype='XYZ',
            default=[1,1,1],
            step=1
            )
    
    def draw(self, context):
        """Layout the operator options"""
        layout = self.layout

        col = layout.column()
        col.label(text="Dimensions")
        box = col.box()
        box.label(text="Width")
        box.row(align=True).prop(self, 'width_type', expand=True)
        box.label(text="Length")
        box.row(align=True).prop(self, 'length_type', expand=True)
        box = col.box()
        box.label(text="Offset Translation")
        box.prop(self, 'location')
        box.prop(self, 'rotation')
        box.prop(self, 'scale')



    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):

        if not ((util.is_grid(context, context.active_object)) or \
                                          util.is_cylinder_shape(context, context.active_object)):
            self.report({'ERROR'}, "This is not a valid grid shaped target surface.")
            return {'CANCELLED'}


        target_surface = context.active_object

        target_surface_bm = bmesh.new()
        eval_depsgraph = context.evaluated_depsgraph_get()
        eval_obj = target_surface.evaluated_get(eval_depsgraph)
        target_surface_bm.from_mesh(eval_obj.data)
        target_surface_bm.transform(eval_obj.matrix_world)

        average_direction_vector = Vector((0,0,0))
        try:

            target_surface_bm.verts.ensure_lookup_table()
            target_surface_bm.edges.ensure_lookup_table()

            corner_verts = []
            if util.is_grid(context, context.active_object):
                corner_verts = [v for v in target_surface_bm.verts if len(v.link_faces) == 1]

                # pick first corner vertex we see and then continue round the loop
                # these four corners are picked so we can use them as the basis of the measurements.
                corner_a = corner_verts[0]
                loop = corner_a.link_loops[0] # this will be the first 'left' edge
                corner_b = target_surface_bm.verts[util.get_end_vertex(loop)]
                loop = corner_b.link_loops[0]
                corner_c = target_surface_bm.verts[util.get_end_vertex(loop)]
                loop = corner_c.link_loops[0]
                corner_d = target_surface_bm.verts[util.get_end_vertex(loop)]

                # Get the rough direction vector going through the 'middle' of the corners.
                dir_vec_1 = (corner_d.co - corner_a.co).normalized()
                dir_vec_2 = (corner_c.co - corner_b.co).normalized()

                average_direction_vector = ((dir_vec_1 + dir_vec_2) / 2).normalized()
                average_direction_vector = util.closest_axis_to_vector_xy(average_direction_vector)

                # First look at the 'side' edges.  Traverse the relevant side to get a starting set of edges.
                side_edge_indexes = util.get_edge_loop(eval_obj, corner_c.index, corner_d.index)
                side_edges = [target_surface_bm.edges[e] for e in side_edge_indexes]
                side_verts = []
                for e in side_edges:
                    side_verts.extend(e.verts)
                side_verts = list(set(side_verts))
                all_edge_lengths = []
                # go through the side vertices and get edge loops across the grid for each one.
                for v in side_verts:
                    try:
                        loop = [l for l in v.link_loops if l.edge.other_vert(v) not in side_verts][0]
                        end_vertex_index = util.get_end_vertex(loop)
                        edge_loop = util.get_edge_loop(eval_obj, v.index, end_vertex_index)
                    except IndexError:
                        # This error occurs because one of the corner vertices will be going in the opposite direction.
                        # therefore, get the side in the direction of these loops.
                        if v.index == corner_c.index:
                            edge_loop = util.get_edge_loop(eval_obj, corner_b.index, corner_c.index)
                        else:
                            raise IndexError("Unexpected vertex on target surface.")
                    edges = [target_surface_bm.edges[e] for e in edge_loop]
                    edge_length = sum([e.calc_length() for e in edges])
                    all_edge_lengths.append(edge_length)
                
                # Now we can determine sizes for the dimensions of the grid.
                width_segments = len(side_edges) - 1
                width_av = sum(all_edge_lengths) / len(all_edge_lengths)
                width_max = max(all_edge_lengths)
                width_min = min(all_edge_lengths)

                # Repeat the process for the top edges.
                top_edge_indexes = util.get_edge_loop(eval_obj, corner_d.index, corner_a.index)
                top_edges = [target_surface_bm.edges[e] for e in top_edge_indexes]
                top_verts = []
                for e in top_edges:
                    top_verts.extend(e.verts)
                top_verts = list(set(top_verts))
                all_edge_lengths = []
                for v in top_verts:
                    try:
                        loop = [l for l in v.link_loops if l.edge.other_vert(v) not in top_verts][0]
                        end_vertex_index = util.get_end_vertex(loop)
                        edge_loop = util.get_edge_loop(eval_obj, v.index, end_vertex_index)
                    except IndexError:
                        if v.index == corner_d.index:
                            edge_loop = util.get_edge_loop(eval_obj, corner_c.index, corner_d.index)
                        else:
                            raise IndexError("Unexpected vertex on target surface.")
                    edges = [target_surface_bm.edges[e] for e in edge_loop]
                    edge_length = sum([e.calc_length() for e in edges])
                    all_edge_lengths.append(edge_length)

                length_segments = len(top_edges) - 1
                length_av = sum(all_edge_lengths) / len(all_edge_lengths)
                length_max = max(all_edge_lengths)
                length_min = min(all_edge_lengths)


            else: # cylinder case
                # find all boundary edges so we can derive the edge loops.
                data_edges = []
                for e in target_surface_bm.edges:
                    if e.is_boundary:
                        data_edges.append(eval_obj.data.edges[e.index])

                edge_loops = edge_loops_from_edges(eval_obj.data, data_edges)
                if len(edge_loops) == 2:

                    # now go along one of these border edge loops (the tops of the cylinder) and get all the profile loops to measure.
                    side_edge_lengths = []
                    all_side_edges = []
                    edge_loop_length = 0

                    for vertex_index in edge_loops[0]:
                        loop = [l for l in target_surface_bm.verts[vertex_index].link_loops if len(l.edge.link_faces) == 2][0]
                        end_vertex_index = util.get_end_vertex(loop)
                        edges = util.get_edge_loop(eval_obj, vertex_index, end_vertex_index)
                        edges = [target_surface_bm.edges[e] for e in edges]
                        all_side_edges.append(edges)
                        side_edge_lengths.append(sum([e.calc_length() for e in edges]))
                        edge_loop_length = len(edges)

                    length_segments = edge_loop_length - 1
                    width_av = sum(side_edge_lengths) / len(side_edge_lengths)
                    width_min = min(side_edge_lengths)
                    width_max = max(side_edge_lengths)

                    # now find all edge loops we have not covered by going 'around' the cylinder.
                    all_circle_edges = []
                    top_edge_lengths = []
                    edge_loop_length = 0
                    if all_side_edges:
                        first_side_loop = all_side_edges[0]
                        all_verts = list(set([v for e in first_side_loop for v in e.verts]))
                        for v in all_verts:
                            edges = util.get_edge_loop(eval_obj, v.index, v.index)
                            edges = [target_surface_bm.edges[e] for e in edges]
                            all_circle_edges.append(edges)
                            top_edge_lengths.append(sum([e.calc_length() for e in edges]))
                            edge_loop_length = len(edges)
                    
                    width_segments = edge_loop_length - 1
                    length_av = sum(top_edge_lengths) / len(top_edge_lengths)
                    length_min = min(top_edge_lengths)
                    length_max = max(top_edge_lengths)

            # find width
            if self.width_type == 'AVERAGE':
                width = width_av
            elif self.width_type == 'MAX':
                width = width_max
            elif self.width_type == 'MIN':
                width = width_min

            # find length
            if self.length_type == 'AVERAGE':
                length = length_av
            elif self.length_type == 'MAX':
                length = length_max
            elif self.length_type == 'MIN':
                length = length_min

            # get the thickness of the surface for offsetting the grid location.
            all_verts_x = [(v.co).x for v in target_surface_bm.verts]
            all_verts_y = [(v.co).y for v in target_surface_bm.verts]
            all_verts_z = [(v.co).z for v in target_surface_bm.verts]

            min_x_pos = min(all_verts_x)
            max_x_pos = max(all_verts_x)

            min_y_pos = min(all_verts_y)
            max_y_pos = max(all_verts_y)

            min_z_pos = min(all_verts_z)
            max_z_pos = max(all_verts_z)
        finally:
            target_surface_bm.free()

        # Create the object that will be the result of the Source Object -> Target Object mapping.
        new_obj_name = target_surface.name + " Source Grid"
        mesh = bpy.data.meshes.new(new_obj_name)
        new_obj = bpy.data.objects.new(new_obj_name, mesh)

        collection = target_surface.users_collection[0] if len(target_surface.users_collection) else context.collection
        collection.objects.link(new_obj)

        # Now we can create the object.
        mesh = new_obj.data
        source_grid_bm = bmesh.new()
        source_grid_bm.from_mesh(mesh)
        try:
            bmesh.ops.create_grid(source_grid_bm, x_segments=0, y_segments=0, size=1)

            # Subdivide across and down
            bmesh.ops.subdivide_edges(source_grid_bm, 
                                    edges=[e for e in source_grid_bm.edges if abs(e.verts[0].co.y - e.verts[1].co.y) < 0.01],
                                    cuts=length_segments)

            bmesh.ops.subdivide_edges(source_grid_bm, 
                                    edges=[e for e in source_grid_bm.edges if abs(e.verts[0].co.x - e.verts[1].co.x) < 0.01],
                                    cuts=width_segments)
        finally:
            source_grid_bm.to_mesh(new_obj.data)
            source_grid_bm.free()


        for o in context.selected_objects:
            o.select_set(False)
        new_obj.select_set(True)
        context.view_layer.update()

        context.view_layer.objects.active = new_obj

        # Scale the plane
        new_obj.scale.x = width / 2  # Plane is 2x2 by default
        new_obj.scale.y = length / 2  # Plane is 2x2 by default



        # Apply the scale transformation
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        #if we have an vector we need to align to along the target surface perform the alignment so it looks aligned as possible to the target surface.
        if average_direction_vector.length:
            rotation_difference = Vector((1,0,0)).rotation_difference(average_direction_vector)
            # this would be the opposite of rotation, to get back to the original object.
            old_rotation_mode = new_obj.rotation_mode
            new_obj.rotation_mode = 'QUATERNION'
            new_obj.rotation_quaternion.rotate(rotation_difference.conjugated())
            new_obj.rotation_mode = old_rotation_mode
            context.view_layer.update()


        # Add offset translation.
        new_obj.location = Vector(((max_x_pos + min_x_pos)/2, (max_y_pos + min_y_pos)/2, max_z_pos * 1.3)) + self.location
        new_obj.rotation_euler.rotate(self.rotation)
        new_obj.scale = new_obj.scale * self.scale

        new_obj.show_wire = True

        # Finally make sure the layer is updated so the user can see the results.
        context.view_layer.update()

        return {'FINISHED'}

    
class OBJECT_MT_flowify(bpy.types.Menu):
    bl_idname = 'OBJECT_MT_flowify'
    bl_label = 'Flowify'

    @classmethod
    def poll(cls, context):
        # Return False if any object is in edit mode
        return context.active_object and context.active_object.mode == 'OBJECT'

    def draw(self, context):
        col = self.layout.column()
        col.operator_context = 'INVOKE_DEFAULT'
        col.operator(OBJECT_OT_Flowify.bl_idname,  text="Flowify", icon='EVENT_F')
        col.operator(OBJECT_OT_create_source_grid.bl_idname, text="Create Source Grid from Target Surface", icon='SNAP_GRID')
        # col.operator(OBJECT_OT_even_surface.bl_idname, text="Even Surface", icon='SNAP_GRID') #TODO Re-implement when more robust

def menu_quick_func(self, context):
    self.layout.menu(OBJECT_MT_flowify.bl_idname,icon='EVENT_F', text="" )

def menu_func(self, context):
    """The Menu option to execute Flowify"""
    self.layout.menu(OBJECT_MT_flowify.bl_idname)


classes = [OBJECT_OT_Flowify, OBJECT_OT_create_source_grid, OBJECT_MT_flowify]


def register():
    global classes
    for cls in classes:
        register_class(cls)

    bpy.types.VIEW3D_MT_object_context_menu.append(menu_func)

    bpy.types.VIEW3D_MT_editor_menus.append(menu_quick_func)


def unregister():
    bpy.types.VIEW3D_MT_editor_menus.remove(menu_quick_func)
    bpy.types.VIEW3D_MT_object_context_menu.remove(menu_func)


    global classes
    for cls in classes:
        unregister_class(cls)
