import bpy
import bmesh 
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d
from bpy_extras.mesh_utils import edge_loops_from_edges
import math
import mathutils
from mathutils import Vector
from collections import deque

def is_grid(context, obj):
    """Efficiently determine if this object appears to be a quad grid shape."""
    if obj.type != 'MESH':
        return False

    eval_depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(eval_depsgraph)

    # Create a bmesh from the object's mesh data
    bm = bmesh.new()
    bm.from_mesh(eval_obj.data)
    try:

        # Count vertices with exactly 2 linked edges
        corner_vertices_count = 0
        for v in bm.verts:
            if len(v.link_edges) == 2:
                corner_vertices_count += 1
                if corner_vertices_count > 4:
                    # We are over the limit
                    break

        # Update the cache and return the result
        is_valid = corner_vertices_count == 4
    finally:
        # Clean up the bmesh
        bm.free()
    
    return is_valid

def is_flat_grid(context, obj):
    """
    Checks if the given object looks like a flat grid object.
    """
    # Ensure the object is a mesh
    if obj.type != 'MESH':
        return False
        
    if not is_grid(context, obj):
        return False
    eval_depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(eval_depsgraph)

    bm = bmesh.new()
    bm.from_mesh(eval_obj.data)
    try:

        # To check if the mesh is flat, compare the normal of the first face with others
        bm.faces.ensure_lookup_table()
        if bm.faces:
            first_normal = bm.faces[0].normal
            for face in bm.faces[1:]:
                # Using a dot product to compare normals. If they're aligned, the dot product should be near 1.
                # A small tolerance (e.g., 1e-6) is used to handle minor numerical inaccuracies.
                if math.isclose(first_normal.dot(face.normal), 1, rel_tol=1e-6) == False:
                    return False
    finally:
        bm.free()
    return True

def is_cylinder_shape(context, obj):
    """
    Check if the given object is a cylinder shape.
    Criteria: All quads, circular edge loops at top and bottom, no n-gons.

    :param obj: The object to check.
    :return: True if the object is a cylinder shape, False otherwise.
    """
    # Ensure the object is a mesh
    if obj.type != 'MESH':
        return False
    
    eval_depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(eval_depsgraph)

    # Create a bmesh from the object mesh
    bm = bmesh.new()
    bm.from_mesh(eval_obj.data)
    try:

        # Check for all quads first
        if any(len(f.edges) != 4 for f in bm.faces):
            return False

        # Check for all quads first
        if any(len(v.link_edges) == 2 for v in bm.verts):
            return False

        # Find top and bottom edge loops
        data_edges = []
        for e in bm.edges:
            if e.is_boundary:
                data_edges.append(eval_obj.data.edges[e.index])
        
        edge_loops = edge_loops_from_edges(eval_obj.data, data_edges)

        if len(edge_loops) != 2:
            return False

        # Check if edge loops are circular (equal number of edges)
        if len(edge_loops[0]) != len(edge_loops[1]):
            return False
        
        for edge_loop in edge_loops:
            if edge_loop[0] != edge_loop[-1]:
                return False
    finally:
        bm.free()
    return True

def get_identifier(mod, input_key):
    """
    Returns the identifier for a given input key from a node group.

    :param mod: The modifier with a reference to the node group.
    :param input_key: The key to fetch the identifier for.
    :return: The identifier for the given key.
    """
    if hasattr(mod.node_group, 'inputs'):
        return mod.node_group.inputs[input_key].identifier
    else:
        return mod.node_group.interface.items_tree[input_key].identifier
    



def get_object_under_mouse(context, event):
    """Check to see if there is a grid looking object under the mouse, if so return it with the id of the nearest corner vertex."""

    #get information about the viewing region.
    region, adjusted_mouse_x, adjusted_mouse_y, space, i = get_quadview_index(context, event.mouse_x, event.mouse_y)
    rv3d = None
    if space is not None:
        if i is None:
            rv3d = space.region_3d
        else:
            rv3d = space.region_quadviews[i]

    if not rv3d:
        return None, None, None, None, None, None
    
    mouse_pos = adjusted_mouse_x, adjusted_mouse_y

    # Do a ray cast from the viewport and see if we hit an object.
    ray_origin = region_2d_to_origin_3d(region, rv3d, mouse_pos)
    view_vector = region_2d_to_vector_3d(region, rv3d, mouse_pos)

    eval_depsgraph = context.evaluated_depsgraph_get()
    return context.scene.ray_cast(eval_depsgraph, ray_origin, view_vector)


def get_quadview_index(context, x, y):
    '''Get the index of a quad view based on supplied coordinates'''
    for area in context.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        is_quadview = len(area.spaces.active.region_quadviews) == 0
        i = -1
        for region in area.regions:
            if region.type == 'WINDOW':
                i += 1
                if (x >= region.x and
                    y >= region.y and
                    x < region.width + region.x and
                    y < region.height + region.y):

                    # This adjustment accounts for the mouse position relative to the region
                    adjusted_mouse_x = x - region.x
                    adjusted_mouse_y = y - region.y

                    return (region, adjusted_mouse_x, adjusted_mouse_y, area.spaces.active, None if is_quadview else i)
    return (None, None, None, None, None)


def move_objects_to_collection(objs, parent_collection, collection_name):
    """
    Move objects to a specified collection.

    :param obj_names: A list of names of the objects to be moved.
    :context: The blender context to use.
    :param collection_name: The name of the collection to move the objects to.
    """

    # Get the collection, create it if it does not exist
    if collection_name not in bpy.data.collections:
        new_collection = bpy.data.collections.new(collection_name)
        parent_collection.children.link(new_collection)
    else:
        new_collection = bpy.data.collections[collection_name]

    # Move each object to the new collection
    for obj in objs:
        # Unlink from all collections it's currently in
        for coll in obj.users_collection:
            coll.objects.unlink(obj)
        # Link to the new collection
        new_collection.objects.link(obj)

def get_edge_loop(obj, vertex_a_index, vertex_b_index):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        start_vertex = bm.verts[vertex_a_index]

        all_loops = []
        for l in start_vertex.link_loops:                            
            next_loop = l
            edges = []
            while next_loop:
                next_loop.tag = True
                all_loops.append(next_loop)
                edges.append(next_loop.edge.index)
                if vertex_b_index == next_loop.edge.other_vert(next_loop.vert).index:
                    for l in all_loops:
                        l.tag = False
                    return edges
                if next_loop.link_loop_next.link_loop_radial_next != next_loop.link_loop_next and \
                    not next_loop.link_loop_next.link_loop_radial_next.link_loop_next.tag:
                    next_loop = next_loop.link_loop_next.link_loop_radial_next.link_loop_next
                else:
                    next_loop = None
        
        for l in all_loops:
            l.tag = False
    finally:
        bm.free()
    return []


def get_end_vertex(start_loop):
   
    next_loop = start_loop
    edges = []
    verts = []
    all_loops = []
    while next_loop:
        next_loop.tag = True
        all_loops.append(next_loop)
        edges.append(next_loop.edge)
        verts.append(next_loop.vert)
        if next_loop.link_loop_next.link_loop_radial_next != next_loop.link_loop_next and \
            not next_loop.link_loop_next.link_loop_radial_next.link_loop_next.tag:
            next_loop = next_loop.link_loop_next.link_loop_radial_next.link_loop_next
        else:
            next_loop = None

    for l in all_loops:
        l.tag = False
    
    vert_index = -1
    if edges and verts:
        vert_index = edges[-1].other_vert(verts[-1]).index
    return vert_index

def get_next_side_corner_vertex(obj, vertex_a_index):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    try:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        start_vertex = bm.verts[vertex_a_index]

        l = [l for l in start_vertex.link_loops][0]

        vert_index = get_end_vertex(l)
    finally:
        bm.free()
    return vert_index

def get_next_side_cylinder_vertex(obj, vertex_a_index):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    try:
        bm.verts.ensure_lookup_table()
        l = [l for l in bm.verts[vertex_a_index].link_loops if len(l.edge.link_faces) == 2][0]
        vert_index = get_end_vertex(l)
        return vert_index
    finally:
        bm.free()

def align_longest_length(context, obj_to_rotate, reference_obj):
    """
    Rotates 'obj_to_rotate' in 90-degree increments around the Z-axis until its longest
    length is parallel to the longest length of 'reference_obj'.

    :param obj_to_rotate: The object to rotate (bpy.types.Object).
    :param reference_obj: The reference object (bpy.types.Object).

    """
    old_active  = context.view_layer.objects.active
    context.view_layer.objects.active = obj_to_rotate
    ref_dimensions = reference_obj.dimensions
    ref_dimensions = [r for r in ref_dimensions]
    ref_longest_length = max(ref_dimensions)
    ref_longest_length_index = ref_dimensions.index(ref_longest_length)

    # Initial dimensions of the object to rotate
    rot_dimensions = obj_to_rotate.dimensions
    rot_dimensions = [r for r in rot_dimensions]

    # Function to check if the longest dimensions are aligned
    def is_aligned(rot_dims, ref_length_index):
        max_value = max(rot_dims)
        max_ref_obj_index = rot_dims.index(max_value)
        return max_ref_obj_index == ref_length_index

    # Rotate and check alignment
    for _ in range(4):
        if is_aligned(rot_dimensions, ref_longest_length_index):
            break
        obj_to_rotate.rotation_euler[2] += math.radians(90)
        context.view_layer.update()
        rot_dimensions = obj_to_rotate.dimensions
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
        rot_dimensions = [r for r in rot_dimensions]

    context.view_layer.objects.active = old_active


def resample_edge_ring(bm, edge_ring, num_verts, start_vert=None):
    """
    Resamples an edge ring to have a specified number of vertices while maintaining the shape.

    :param bm: The BMesh object.
    :param edge_ring: A list of BMEdge objects representing the edge ring.
    :param num_verts: The desired number of vertices in the edge ring.
    """
    inner_verts = []
    for e in edge_ring:
        inner_verts.extend(e.verts)
    inner_verts = list(set(inner_verts))


    # First, order the edge_ring.
    def order_edge_ring(edge_ring, start_vertex = None):
        ordered_edges = []

        if not start_vertex:
            all_verts = []
            for e in edge_ring:
                all_verts.extend(e.verts)
            all_verts = list(set(all_verts))

            current_vertex = None
            for v in all_verts:
                if current_vertex:
                    break
                for e in v.link_edges:
                    if e.is_boundary and e not in edge_ring:
                        current_vertex = v

            first_vert = current_vertex
        else:
            current_vertex = start_vertex
            first_vert = current_vertex

        
        while len(ordered_edges) < len(edge_ring):
            for edge in current_vertex.link_edges:
                if edge in edge_ring and edge not in ordered_edges:
                    ordered_edges.append(edge)
                    current_vertex = edge.other_vert(current_vertex)
                    break
        return ordered_edges, first_vert
    
    if not start_vert:
        ordered_edge_ring, first_vert = order_edge_ring(edge_ring)
    else:
        ordered_edge_ring, first_vert = order_edge_ring(edge_ring, start_vert)

    # Calculate the total length of the edge ring.
    total_length = sum(e.calc_length() for e in ordered_edge_ring)

    num_cuts = num_verts + 1

    # Determine the step size for interpolation.
    step_size = total_length / num_cuts

    # Calculate the interpolated positions.
    positions = []

    current_edge_index = 0
    current_edge = ordered_edge_ring[current_edge_index]
    current_edge_length = current_edge.calc_length()
    current_vertex = first_vert
    length_up_to_current_edge = 0  # Cumulative length up to (but not including) the current edge
    
    for i in range(1, num_cuts):

        target_length = i * step_size  # The length along the edge ring where we want to place this position

        # If the target length for this position exceeds the cumulative length up to and including this edge, move to the next edge.
        while target_length > length_up_to_current_edge + current_edge_length and current_edge_index < len(ordered_edge_ring) - 1:
            length_up_to_current_edge += current_edge_length
            current_vertex = current_edge.other_vert(current_vertex)

            current_edge_index += 1
            current_edge = ordered_edge_ring[current_edge_index]
            current_edge_length = current_edge.calc_length()

        # Now, interpolate along the current edge to get the position.
        length_on_current_edge = target_length - length_up_to_current_edge
        factor = length_on_current_edge / current_edge_length
        pos = current_vertex.co.lerp(current_edge.other_vert(current_vertex).co, factor)
        positions.append(pos)

    current_vertex = first_vert
    i = 0
    for e in ordered_edge_ring[:-1]:
        other_vert = e.other_vert(current_vertex)
        print('Repositioning: ', other_vert.index)
        print('from: ', other_vert.co)
        print('to: ', positions[i])
        other_vert.co = positions[i]
        print('now at: ', other_vert.co)
        current_vertex  = other_vert
        i+=1

    bm.normal_update()



def closest_axis_to_vector_xy(direction_vector):
    """
    Find the closest axis (X or Y) to a given direction vector, excluding the Z axis.

    Parameters:
    - direction_vector: A mathutils Vector representing the direction.

    Returns:
    - Vector: A unit vector representing the closest axis (X or Y).
    """
    # Absolute values of the X and Y components of the vector
    abs_x, abs_y = abs(direction_vector.x), abs(direction_vector.y)
    
    # Compare only X and Y to find the closest axis
    if abs_x > abs_y:
        # Closest to X-axis
        return Vector((1, 0, 0))
    else:
        # Closest to Y-axis
        return Vector((0, 1, 0))