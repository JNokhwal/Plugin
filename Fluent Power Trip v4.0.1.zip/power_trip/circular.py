from ..Tools.helper import *
from ..Tools.constants import *
from bpy.types import Operator


class FLUENT_OT_CircularCutStarter(Operator):
    """Cylinder for special workflow
Hold Shift : Fold/Unfold
Hold Ctrl : Activate/Deactivate the "Fix Border" option in the knife2 modifier. This option fixes the shading issue where the two ends meet caused by boolean addition protruding beyond the right&left edges of the unfolded cylinder. This option slows the viewport"""
    bl_idname = "fluent.circularcutstarter"
    bl_label = "Folding cylinder"

    def invoke(self, context, event):
        if event.shift:
            for obj in context.selected_objects:
                fold_circular_object(obj, not is_fold_circular_object(obj))
            return {'FINISHED'}
        if event.ctrl:
            obj = context.active_object
            if obj and obj.get('fluent_type') != 'circular':
                return {'FINISHED'}
            for m in obj.modifiers:
                if m.name == fluent_modifiers_name['knife2'] and m.type == 'NODES':
                    m['Socket_10'] = not m['Socket_10']
                    m.show_viewport = False
                    m.show_viewport = True
                    return {'FINISHED'}
        bpy.ops.fluent.cutter('INVOKE_DEFAULT', operation='CIRCULAR_CUT')
        return {'FINISHED'}