def draw_callback_px(self, context):
    self.ui_management.global_ui_drawing()
