






bl_info = {
    "name": "NOISY-CUTTER",
    "author": "Pictofilmo",
    "version": (0, 1, 8),
    "blender": (4, 2, 0),
    "location": "3D View > FRACTURE",
    "description": "NOISY-CUTTER",
    "warning": "",
    "category": "Object",
}


import bpy
import os
import math
import mathutils
import bmesh
from mathutils import Matrix

from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       FloatProperty,
                       FloatVectorProperty,
                       EnumProperty,
                       PointerProperty,
                       )
from bpy.types import (Panel,
                       Menu,
                       Operator,
                       PropertyGroup,
                       )


# ------------------------------------------------------------------------
#    Scene Properties
# ------------------------------------------------------------------------
def get_material_items(self, context):
    # Generate EnumProperty items based on current materials in the scene
    return [(mat.name, mat.name, "") for mat in bpy.data.materials]    
    
class MyProperties(PropertyGroup):
    my_enum:EnumProperty(
        items=get_material_items,
        name="",
        description="Choose a material from the scene.",
    )
        

    my_string: StringProperty(
        name="",
        description="Cut material name",
        default="NOISY_CUTTER-inside_mat",
        maxlen=1024,
        )

    # Noise setiings ###
    my_noiz: FloatProperty(
        name = "Strength",
        description = "Displacement Strength",
        default = 0.5,
        min = -10,
        max = 10
        )
    my_scal: FloatProperty(
        name = "Scale",
        description = "Noise scale",
        default = 4,
        min = 0,
        max = 200
        )
    my_ndep: IntProperty(
        name = "Levels",
        description = "Noise depth level",
        default = 2,
        min = 0,
        max = 4
        )
    ###################    
        
    my_dens: IntProperty(
        name = "Mesh Density",
        description = "Grid density",
        default = 96,
        min = 10,
        max = 2048,
        )
    my_dep: FloatProperty(
        name = "Length",
        description = "CUTTER extrusion lenght",
        default = 3,
        min = 0.1,
        max = 1500
        )
    my_dep2: FloatProperty(
        name = "Location",
        description = "CUTTER location",
        default = 0,
        min = -1500,
        max = 1500
        )
        
    my_boo: BoolProperty(
        name="Advanced Boolean",
        description="Faster but unstable. Can be use for simple low resolution cut",
        default = True
        ) 


    my_del: BoolProperty(
        name="Delete Cutter after operation",
        description="Delete used mesh after the operation",
        default = True
        )        
    my_del2: BoolProperty(
        name="Delete Spline",
        description="Delete spline after Mesh Cutter creation",
        default = True
        )
#    my_tex: BoolProperty(
#        name="Texture:",
#        description="Use texture instead of noise",
#        default = False
#        )
    my_path : StringProperty(
        name="",
        description="Path to texture",
        default="",
        maxlen=1024,
        subtype='FILE_PATH')

    my_mix: FloatProperty(
        name = "Noise/Texture",
        description = "Mix Noise and Texture",
        default = 0,
        min = 0,
        max = 1
        )  
        
                
    my_disp: FloatProperty(
        name = "Strength",
        description = "Displacement Strength",
        default = 1,
        min = -150,
        max = 150
        )    
        
    my_angl: BoolProperty(
        name="Rotate 90°",
        description="Rotate texture 90°",
        default = False
        )
    my_rot: FloatProperty(
        name = "Rotation",
        description = "texture rotation",
        default = 0,
        min = 0,
        max = 360
        )
        
    
    my_scale2: FloatProperty(
        name = "Scale",
        description = "texture scale",
        default = 1,
        min = 0,
        max = 50
        )



# ------------------------------------------------------------------------
#    FONCTIONS
# ------------------------------------------------------------------------

def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

    
def value_driver(ob,feed):
    #ex: value_driver(bck1.inputs[1],'prop.col2power')
    drc = ob.driver_add("default_value")
    drc.driver.expression = 'var'
    var = drc.driver.variables.new()
    var.name='var'
    var.type='SINGLE_PROP'
    var.targets[0].id_type = 'SCENE'
    var.targets[0].id = bpy.context.scene
    var.targets[0].data_path=feed  
    return


#initialize NC_cutternodes node group
#initialize NC_cutternodes node group
#initialize nc_cutternodes node group
#initialize nc_cutternodes node group
def nc_cutternodes_node_group():
    nc_cutternodes = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "NC_cutternodes")

    nc_cutternodes.is_modifier = True
    
    #initialize nc_cutternodes nodes
    #nc_cutternodes interface
    #Socket Geometry
    geometry_socket = nc_cutternodes.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'
    
    #Socket MyUV
    myuv_socket = nc_cutternodes.interface.new_socket(name = "MyUV", in_out='OUTPUT', socket_type = 'NodeSocketVector')
    myuv_socket.subtype = 'NONE'
    myuv_socket.default_value = (0.0, 0.0, 0.0)
    myuv_socket.min_value = -3.4028234663852886e+38
    myuv_socket.max_value = 3.4028234663852886e+38
    myuv_socket.attribute_domain = 'POINT'
    
    #Socket Geometry
    geometry_socket_1 = nc_cutternodes.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'
    
    
    #node Group Input
    group_input = nc_cutternodes.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    
    #node Group Output
    group_output = nc_cutternodes.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True
    
    #node Set Spline Cyclic
    set_spline_cyclic = nc_cutternodes.nodes.new("GeometryNodeSetSplineCyclic")
    set_spline_cyclic.name = "Set Spline Cyclic"
    #Selection
    set_spline_cyclic.inputs[1].default_value = True
    #Cyclic
    set_spline_cyclic.inputs[2].default_value = False
    
    #node Capture Attribute
    capture_attribute = nc_cutternodes.nodes.new("GeometryNodeCaptureAttribute")
    capture_attribute.name = "Capture Attribute"
    #capture_attribute.data_type = 'FLOAT'
    capture_attribute.domain = 'POINT'
    
    #node Spline Parameter
    spline_parameter = nc_cutternodes.nodes.new("GeometryNodeSplineParameter")
    spline_parameter.name = "Spline Parameter"
    
    #node Curve Length
    curve_length = nc_cutternodes.nodes.new("GeometryNodeCurveLength")
    curve_length.name = "Curve Length"
    
    #node Math
    math = nc_cutternodes.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'DIVIDE'
    math.use_clamp = False
    #Value_002
    math.inputs[2].default_value = 0.5
    
    #node Value
    value = nc_cutternodes.nodes.new("ShaderNodeValue")
    value.name = "Value"
    value.use_custom_color = True
    value.color = (0.0, 1.0, 0.09229516983032227)
    
    value.outputs[0].default_value = 32.0
    #node Combine XYZ
    combine_xyz = nc_cutternodes.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz.name = "Combine XYZ"
    #X
    combine_xyz.inputs[0].default_value = 0.0
    #Y
    combine_xyz.inputs[1].default_value = 0.0
    
    #node Value.001
    value_001 = nc_cutternodes.nodes.new("ShaderNodeValue")
    value_001.name = "Value.001"
    value_001.use_custom_color = True
    value_001.color = (0.0, 0.9999715685844421, 0.09228704124689102)
    
    value_001.outputs[0].default_value = 2.010000467300415
    #node Value.002
    value_002 = nc_cutternodes.nodes.new("ShaderNodeValue")
    value_002.name = "Value.002"
    value_002.use_custom_color = True
    value_002.color = (0.0, 0.9999715685844421, 0.09228704124689102)
    
    value_002.outputs[0].default_value = -0.35999998450279236
    #node Curve Line
    curve_line = nc_cutternodes.nodes.new("GeometryNodeCurvePrimitiveLine")
    curve_line.name = "Curve Line"
    curve_line.mode = 'DIRECTION'
    #End
    curve_line.inputs[1].default_value = (0.0, 0.0, 1.0)
    
    #node Combine XYZ.001
    combine_xyz_001 = nc_cutternodes.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz_001.name = "Combine XYZ.001"
    #X
    combine_xyz_001.inputs[0].default_value = 0.0
    #Y
    combine_xyz_001.inputs[1].default_value = 0.0
    
    #node Resample Curve
    resample_curve = nc_cutternodes.nodes.new("GeometryNodeResampleCurve")
    resample_curve.name = "Resample Curve"
    resample_curve.mode = 'COUNT'
    #Selection
    resample_curve.inputs[1].default_value = True
    #Length
    resample_curve.inputs[3].default_value = 0.10000000149011612
    
    #node Curve to Mesh
    curve_to_mesh = nc_cutternodes.nodes.new("GeometryNodeCurveToMesh")
    curve_to_mesh.name = "Curve to Mesh"
    #Fill Caps
    curve_to_mesh.inputs[2].default_value = False
    
    #node Extrude Mesh
    extrude_mesh = nc_cutternodes.nodes.new("GeometryNodeExtrudeMesh")
    extrude_mesh.name = "Extrude Mesh"
    extrude_mesh.mode = 'EDGES'
    #Selection
    extrude_mesh.inputs[1].default_value = True
    #Individual
    extrude_mesh.inputs[4].default_value = False
    
    #node Vector
    vector = nc_cutternodes.nodes.new("FunctionNodeInputVector")
    vector.name = "Vector"
    vector.vector = (0.0, 0.0, 1.0)
    
    #node Reroute
    reroute = nc_cutternodes.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    #node Resample Curve.001
    resample_curve_001 = nc_cutternodes.nodes.new("GeometryNodeResampleCurve")
    resample_curve_001.name = "Resample Curve.001"
    resample_curve_001.mode = 'LENGTH'
    #Selection
    resample_curve_001.inputs[1].default_value = True
    #Count
    resample_curve_001.inputs[2].default_value = 10
    
    #node Capture Attribute.002
    capture_attribute_002 = nc_cutternodes.nodes.new("GeometryNodeCaptureAttribute")
    capture_attribute_002.name = "Capture Attribute.002"
    #capture_attribute_002.data_type = 'FLOAT'
    capture_attribute_002.domain = 'POINT'
    
    #node Curve to Mesh.001
    curve_to_mesh_001 = nc_cutternodes.nodes.new("GeometryNodeCurveToMesh")
    curve_to_mesh_001.name = "Curve to Mesh.001"
    #Fill Caps
    curve_to_mesh_001.inputs[2].default_value = False
    
    #node Mesh to Points
    mesh_to_points = nc_cutternodes.nodes.new("GeometryNodeMeshToPoints")
    mesh_to_points.name = "Mesh to Points"
    mesh_to_points.mode = 'VERTICES'
    #Selection
    mesh_to_points.inputs[1].default_value = True
    #Position
    mesh_to_points.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Radius
    mesh_to_points.inputs[3].default_value = 0.0
    
    #node Instance on Points
    instance_on_points = nc_cutternodes.nodes.new("GeometryNodeInstanceOnPoints")
    instance_on_points.name = "Instance on Points"
    #Selection
    instance_on_points.inputs[1].default_value = True
    #Pick Instance
    instance_on_points.inputs[3].default_value = False
    #Instance Index
    instance_on_points.inputs[4].default_value = 0
    #Rotation
    instance_on_points.inputs[5].default_value = (0.0, 0.0, 0.0)
    #Scale
    instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)
    
    #node Math.001
    math_001 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'DIVIDE'
    math_001.use_clamp = False
    #Value_002
    math_001.inputs[2].default_value = 0.5
    
    #node Math.002
    math_002 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'MULTIPLY'
    math_002.use_clamp = False
    #Value_002
    math_002.inputs[2].default_value = 0.5
    
    #node Reroute.001
    reroute_001 = nc_cutternodes.nodes.new("NodeReroute")
    reroute_001.name = "Reroute.001"
    #node Combine XYZ.002
    combine_xyz_002 = nc_cutternodes.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz_002.name = "Combine XYZ.002"
    #Z
    combine_xyz_002.inputs[2].default_value = 0.0
    
    #node Math.003
    math_003 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'DIVIDE'
    math_003.use_clamp = False
    #Value_001
    math_003.inputs[1].default_value = 100.0
    #Value_002
    math_003.inputs[2].default_value = 0.5
    
    #node Math.004
    math_004 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_004.name = "Math.004"
    math_004.operation = 'MULTIPLY'
    math_004.use_clamp = False
    #Value_001
    math_004.inputs[1].default_value = 33.0
    #Value_002
    math_004.inputs[2].default_value = 0.5
    
    #node Realize Instances
    realize_instances = nc_cutternodes.nodes.new("GeometryNodeRealizeInstances")
    realize_instances.name = "Realize Instances"
    
    #node Merge by Distance
    merge_by_distance = nc_cutternodes.nodes.new("GeometryNodeMergeByDistance")
    merge_by_distance.name = "Merge by Distance"
    merge_by_distance.mode = 'ALL'
    #Selection
    merge_by_distance.inputs[1].default_value = True
    
    #node Set Position
    set_position = nc_cutternodes.nodes.new("GeometryNodeSetPosition")
    set_position.name = "Set Position"
    #Selection
    set_position.inputs[1].default_value = True
    #Position
    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)
    
    #node Set Material
    set_material = nc_cutternodes.nodes.new("GeometryNodeSetMaterial")
    set_material.name = "Set Material"
    set_material.mute = True
    #Selection
    set_material.inputs[1].default_value = True
    if "NC_Preview" in bpy.data.materials:
        set_material.inputs[2].default_value = bpy.data.materials["NC_Preview"]
    
    #node Combine XYZ.003
    combine_xyz_003 = nc_cutternodes.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz_003.name = "Combine XYZ.003"
    
    #node Value.003
    value_003 = nc_cutternodes.nodes.new("ShaderNodeValue")
    value_003.name = "Value.003"
    value_003.use_custom_color = True
    value_003.color = (0.0, 0.9999715685844421, 0.09228704124689102)
    
    value_003.outputs[0].default_value = 0.40000036358833313
    #node Vector Math
    vector_math = nc_cutternodes.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'MULTIPLY'
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math.inputs[3].default_value = 1.0
    
    #node Vector Rotate
    vector_rotate = nc_cutternodes.nodes.new("ShaderNodeVectorRotate")
    vector_rotate.name = "Vector Rotate"
    vector_rotate.invert = False
    vector_rotate.rotation_type = 'Z_AXIS'
    #Center
    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Axis
    vector_rotate.inputs[2].default_value = (0.0, 0.0, 1.0)
    #Rotation
    vector_rotate.inputs[4].default_value = (0.0, 0.0, 0.0)
    
    #node Value.004
    value_004 = nc_cutternodes.nodes.new("ShaderNodeValue")
    value_004.name = "Value.004"
    value_004.use_custom_color = True
    value_004.color = (0.0, 0.9999715685844421, 0.09228704124689102)
    
    value_004.outputs[0].default_value = 3.6689999103546143
    #node Image Texture
    image_texture = nc_cutternodes.nodes.new("GeometryNodeImageTexture")
    image_texture.name = "Image Texture"
    image_texture.extension = 'REPEAT'
    image_texture.interpolation = 'Linear'
    #Frame
    image_texture.inputs[2].default_value = 0
    
    #node Math.005
    math_005 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_005.name = "Math.005"
    math_005.operation = 'MULTIPLY'
    math_005.use_clamp = False
    #Value_002
    math_005.inputs[2].default_value = 0.5
    
    #node Value.005
    value_005 = nc_cutternodes.nodes.new("ShaderNodeValue")
    value_005.name = "Value.005"
    value_005.use_custom_color = True
    value_005.color = (0.0, 0.9999715685844421, 0.09228704124689102)
    
    value_005.outputs[0].default_value = 0.0
    #node Mix
    mix = nc_cutternodes.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.5
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    #A_Rotation
    mix.inputs[8].default_value = (0.0, 0.0, 0.0)
    #B_Rotation
    mix.inputs[9].default_value = (0.0, 0.0, 0.0)
    
    #node Normal
    normal = nc_cutternodes.nodes.new("GeometryNodeInputNormal")
    normal.name = "Normal"
    
    #node Vector Math.001
    vector_math_001 = nc_cutternodes.nodes.new("ShaderNodeVectorMath")
    vector_math_001.name = "Vector Math.001"
    vector_math_001.operation = 'MULTIPLY'
    #Vector_002
    vector_math_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math_001.inputs[3].default_value = 1.0
    
    #node Math.006
    math_006 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_006.name = "Math.006"
    math_006.operation = 'MULTIPLY_ADD'
    math_006.use_clamp = False
    
    #node Math.007
    math_007 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_007.name = "Math.007"
    math_007.operation = 'DIVIDE'
    math_007.use_clamp = False
    #Value_001
    math_007.inputs[1].default_value = -4.0
    #Value_002
    math_007.inputs[2].default_value = 0.5
    
    #node Value.006
    value_006 = nc_cutternodes.nodes.new("ShaderNodeValue")
    value_006.name = "Value.006"
    value_006.use_custom_color = True
    value_006.color = (0.0, 0.9999715685844421, 0.09228704124689102)
    
    value_006.outputs[0].default_value = 1.1399999856948853
    #node Mix.001
    mix_001 = nc_cutternodes.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'SOFT_LIGHT'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'RGBA'
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    #A_Rotation
    mix_001.inputs[8].default_value = (0.0, 0.0, 0.0)
    #B_Rotation
    mix_001.inputs[9].default_value = (0.0, 0.0, 0.0)
    
    #node Math.008
    math_008 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_008.name = "Math.008"
    math_008.operation = 'PINGPONG'
    math_008.use_clamp = False
    #Value_001
    math_008.inputs[1].default_value = -0.20000000298023224
    #Value_002
    math_008.inputs[2].default_value = 0.5
    
    #node Mix.002
    mix_002 = nc_cutternodes.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'SUBTRACT'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'RGBA'
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 0.3330000042915344
    #Factor_Vector
    mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_002.inputs[2].default_value = 0.0
    #B_Float
    mix_002.inputs[3].default_value = 0.0
    #A_Vector
    mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
    #A_Rotation
    mix_002.inputs[8].default_value = (0.0, 0.0, 0.0)
    #B_Rotation
    mix_002.inputs[9].default_value = (0.0, 0.0, 0.0)
    
    #node Color Ramp
    color_ramp = nc_cutternodes.nodes.new("ShaderNodeValToRGB")
    color_ramp.name = "Color Ramp"
    color_ramp.color_ramp.color_mode = 'RGB'
    color_ramp.color_ramp.hue_interpolation = 'NEAR'
    color_ramp.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
    color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
    color_ramp_cre_0.position = 0.27272728085517883
    color_ramp_cre_0.alpha = 1.0
    color_ramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.4545454978942871)
    color_ramp_cre_1.alpha = 1.0
    color_ramp_cre_1.color = (0.5, 0.5, 0.5, 1.0)

    color_ramp_cre_2 = color_ramp.color_ramp.elements.new(1.0)
    color_ramp_cre_2.alpha = 1.0
    color_ramp_cre_2.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Noise Texture
    noise_texture = nc_cutternodes.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Detail
    noise_texture.inputs[3].default_value = 12.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.44200000166893005
    #Lacunarity
    noise_texture.inputs[5].default_value = 0.0
    #Offset
    noise_texture.inputs[6].default_value = 0.0
    #Gain
    noise_texture.inputs[7].default_value = 1.0
    #Distortion
    noise_texture.inputs[8].default_value = 0.0
    
    #node Math.009
    math_009 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_009.name = "Math.009"
    math_009.operation = 'MULTIPLY'
    math_009.use_clamp = False
    #Value_001
    math_009.inputs[1].default_value = 7.0
    #Value_002
    math_009.inputs[2].default_value = 0.5
    
    #node Color Ramp.001
    color_ramp_001 = nc_cutternodes.nodes.new("ShaderNodeValToRGB")
    color_ramp_001.name = "Color Ramp.001"
    color_ramp_001.color_ramp.color_mode = 'RGB'
    color_ramp_001.color_ramp.hue_interpolation = 'NEAR'
    color_ramp_001.color_ramp.interpolation = 'LINEAR'
    
    #initialize color ramp elements
    color_ramp_001.color_ramp.elements.remove(color_ramp_001.color_ramp.elements[0])
    color_ramp_001_cre_0 = color_ramp_001.color_ramp.elements[0]
    color_ramp_001_cre_0.position = 0.44545453786849976
    color_ramp_001_cre_0.alpha = 1.0
    color_ramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_001_cre_1 = color_ramp_001.color_ramp.elements.new(0.540909469127655)
    color_ramp_001_cre_1.alpha = 1.0
    color_ramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    color_ramp_001_cre_2 = color_ramp_001.color_ramp.elements.new(0.6977273225784302)
    color_ramp_001_cre_2.alpha = 1.0
    color_ramp_001_cre_2.color = (0.0, 0.0, 0.0, 1.0)

    
    #node Noise Texture.001
    noise_texture_001 = nc_cutternodes.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #W
    noise_texture_001.inputs[1].default_value = 0.0
    #Detail
    noise_texture_001.inputs[3].default_value = 10.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.492000013589859
    #Lacunarity
    noise_texture_001.inputs[5].default_value = 2.0
    #Offset
    noise_texture_001.inputs[6].default_value = 0.0
    #Gain
    noise_texture_001.inputs[7].default_value = 1.0
    #Distortion
    noise_texture_001.inputs[8].default_value = 0.0
    
    #node Voronoi Texture
    voronoi_texture = nc_cutternodes.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'CHEBYCHEV'
    voronoi_texture.feature = 'SMOOTH_F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #W
    voronoi_texture.inputs[1].default_value = 0.0
    #Detail
    voronoi_texture.inputs[3].default_value = 0.699999988079071
    #Roughness
    voronoi_texture.inputs[4].default_value = 0.30000001192092896
    #Lacunarity
    voronoi_texture.inputs[5].default_value = 4.0
    #Smoothness
    voronoi_texture.inputs[6].default_value = 1.0
    #Exponent
    voronoi_texture.inputs[7].default_value = 0.5
    #Randomness
    voronoi_texture.inputs[8].default_value = 1.0
    
    #node Math.010
    math_010 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_010.name = "Math.010"
    math_010.operation = 'MULTIPLY'
    math_010.use_clamp = False
    #Value_001
    math_010.inputs[1].default_value = 8.800000190734863
    #Value_002
    math_010.inputs[2].default_value = 0.5
    
    #node Value.007
    value_007 = nc_cutternodes.nodes.new("ShaderNodeValue")
    value_007.name = "Value.007"
    value_007.use_custom_color = True
    value_007.color = (0.0, 0.9999715685844421, 0.09228704124689102)
    
    value_007.outputs[0].default_value = 6.339999675750732
    #node Math.011
    math_011 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_011.name = "Math.011"
    math_011.operation = 'DIVIDE'
    math_011.use_clamp = False
    #Value_001
    math_011.inputs[1].default_value = 100.0
    #Value_002
    math_011.inputs[2].default_value = 0.5
    
    #node Position
    position = nc_cutternodes.nodes.new("GeometryNodeInputPosition")
    position.name = "Position"
    
    #node Mix.003
    mix_003 = nc_cutternodes.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'SUBTRACT'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'VECTOR'
    mix_003.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_003.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_003.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_003.inputs[2].default_value = 0.0
    #B_Float
    mix_003.inputs[3].default_value = 0.0
    #A_Color
    mix_003.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)
    #B_Color
    mix_003.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
    #A_Rotation
    mix_003.inputs[8].default_value = (0.0, 0.0, 0.0)
    #B_Rotation
    mix_003.inputs[9].default_value = (0.0, 0.0, 0.0)
    
    #node Reroute.002
    reroute_002 = nc_cutternodes.nodes.new("NodeReroute")
    reroute_002.name = "Reroute.002"
    #node Reroute.003
    reroute_003 = nc_cutternodes.nodes.new("NodeReroute")
    reroute_003.name = "Reroute.003"
    #node Math.012
    math_012 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_012.name = "Math.012"
    math_012.operation = 'SUBTRACT'
    math_012.use_clamp = False
    #Value_002
    math_012.inputs[2].default_value = 0.5
    
    #node Math.013
    math_013 = nc_cutternodes.nodes.new("ShaderNodeMath")
    math_013.name = "Math.013"
    math_013.operation = 'DIVIDE'
    math_013.use_clamp = False
    #Value_001
    math_013.inputs[1].default_value = 2.0
    #Value_002
    math_013.inputs[2].default_value = 0.5
    
    
    
    
    #Set locations
    group_input.location = (-326.5056457519531, -37.52433395385742)
    group_output.location = (5506.4765625, 278.5551452636719)
    set_spline_cyclic.location = (-106.50566864013672, -59.42977523803711)
    capture_attribute.location = (85.2175064086914, -362.01123046875)
    spline_parameter.location = (-332.24078369140625, 182.95767211914062)
    curve_length.location = (332.77667236328125, -253.65057373046875)
    math.location = (573.4867553710938, -83.23490905761719)
    value.location = (84.87128448486328, 249.13771057128906)
    combine_xyz.location = (845.5108032226562, 310.0826721191406)
    value_001.location = (84.87128448486328, 362.3114013671875)
    value_002.location = (87.8856201171875, 473.97607421875)
    curve_line.location = (1139.4085693359375, 480.5976867675781)
    combine_xyz_001.location = (779.3045654296875, 590.2568359375)
    resample_curve.location = (1118.0240478515625, 205.71363830566406)
    curve_to_mesh.location = (1351.8865966796875, 243.3361053466797)
    extrude_mesh.location = (1613.1014404296875, 198.03379821777344)
    vector.location = (1361.3636474609375, 106.00201416015625)
    reroute.location = (791.21484375, -79.2357177734375)
    resample_curve_001.location = (1319.3194580078125, 809.3524780273438)
    capture_attribute_002.location = (1541.1717529296875, 684.490234375)
    curve_to_mesh_001.location = (1760.0533447265625, 682.8580322265625)
    mesh_to_points.location = (1981.20166015625, 623.9785766601562)
    instance_on_points.location = (2206.70751953125, 571.6412963867188)
    math_001.location = (1506.54345703125, -239.41798400878906)
    math_002.location = (1706.0245361328125, -110.60719299316406)
    reroute_001.location = (369.0398864746094, 156.12338256835938)
    combine_xyz_002.location = (2099.1611328125, -164.23516845703125)
    math_003.location = (2224.56884765625, 195.43601989746094)
    math_004.location = (2396.745361328125, 194.52195739746094)
    realize_instances.location = (2463.5244140625, 500.1900329589844)
    merge_by_distance.location = (2674.912841796875, 474.0572204589844)
    set_position.location = (4981.0927734375, 367.71795654296875)
    set_material.location = (5294.6708984375, 351.07415771484375)
    combine_xyz_003.location = (2946.5244140625, 43.13691329956055)
    value_003.location = (2704.666015625, -15.87289047241211)
    vector_math.location = (3196.801025390625, -152.88906860351562)
    vector_rotate.location = (3402.76171875, 51.6677360534668)
    value_004.location = (3070.8115234375, 167.35317993164062)
    image_texture.location = (3628.733154296875, -4.234779357910156)
    math_005.location = (4216.75146484375, -57.265560150146484)
    value_005.location = (3864.720703125, 112.69268798828125)
    mix.location = (4520.33935546875, -70.84085845947266)
    normal.location = (4321.283203125, 143.02293395996094)
    vector_math_001.location = (4733.73779296875, 66.70896911621094)
    math_006.location = (4308.16796875, -333.3063659667969)
    math_007.location = (4298.7138671875, -529.5599975585938)
    value_006.location = (3949.748779296875, -259.2886047363281)
    mix_001.location = (4061.9921875, -405.26007080078125)
    math_008.location = (4114.15673828125, -647.5028076171875)
    mix_002.location = (3349.834228515625, -362.2732849121094)
    color_ramp.location = (3794.2412109375, -649.5402221679688)
    noise_texture.location = (3565.03857421875, -654.5296020507812)
    math_009.location = (3190.46484375, -824.41455078125)
    color_ramp_001.location = (2943.0458984375, -664.4343872070312)
    noise_texture_001.location = (2621.5498046875, -334.6443786621094)
    voronoi_texture.location = (2622.15234375, -687.5945434570312)
    math_010.location = (2268.487548828125, -660.2906494140625)
    value_007.location = (1546.2916259765625, -826.1744995117188)
    math_011.location = (1825.5875244140625, -776.4219970703125)
    position.location = (1833.2950439453125, -645.2382202148438)
    mix_003.location = (2314.55517578125, -365.7547302246094)
    reroute_002.location = (2498.389404296875, -447.5556335449219)
    reroute_003.location = (2085.535888671875, -796.1448974609375)
    math_012.location = (546.12890625, 566.8761596679688)
    math_013.location = (310.7275390625, 650.9307250976562)
    
    #Set dimensions
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    set_spline_cyclic.width, set_spline_cyclic.height = 140.0, 100.0
    capture_attribute.width, capture_attribute.height = 140.0, 100.0
    spline_parameter.width, spline_parameter.height = 140.0, 100.0
    curve_length.width, curve_length.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    value.width, value.height = 140.0, 100.0
    combine_xyz.width, combine_xyz.height = 140.0, 100.0
    value_001.width, value_001.height = 140.0, 100.0
    value_002.width, value_002.height = 140.0, 100.0
    curve_line.width, curve_line.height = 140.0, 100.0
    combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
    resample_curve.width, resample_curve.height = 140.0, 100.0
    curve_to_mesh.width, curve_to_mesh.height = 140.0, 100.0
    extrude_mesh.width, extrude_mesh.height = 140.0, 100.0
    vector.width, vector.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    resample_curve_001.width, resample_curve_001.height = 140.0, 100.0
    capture_attribute_002.width, capture_attribute_002.height = 140.0, 100.0
    curve_to_mesh_001.width, curve_to_mesh_001.height = 140.0, 100.0
    mesh_to_points.width, mesh_to_points.height = 140.0, 100.0
    instance_on_points.width, instance_on_points.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    reroute_001.width, reroute_001.height = 16.0, 100.0
    combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    math_004.width, math_004.height = 140.0, 100.0
    realize_instances.width, realize_instances.height = 140.0, 100.0
    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
    set_position.width, set_position.height = 140.0, 100.0
    set_material.width, set_material.height = 140.0, 100.0
    combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
    value_003.width, value_003.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    vector_rotate.width, vector_rotate.height = 140.0, 100.0
    value_004.width, value_004.height = 140.0, 100.0
    image_texture.width, image_texture.height = 240.0, 100.0
    math_005.width, math_005.height = 140.0, 100.0
    value_005.width, value_005.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    normal.width, normal.height = 140.0, 100.0
    vector_math_001.width, vector_math_001.height = 140.0, 100.0
    math_006.width, math_006.height = 140.0, 100.0
    math_007.width, math_007.height = 140.0, 100.0
    value_006.width, value_006.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    math_008.width, math_008.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    color_ramp.width, color_ramp.height = 240.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    math_009.width, math_009.height = 140.0, 100.0
    color_ramp_001.width, color_ramp_001.height = 240.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    math_010.width, math_010.height = 140.0, 100.0
    value_007.width, value_007.height = 140.0, 100.0
    math_011.width, math_011.height = 140.0, 100.0
    position.width, position.height = 140.0, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    reroute_002.width, reroute_002.height = 16.0, 100.0
    reroute_003.width, reroute_003.height = 16.0, 100.0
    math_012.width, math_012.height = 140.0, 100.0
    math_013.width, math_013.height = 140.0, 100.0
    
    #initialize nc_cutternodes links
    #group_input.Geometry -> set_spline_cyclic.Geometry
    nc_cutternodes.links.new(group_input.outputs[0], set_spline_cyclic.inputs[0])
    #set_spline_cyclic.Geometry -> capture_attribute.Geometry
    nc_cutternodes.links.new(set_spline_cyclic.outputs[0], capture_attribute.inputs[0])
    #spline_parameter.Factor -> capture_attribute.Value
    nc_cutternodes.links.new(spline_parameter.outputs[0], capture_attribute.inputs[1])
    #capture_attribute.Geometry -> curve_length.Curve
    nc_cutternodes.links.new(capture_attribute.outputs[0], curve_length.inputs[0])
    #curve_length.Length -> math.Value
    nc_cutternodes.links.new(curve_length.outputs[0], math.inputs[0])
    #reroute_001.Output -> math.Value
    nc_cutternodes.links.new(reroute_001.outputs[0], math.inputs[1])
    #reroute.Output -> combine_xyz.Z
    nc_cutternodes.links.new(reroute.outputs[0], combine_xyz.inputs[2])
    #combine_xyz.Vector -> curve_line.Direction
    nc_cutternodes.links.new(combine_xyz.outputs[0], curve_line.inputs[2])
    #combine_xyz_001.Vector -> curve_line.Start
    nc_cutternodes.links.new(combine_xyz_001.outputs[0], curve_line.inputs[0])
    #math_012.Value -> combine_xyz_001.Z
    nc_cutternodes.links.new(math_012.outputs[0], combine_xyz_001.inputs[2])
    #value_001.Value -> curve_line.Length
    nc_cutternodes.links.new(value_001.outputs[0], curve_line.inputs[3])
    #reroute_001.Output -> resample_curve.Count
    nc_cutternodes.links.new(reroute_001.outputs[0], resample_curve.inputs[2])
    #resample_curve.Curve -> curve_to_mesh.Curve
    nc_cutternodes.links.new(resample_curve.outputs[0], curve_to_mesh.inputs[0])
    #curve_to_mesh.Mesh -> extrude_mesh.Mesh
    nc_cutternodes.links.new(curve_to_mesh.outputs[0], extrude_mesh.inputs[0])
    #vector.Vector -> extrude_mesh.Offset
    nc_cutternodes.links.new(vector.outputs[0], extrude_mesh.inputs[2])
    #reroute.Output -> extrude_mesh.Offset Scale
    nc_cutternodes.links.new(reroute.outputs[0], extrude_mesh.inputs[3])
    #math.Value -> reroute.Input
    nc_cutternodes.links.new(math.outputs[0], reroute.inputs[0])
    #curve_line.Curve -> resample_curve_001.Curve
    nc_cutternodes.links.new(curve_line.outputs[0], resample_curve_001.inputs[0])
    #reroute.Output -> resample_curve_001.Length
    nc_cutternodes.links.new(reroute.outputs[0], resample_curve_001.inputs[3])
    #resample_curve_001.Curve -> capture_attribute_002.Geometry
    nc_cutternodes.links.new(resample_curve_001.outputs[0], capture_attribute_002.inputs[0])
    #spline_parameter.Factor -> capture_attribute_002.Value
    nc_cutternodes.links.new(spline_parameter.outputs[0], capture_attribute_002.inputs[1])
    #capture_attribute_002.Geometry -> curve_to_mesh_001.Curve
    nc_cutternodes.links.new(capture_attribute_002.outputs[0], curve_to_mesh_001.inputs[0])
    #curve_to_mesh_001.Mesh -> mesh_to_points.Mesh
    nc_cutternodes.links.new(curve_to_mesh_001.outputs[0], mesh_to_points.inputs[0])
    #mesh_to_points.Points -> instance_on_points.Points
    nc_cutternodes.links.new(mesh_to_points.outputs[0], instance_on_points.inputs[0])
    #extrude_mesh.Mesh -> instance_on_points.Instance
    nc_cutternodes.links.new(extrude_mesh.outputs[0], instance_on_points.inputs[2])
    #math_001.Value -> math_002.Value
    nc_cutternodes.links.new(math_001.outputs[0], math_002.inputs[1])
    #curve_length.Length -> math_001.Value
    nc_cutternodes.links.new(curve_length.outputs[0], math_001.inputs[1])
    #value_001.Value -> math_001.Value
    nc_cutternodes.links.new(value_001.outputs[0], math_001.inputs[0])
    #value.Value -> reroute_001.Input
    nc_cutternodes.links.new(value.outputs[0], reroute_001.inputs[0])
    #capture_attribute_002.Attribute -> math_002.Value
    nc_cutternodes.links.new(capture_attribute_002.outputs[1], math_002.inputs[0])
    #math_002.Value -> combine_xyz_002.Y
    nc_cutternodes.links.new(math_002.outputs[0], combine_xyz_002.inputs[1])
    #capture_attribute.Attribute -> combine_xyz_002.X
    nc_cutternodes.links.new(capture_attribute.outputs[1], combine_xyz_002.inputs[0])
    #instance_on_points.Instances -> realize_instances.Geometry
    nc_cutternodes.links.new(instance_on_points.outputs[0], realize_instances.inputs[0])
    #realize_instances.Geometry -> merge_by_distance.Geometry
    nc_cutternodes.links.new(realize_instances.outputs[0], merge_by_distance.inputs[0])
    #math_004.Value -> merge_by_distance.Distance
    nc_cutternodes.links.new(math_004.outputs[0], merge_by_distance.inputs[2])
    #math_003.Value -> math_004.Value
    nc_cutternodes.links.new(math_003.outputs[0], math_004.inputs[0])
    #reroute.Output -> math_003.Value
    nc_cutternodes.links.new(reroute.outputs[0], math_003.inputs[0])
    #merge_by_distance.Geometry -> set_position.Geometry
    nc_cutternodes.links.new(merge_by_distance.outputs[0], set_position.inputs[0])
    #set_position.Geometry -> set_material.Geometry
    nc_cutternodes.links.new(set_position.outputs[0], set_material.inputs[0])
    #value_003.Value -> combine_xyz_003.X
    nc_cutternodes.links.new(value_003.outputs[0], combine_xyz_003.inputs[0])
    #value_003.Value -> combine_xyz_003.Y
    nc_cutternodes.links.new(value_003.outputs[0], combine_xyz_003.inputs[1])
    #value_003.Value -> combine_xyz_003.Z
    nc_cutternodes.links.new(value_003.outputs[0], combine_xyz_003.inputs[2])
    #combine_xyz_002.Vector -> vector_math.Vector
    nc_cutternodes.links.new(combine_xyz_002.outputs[0], vector_math.inputs[0])
    #vector_math.Vector -> vector_rotate.Vector
    nc_cutternodes.links.new(vector_math.outputs[0], vector_rotate.inputs[0])
    #value_004.Value -> vector_rotate.Angle
    nc_cutternodes.links.new(value_004.outputs[0], vector_rotate.inputs[3])
    #vector_rotate.Vector -> image_texture.Vector
    nc_cutternodes.links.new(vector_rotate.outputs[0], image_texture.inputs[1])
    #image_texture.Color -> math_005.Value
    nc_cutternodes.links.new(image_texture.outputs[0], math_005.inputs[0])
    #value_005.Value -> math_005.Value
    nc_cutternodes.links.new(value_005.outputs[0], math_005.inputs[1])
    #math_005.Value -> mix.A
    nc_cutternodes.links.new(math_005.outputs[0], mix.inputs[6])
    #normal.Normal -> vector_math_001.Vector
    nc_cutternodes.links.new(normal.outputs[0], vector_math_001.inputs[0])
    #mix.Result -> vector_math_001.Vector
    nc_cutternodes.links.new(mix.outputs[2], vector_math_001.inputs[1])
    #vector_math_001.Vector -> set_position.Offset
    nc_cutternodes.links.new(vector_math_001.outputs[0], set_position.inputs[3])
    #math_006.Value -> mix.B
    nc_cutternodes.links.new(math_006.outputs[0], mix.inputs[7])
    #math_007.Value -> math_006.Value
    nc_cutternodes.links.new(math_007.outputs[0], math_006.inputs[2])
    #value_006.Value -> math_006.Value
    nc_cutternodes.links.new(value_006.outputs[0], math_006.inputs[1])
    #value_006.Value -> math_007.Value
    nc_cutternodes.links.new(value_006.outputs[0], math_007.inputs[0])
    #mix_001.Result -> math_006.Value
    nc_cutternodes.links.new(mix_001.outputs[2], math_006.inputs[0])
    #math_008.Value -> mix_001.B
    nc_cutternodes.links.new(math_008.outputs[0], mix_001.inputs[7])
    #mix_002.Result -> mix_001.A
    nc_cutternodes.links.new(mix_002.outputs[2], mix_001.inputs[6])
    #color_ramp.Color -> math_008.Value
    nc_cutternodes.links.new(color_ramp.outputs[0], math_008.inputs[0])
    #noise_texture.Fac -> color_ramp.Fac
    nc_cutternodes.links.new(noise_texture.outputs[0], color_ramp.inputs[0])
    #math_009.Value -> noise_texture.Scale
    nc_cutternodes.links.new(math_009.outputs[0], noise_texture.inputs[2])
    #color_ramp_001.Color -> mix_002.B
    nc_cutternodes.links.new(color_ramp_001.outputs[0], mix_002.inputs[7])
    #noise_texture_001.Fac -> mix_002.A
    nc_cutternodes.links.new(noise_texture_001.outputs[0], mix_002.inputs[6])
    #voronoi_texture.Color -> color_ramp_001.Fac
    nc_cutternodes.links.new(voronoi_texture.outputs[1], color_ramp_001.inputs[0])
    #reroute_002.Output -> noise_texture_001.Vector
    nc_cutternodes.links.new(reroute_002.outputs[0], noise_texture_001.inputs[0])
    #reroute_002.Output -> noise_texture.Vector
    nc_cutternodes.links.new(reroute_002.outputs[0], noise_texture.inputs[0])
    #reroute_002.Output -> voronoi_texture.Vector
    nc_cutternodes.links.new(reroute_002.outputs[0], voronoi_texture.inputs[0])
    #math_010.Value -> noise_texture_001.Scale
    nc_cutternodes.links.new(math_010.outputs[0], noise_texture_001.inputs[2])
    #math_010.Value -> voronoi_texture.Scale
    nc_cutternodes.links.new(math_010.outputs[0], voronoi_texture.inputs[2])
    #value_007.Value -> math_011.Value
    nc_cutternodes.links.new(value_007.outputs[0], math_011.inputs[0])
    #reroute_003.Output -> math_010.Value
    nc_cutternodes.links.new(reroute_003.outputs[0], math_010.inputs[0])
    #position.Position -> mix_003.B
    nc_cutternodes.links.new(position.outputs[0], mix_003.inputs[5])
    #combine_xyz_002.Vector -> mix_003.A
    nc_cutternodes.links.new(combine_xyz_002.outputs[0], mix_003.inputs[4])
    #mix_003.Result -> reroute_002.Input
    nc_cutternodes.links.new(mix_003.outputs[1], reroute_002.inputs[0])
    #math_011.Value -> reroute_003.Input
    nc_cutternodes.links.new(math_011.outputs[0], reroute_003.inputs[0])
    #reroute_003.Output -> math_009.Value
    nc_cutternodes.links.new(reroute_003.outputs[0], math_009.inputs[0])
    #combine_xyz_002.Vector -> group_output.MyUV
    nc_cutternodes.links.new(combine_xyz_002.outputs[0], group_output.inputs[1])
    #set_material.Geometry -> group_output.Geometry
    nc_cutternodes.links.new(set_material.outputs[0], group_output.inputs[0])
    #combine_xyz_003.Vector -> vector_math.Vector
    nc_cutternodes.links.new(combine_xyz_003.outputs[0], vector_math.inputs[1])
    #capture_attribute.Geometry -> resample_curve.Curve
    nc_cutternodes.links.new(capture_attribute.outputs[0], resample_curve.inputs[0])
    #value_002.Value -> math_012.Value
    nc_cutternodes.links.new(value_002.outputs[0], math_012.inputs[0])
    #value_001.Value -> math_013.Value
    nc_cutternodes.links.new(value_001.outputs[0], math_013.inputs[0])
    #math_013.Value -> math_012.Value
    nc_cutternodes.links.new(math_013.outputs[0], math_012.inputs[1])


    #drivers
    value_driver(value_001.outputs[0],'my_prop.my_dep') 
    value_driver(value.outputs[0],'my_prop.my_dens') 
    value_driver(value_004.outputs[0],'my_prop.my_rot')     
    value_driver(value_006.outputs[0],'my_prop.my_noiz')  
    value_driver(value_002.outputs[0],'my_prop.my_dep2') 
    
    value_driver(value_007.outputs[0],'my_prop.my_scal') 
    value_driver(value_003.outputs[0],'my_prop.my_scale2')  
    value_driver(value_005.outputs[0],'my_prop.my_disp') 







    return nc_cutternodes










# ------------------------------------------------------------------------
#    Operators
# ------------------------------------------------------------------------
class DRAW_button(bpy.types.Operator):
    bl_idname = "wm.decal"
    bl_label = "DRAW CUTTER"
    bl_description="Draw the cut spline. Press TAB to finish. Don't forget to draw in Orthographic view (numpad 5)"

    def execute(self, context):
        sel = bpy.context.selected_objects
        if len(sel)<1:
            ShowMessageBox("Please, select an object first")
        else: 
            ob = bpy.context.view_layer.objects.active
            bpy.context.scene.cursor.location = ob.location   
                
            for area in bpy.context.screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'WINDOW':
                            ctx = bpy.context.copy()
                            ctx['area'] = area
                            ctx['region'] = region
                            bpy.ops.curve.primitive_bezier_curve_add(radius=1, enter_editmode=True, align='VIEW', location=ob.location, )
                            bpy.context.object.show_in_front = True
                            cv = bpy.context.view_layer.objects.active
                            cv.name='CUTTER_profil'
                            bpy.ops.curve.delete(type='VERT')

                            #bpy.ops.view3d.view_persportho(ctx)
                            bpy.context.scene.tool_settings.curve_paint_settings.curve_type = 'BEZIER'
                            bpy.context.scene.tool_settings.curve_paint_settings.fit_method = 'REFIT'
                            bpy.context.scene.tool_settings.curve_paint_settings.error_threshold = 8
                            bpy.context.scene.tool_settings.curve_paint_settings.use_corners_detect = True
                            bpy.context.scene.tool_settings.curve_paint_settings.corner_angle = 1.22173
                            bpy.context.scene.tool_settings.curve_paint_settings.radius_taper_start = 0
                            bpy.context.scene.tool_settings.curve_paint_settings.radius_taper_end = 0
                            bpy.context.scene.tool_settings.curve_paint_settings.radius_min = 0
                            bpy.context.scene.tool_settings.curve_paint_settings.radius_max = 1
                            bpy.context.scene.tool_settings.curve_paint_settings.use_pressure_radius = False
                            bpy.context.scene.tool_settings.curve_paint_settings.depth_mode = 'CURSOR'

                            bpy.ops.wm.tool_set_by_id(name="builtin.draw")  
                            break 
                        


            
                        
            # MESHER  ##################
            
            # preview material
            mat_name="NC_Preview"
            ng = bpy.data.materials
            if mat_name in ng:
                mat = bpy.data.materials.get(mat_name)
            else:                   
                mat = bpy.data.materials.new(name = mat_name)
                mat.use_nodes = True
                mat.diffuse_color = (0.05, 0.05, 0.05, 1)
                NC_Preview = mat.node_tree
                for node in NC_Preview.nodes:
                    NC_Preview.nodes.remove(node)
                material_output = NC_Preview.nodes.new("ShaderNodeOutputMaterial")
                principled_bsdf = NC_Preview.nodes.new("ShaderNodeBsdfPrincipled")
                

                principled_bsdf.inputs[0].default_value = (0.05, 0.05, 0.05, 1)
                material_output.location = (300.0, 300.0)
                principled_bsdf.location = (-83.83859252929688, 303.24078369140625)
                NC_Preview.links.new(principled_bsdf.outputs[0], material_output.inputs[0])     
                

            #mesher
            obj = bpy.context.active_object
            
            if obj.type == 'CURVE':
                #bpy.ops.object.mode_set(mode="OBJECT")
                
                if bpy.context.scene.my_prop.my_del2 == False :
                    bpy.ops.object.duplicate()
                    duplicated_object = bpy.context.active_object
                    obj.select_set(True)
                    bpy.context.view_layer.objects.active = obj
                    
                
                if 'NC_cutternodes' not in bpy.data.node_groups:
                    NC_cutternodes = nc_cutternodes_node_group()
                else:
                    print("Already here")    
                
                # temp dev mod
    #            NC_cutternodes = nc_cutternodes_node_group()
                
                #ng = bpy.data.node_groups['NC_cutternodes']
                modifier=obj.modifiers.new("Cutter", "NODES")
                #bpy.data.node_groups.remove(modifier.node_group)
                modifier.node_group = bpy.data.node_groups['NC_cutternodes']
                #modifier["Output_1_attribute_name"] = "UVMap"
                modifier["Socket_1_attribute_name"] = "UVMap"


                
                obj.name="CUTTER"
                bpy.context.object.show_in_front = False
                bpy.context.object.show_wire = True

          
            
    #        if event.type == 'RIGHTMOUSE':
    #            if event.value == 'RELEASE': 
    #                bpy.ops.object.mode_set(mode="OBJECT")    
                               
        return {'FINISHED'}        
                                     

class MESHER2_button(bpy.types.Operator):
    bl_idname = "wm.mesher2"
    bl_label = "DRAWING (TAB to exit)"
    bl_description="Stop drawing"
    
    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        return {'FINISHED'}        

class BOOL_button(bpy.types.Operator):
    bl_idname = "wm.boolcut"
    bl_label = "CUT Fast"
    bl_description ="Cut selected objects with the CUTTER plane. Just select the objects before to use the CUT button"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        context = bpy.context
        scene = context.scene
        #cutter = bpy.context.active_object
        print("FAST **************************")
        if bpy.data.objects.get("CUTTER") is not None and len(bpy.context.selected_objects)>0:            
            cutter = bpy.data.objects.get('CUTTER')
            sel = bpy.context.selected_objects
            state=0
            for o in sel:
                if o.type == 'MESH' and o.name!="CUTTER":
                    state+=1
                else:
                    state+=0                    
            if state > 0: 
                cutter = bpy.data.objects.get('CUTTER')   
                bpy.ops.object.select_all(action='DESELECT')
                cutter.select_set(True)
                bpy.context.view_layer.objects.active = cutter                
                # mute material node from geometry nodes
                if 'NC_cutternodes' in bpy.data.node_groups:
                    node_name = "Set Material"     
                    node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
                    node.mute = True                                                    
                #convert to mesh and atribute to UVmap
                bpy.ops.object.convert(target='MESH')
                a = bpy.context.object.data.attributes
                a.active = a['UVMap']
                bpy.ops.geometry.attribute_convert(mode='GENERIC', domain='CORNER', data_type='FLOAT2')
                               
                mat_name=bpy.context.scene.my_prop.my_enum                
                cutter_material = bpy.data.materials.get(mat_name)
                cutter.active_material = cutter_material 
                print("geonode converted to mesh")
                
                                 
                list=[]
                for o in sel:
                     if o != cutter and o.type =='MESH':
                         list.append(o)                
                for ob in list:
                    bpy.ops.object.select_all(action='DESELECT')
                    ob.select_set(True)
                    bpy.context.view_layer.objects.active = ob
                    bpy.ops.object.convert(target='MESH')     
                    bpy.ops.object.shade_smooth_by_angle()           
#                    ob.data.use_auto_smooth = True
#                    ob .data.auto_smooth_angle = 0.52                                  
                    # CREATE dummy base Material if object don't have any material   
                    mat_name="NC_Temp"
                    ng = bpy.data.materials
                    if mat_name in ng:
                        dummy_mat = bpy.data.materials.get(mat_name)
                    else:
                        dummy_mat = bpy.data.materials.new(name=mat_name)
                        dummy_mat.diffuse_color = (0.75, 0.75, 0.75,1) 
                        dummy_mat.use_nodes = True
                        nodes = dummy_mat.node_tree.nodes
                        dummy_mat.node_tree.nodes.clear() 
                        princ = nodes.new('ShaderNodeBsdfPrincipled')
                        princ.location = (0,0)
                        outepute= nodes.new('ShaderNodeOutputMaterial')
                        outepute.location=(300,0)
                        dummy_mat.node_tree.links.new(princ.outputs[0], outepute.inputs[0])                 
                    ob_mat = ob.active_material
                    if not ob_mat:
                        ob.data.materials.append(dummy_mat)   
                    if not cutter_material.name in ob.material_slots:
                        ob.data.materials.append(cutter_material)    
                    print("materials ok")     
                                                
                    #Boolean 1                                  
                    mod = ob.modifiers.new('Boolean',type='BOOLEAN')
                    mod.object = cutter
                    mod.operation = 'DIFFERENCE'                    
                    mod.solver = 'FAST'
                    bpy.ops.object.shade_smooth_by_angle()

#                    bpy.ops.object.mode_set(mode="EDIT")
#                    bpy.ops.mesh.select_all(action='SELECT')
#                    bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0)                
#                    bpy.ops.object.mode_set(mode="OBJECT")    
                    #add cutter material to objet
                    print("Boolean1 ok")

                    #Boolean 2    
                    bpy.ops.object.duplicate_move()
                    ob2 = bpy.context.view_layer.objects.active
                    bpy.ops.object.modifier_apply(modifier="Boolean")
                    bpy.context.view_layer.objects.active = cutter
                    bpy.ops.object.mode_set(mode="EDIT")  
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.flip_normals()
                    bpy.ops.object.mode_set(mode="OBJECT")                
                    bpy.context.view_layer.objects.active = ob  
                    ob.modifiers["Boolean"].operation = 'DIFFERENCE'                    
                    bpy.ops.object.modifier_apply(modifier="Boolean")
                    bpy.context.view_layer.objects.active = cutter
                    bpy.ops.object.mode_set(mode="EDIT")  
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.flip_normals()
                    bpy.ops.object.mode_set(mode="OBJECT") 
                    bpy.ops.object.shade_smooth_by_angle()
                   
                    print("Boolean2 ok")           
                             
                if bpy.context.scene.my_prop.my_del == True :
                    bpy.data.objects.remove(cutter, do_unlink=True)
                    print("cutter removed")

         
        # unmute material node from geometry nodes for next operations
        if 'NC_cutternodes' in bpy.data.node_groups:
            node_name = "Set Material"     
            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
            node.mute = False  
            print("GeoNode restored for next operation")
            
        return{'FINISHED'}    
class BOOL3_button(bpy.types.Operator):
    bl_idname = "wm.boolcut3"
    bl_label = "CUT Fast"
    bl_description ="Cut selected objects with the CUTTER plane. Just select the objects before to use the CUT button"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        context = bpy.context
        scene = context.scene
        #cutter = bpy.context.active_object
        

            
        print("FAST2 **************************")
        if bpy.data.objects.get("CUTTER") is not None and len(bpy.context.selected_objects)>0:            
            cutter = bpy.data.objects.get('CUTTER')
            sel = bpy.context.selected_objects
            state=0
            for o in sel:
                if o.type == 'MESH' and o.name!="CUTTER":
                    state+=1
                else:
                    state+=0                    
            if state > 0: 
                cutter = bpy.data.objects.get('CUTTER')   
                bpy.ops.object.select_all(action='DESELECT')
                cutter.select_set(True)
                bpy.context.view_layer.objects.active = cutter   
                for modifier in cutter.modifiers:
                    if modifier.type == "NODES":  
                        print("cutter is a Geonode")           
                        # mute material node from geometry nodes
                        if 'NC_cutternodes' in bpy.data.node_groups:
                            node_name = "Set Material"     
                            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
                            node.mute = True                                                    
                        #convert to mesh and atribute to UVmap
                        bpy.ops.object.convert(target='MESH')
                        a = bpy.context.object.data.attributes
                        a.active = a['UVMap']
                        bpy.ops.geometry.attribute_convert(mode='GENERIC', domain='CORNER', data_type='FLOAT2')
                                       
                        mat_name=bpy.context.scene.my_prop.my_enum                
                        cutter_material = bpy.data.materials.get(mat_name)
                        cutter.active_material = cutter_material 
                        print("geonode converted to mesh")
                else:
                    print("Cutter is a mesh")
                cutter.select_set(True)
                bpy.context.view_layer.objects.active = cutter
                mod1 = cutter.modifiers.new('Solidify',type='SOLIDIFY')
                mod1.offset = 0
                mod1.thickness = 0.001

                print("solidify ok")          



                                         
                list=[]
                for o in sel:
                     if o != cutter and o.type =='MESH':
                         list.append(o)                
                for ob in list:
                    bpy.ops.object.select_all(action='DESELECT')
                    ob.select_set(True)
                    bpy.context.view_layer.objects.active = ob
                    bpy.ops.object.convert(target='MESH') 
                    bpy.ops.object.shade_smooth_by_angle()
                    #ob.data.use_auto_smooth = True
                    #ob .data.auto_smooth_angle = 0.52                                  
                    # CREATE dummy base Material if object don't have any material   
                    mat_name="NC_Temp"
                    ng = bpy.data.materials
                    if mat_name in ng:
                        dummy_mat = bpy.data.materials.get(mat_name)
                    else:
                        dummy_mat = bpy.data.materials.new(name=mat_name)
                        dummy_mat.diffuse_color = (0.75, 0.75, 0.75,1) 
                        dummy_mat.use_nodes = True
                        nodes = dummy_mat.node_tree.nodes
                        dummy_mat.node_tree.nodes.clear() 
                        princ = nodes.new('ShaderNodeBsdfPrincipled')
                        princ.location = (0,0)
                        outepute= nodes.new('ShaderNodeOutputMaterial')
                        outepute.location=(300,0)
                        dummy_mat.node_tree.links.new(princ.outputs[0], outepute.inputs[0])                 
                    ob_mat = ob.active_material
                    if not ob_mat:
                        ob.data.materials.append(dummy_mat)   
                        
                    mat_name=bpy.context.scene.my_prop.my_enum                
                    cutter_material = bpy.data.materials.get(mat_name)
                    if not cutter_material.name in ob.material_slots:
                        ob.data.materials.append(cutter_material)    
                    print("materials ok")     
                    

                                                
                    #Boolean 1   
                    ob.select_set(True)
                    bpy.context.view_layer.objects.active = ob                           
                    mod = ob.modifiers.new('Boolean',type='BOOLEAN')
                    mod.object = cutter
                    mod.operation = 'DIFFERENCE'                    
                    mod.solver = 'FAST'
                    bpy.ops.object.convert(target='MESH') 
                    bpy.ops.wm.split()
                    bpy.ops.object.shade_smooth_by_angle()

                    print("boolean OK")  
                             
                if bpy.context.scene.my_prop.my_del == True :
                    bpy.data.objects.remove(cutter, do_unlink=True)
                    print("cutter removed")
                else:
                    cutter.modifiers.clear()

         
        # unmute material node from geometry nodes for next operations
        if 'NC_cutternodes' in bpy.data.node_groups:
            node_name = "Set Material"     
            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
            node.mute = False  
            print("GeoNode restored for next operation")
            
        return{'FINISHED'}    
    
        
class BOOL2_button(bpy.types.Operator):
    bl_idname = "wm.boolcut2"
    bl_label = "CUT Advanced"
    bl_description ="Cut selected objects with the CUTTER plane. Just select the objects before to use the CUT button"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        context = bpy.context
        scene = context.scene
        #cutter = bpy.context.active_object
        if bpy.data.objects.get("CUTTER") is not None and len(bpy.context.selected_objects)>0:            
            cutter = bpy.data.objects.get('CUTTER')
            sel = bpy.context.selected_objects
            state=0
            for o in sel:
                if o.type == 'MESH' and o.name!="CUTTER":
                    state+=1
                else:
                    state+=0                    
            if state > 0: 
                cutter = bpy.data.objects.get('CUTTER')   
                bpy.ops.object.select_all(action='DESELECT')
                cutter.select_set(True)
                bpy.context.view_layer.objects.active = cutter   
                for modifier in cutter.modifiers:
                    if modifier.type == "NODES":  
                        print("cutter is a Geonode")           
                        # mute material node from geometry nodes
                        if 'NC_cutternodes' in bpy.data.node_groups:
                            node_name = "Set Material"     
                            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
                            node.mute = True                                                    
                        #convert to mesh and atribute to UVmap
                        bpy.ops.object.convert(target='MESH')
                        a = bpy.context.object.data.attributes
                        a.active = a['UVMap']
                        bpy.ops.geometry.attribute_convert(mode='GENERIC', domain='CORNER', data_type='FLOAT2')
                                       
                        mat_name=bpy.context.scene.my_prop.my_enum                
                        cutter_material = bpy.data.materials.get(mat_name)
                        cutter.active_material = cutter_material 
                        print("geonode converted to mesh")
                else:
                    print("Cutter is a mesh")
                    
                list=[]
                for o in sel:
                     if o != cutter and o.type =='MESH':
                         list.append(o)                
                for ob in list:
                    bpy.ops.object.select_all(action='DESELECT')
                    ob.select_set(True)
                    bpy.context.view_layer.objects.active = ob
                    bpy.ops.object.convert(target='MESH') 
                    bpy.ops.object.shade_smooth_by_angle()

#                    ob.data.use_auto_smooth = True
#                    ob .data.auto_smooth_angle = 0.872665                                        
                    # CREATE dummy base Material if object don't have any material   
                    mat_name="NC_Temp"
                    ng = bpy.data.materials
                    if mat_name in ng:
                        dummy_mat = bpy.data.materials.get(mat_name)
                    else:
                        dummy_mat = bpy.data.materials.new(name=mat_name)
                        dummy_mat.diffuse_color = (0.75, 0.75, 0.75,1) 
                        dummy_mat.use_nodes = True
                        nodes = dummy_mat.node_tree.nodes
                        dummy_mat.node_tree.nodes.clear() 
                        princ = nodes.new('ShaderNodeBsdfPrincipled')
                        princ.location = (0,0)
                        outepute= nodes.new('ShaderNodeOutputMaterial')
                        outepute.location=(300,0)
                        dummy_mat.node_tree.links.new(princ.outputs[0], outepute.inputs[0])                 
                    ob_mat = ob.active_material
                    if not ob_mat:
                        ob.data.materials.append(dummy_mat)                                 
                    mod = ob.modifiers.new('Boolean',type='BOOLEAN')
                    mod.object = cutter
                    mod.operation = 'DIFFERENCE'
                    mod.solver = 'EXACT'
                    mod.use_hole_tolerant = False
                    mod.use_self = True
                    mod.material_mode = 'TRANSFER'
                    
                        
                    bpy.ops.object.duplicate_move()
                    ob2 = bpy.context.view_layer.objects.active
                    bpy.ops.object.modifier_apply(modifier="Boolean")
                    bpy.ops.object.shade_smooth_by_angle()
                    
                    bpy.context.view_layer.objects.active = cutter
                    bpy.ops.object.mode_set(mode="EDIT")  
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.flip_normals()
                    bpy.ops.object.mode_set(mode="OBJECT")  
                                  
                    bpy.context.view_layer.objects.active = ob                  
                    bpy.ops.object.modifier_apply(modifier="Boolean")
                    bpy.ops.object.shade_smooth_by_angle()   
                    
                    bpy.context.view_layer.objects.active = cutter
                    bpy.ops.object.mode_set(mode="EDIT")  
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.flip_normals()
                    bpy.ops.object.mode_set(mode="OBJECT") 
                    
                    bpy.context.view_layer.objects.active=ob
                    ob.select_set(True)
                    ob.name="01"
                    bpy.ops.object.shade_smooth_by_angle()  
                    
                    bpy.context.view_layer.objects.active =ob2  
                    ob2.select_set(True)
                    ob2.name="02"
                    bpy.ops.object.shade_smooth_by_angle()  
                    
                                 
#                    # DEPLIAGE uv sur la section
#                    bpy.context.view_layer.objects.active = ob 
#                    index = -1
#                    mat_name=bpy.context.scene.my_prop.my_enum
#                    for m in ob.material_slots:
#                        index += 1
#                        bpy.context.object.active_material_index=index 
#                        mat=bpy.context.object.active_material
#                        
#                        if mat.name==mat_name:
#                            bpy.ops.object.mode_set(mode="EDIT")
#                            bpy.ops.mesh.select_all(action='DESELECT')
#                            bpy.ops.object.material_slot_select()
#                            bpy.ops.uv.smart_project()
#                            #bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.001)
#                            bpy.ops.object.mode_set(mode="OBJECT")                                             
                if bpy.context.scene.my_prop.my_del == True :
                    bpy.data.objects.remove(cutter, do_unlink=True)

        # unmute material node from geometry nodes for next operations
        if 'NC_cutternodes' in bpy.data.node_groups:
            node_name = "Set Material"     
            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
            node.mute = False  
        return{'FINISHED'}    
    
        
class SPLIT_button(bpy.types.Operator):
    bl_idname = "wm.split"
    bl_label = "Split"
    bl_description ="Split disconnected mesh"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context): 
        sel= bpy.context.selected_objects 
        for i in sel:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.separate(type='LOOSE')
            bpy.ops.object.editmode_toggle()               
        return{'FINISHED'} 
    
class ORIG_button(bpy.types.Operator):
    bl_idname = "wm.orig"
    bl_label = "Origin"
    bl_description ="Set origin to geometry"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context): 
        sel= bpy.context.selected_objects 
        for i in sel:
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')        
        return{'FINISHED'} 
    
class WIR_button(bpy.types.Operator):
    bl_idname = "wm.wir"
    bl_label = "Display Wireframe"
    bl_description ="View wireframe"
    def execute(self, context): 
        sel= bpy.context.selected_objects 
        for i in sel:
            if i.show_wire == False:
                i.show_wire = True
            else:
                i.show_wire = False  
    
        return{'FINISHED'}  





class CYC_button(bpy.types.Operator):
    bl_idname = "wm.cyc"
    bl_label = "Cyclic Profil"
    bl_description ="switch to closed curve"
    def execute(self, context):   
        if bpy.data.objects.get("CUTTER") is not None:
            node_name = "Set Spline Cyclic"     
            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
            if node.inputs[2].default_value == False:      
                node.inputs[2].default_value = True
            else:
                node.inputs[2].default_value = False
            return{'FINISHED'}  
            
            
            
                
###--Update   
class UPD_button(bpy.types.Operator):
    bl_idname = "wm.upd"
    bl_label = "Load Texture"
    bl_description ="Update image texture"
    def execute(self, context):   

        my_path=bpy.context.scene.my_prop.my_path                
        tex_name=os.path.basename(my_path)
        ob = bpy.context.view_layer.objects.active                               
        image_exists = tex_name in bpy.data.images
        if image_exists:
            new_img = bpy.data.images[tex_name]
        else:
            if my_path=="":
                new_img = None
            else:    
                new_img = bpy.data.images.load(filepath = my_path)
            
        if 'NC_cutternodes' in bpy.data.node_groups:              
            node_name = "Image Texture"     
            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)
            node.inputs[0].default_value = new_img

        
        return{'FINISHED'} 


class MAT_button(bpy.types.Operator):
    bl_idname = "wm.mat"
    bl_label = "Add NC_Broken-Concrete Material"
    bl_description ="NC_Broken-Concrete Material is a high definition procedural material"
    def execute(self, context):   
        mat_name="NC_Broken-Concrete"
        ng = bpy.data.materials
        grp = bpy.data.node_groups
        if "CementBreak" not in grp:


            cementbreak = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "CementBreak")
            color_socket = cementbreak.interface.new_socket(name = "Color", in_out='OUTPUT', socket_type = 'NodeSocketColor')
            color_socket.attribute_domain = 'POINT'
            roughness_socket = cementbreak.interface.new_socket(name = "Roughness", in_out='OUTPUT', socket_type = 'NodeSocketColor')
            roughness_socket.attribute_domain = 'POINT'
            normal_socket = cementbreak.interface.new_socket(name = "Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
            normal_socket.subtype = 'NONE'
            normal_socket.default_value = (0.0, 0.0, 0.0)
            normal_socket.min_value = -3.4028234663852886e+38
            normal_socket.max_value = 3.4028234663852886e+38
            normal_socket.attribute_domain = 'POINT'
            scale_socket = cementbreak.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
            scale_socket.subtype = 'NONE'
            scale_socket.default_value = 0.30000001192092896
            scale_socket.min_value = 0.0
            scale_socket.max_value = 50.0
            scale_socket.attribute_domain = 'POINT'
            generated_uv_socket = cementbreak.interface.new_socket(name = "Generated/UV", in_out='INPUT', socket_type = 'NodeSocketFloat')
            generated_uv_socket.subtype = 'NONE'
            generated_uv_socket.default_value = 1.0
            generated_uv_socket.min_value = 0.0
            generated_uv_socket.max_value = 1.0
            generated_uv_socket.attribute_domain = 'POINT'
            group_output = cementbreak.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.is_active_output = True
            mix = cementbreak.nodes.new("ShaderNodeMix")
            mix.name = "Mix"
            mix.blend_type = 'MULTIPLY'
            mix.clamp_factor = True
            mix.clamp_result = False
            mix.data_type = 'RGBA'
            mix.factor_mode = 'UNIFORM'
            mix.inputs[0].default_value = 0.6416666507720947
            mix.inputs[1].default_value = (0.5, 0.5, 0.5)
            mix.inputs[2].default_value = 0.0
            mix.inputs[3].default_value = 0.0
            mix.inputs[4].default_value = (0.0, 0.0, 0.0)
            mix.inputs[5].default_value = (0.0, 0.0, 0.0)
            mix.inputs[8].default_value = (0.0, 0.0, 0.0)
            mix.inputs[9].default_value = (0.0, 0.0, 0.0)
            noise_texture = cementbreak.nodes.new("ShaderNodeTexNoise")
            noise_texture.name = "Noise Texture"
            noise_texture.noise_dimensions = '3D'
            noise_texture.normalize = True
            noise_texture.inputs[1].default_value = 0.0
            noise_texture.inputs[2].default_value = 8.0
            noise_texture.inputs[3].default_value = 15.0
            noise_texture.inputs[4].default_value = 0.46666666865348816
            noise_texture.inputs[5].default_value = 2.0
            noise_texture.inputs[6].default_value = 0.0
            noise_texture.inputs[7].default_value = 1.0
            noise_texture.inputs[8].default_value = 0.0
            noise_texture_001 = cementbreak.nodes.new("ShaderNodeTexNoise")
            noise_texture_001.name = "Noise Texture.001"
            noise_texture_001.noise_dimensions = '3D'
            noise_texture_001.normalize = True
            noise_texture_001.inputs[1].default_value = 0.0
            noise_texture_001.inputs[2].default_value = 48.999996185302734
            noise_texture_001.inputs[3].default_value = 15.0
            noise_texture_001.inputs[4].default_value = 0.8166666626930237
            noise_texture_001.inputs[5].default_value = 2.0
            noise_texture_001.inputs[6].default_value = 0.0
            noise_texture_001.inputs[7].default_value = 1.0
            noise_texture_001.inputs[8].default_value = 0.0
            mix_001 = cementbreak.nodes.new("ShaderNodeMix")
            mix_001.name = "Mix.001"
            mix_001.blend_type = 'LIGHTEN'
            mix_001.clamp_factor = True
            mix_001.clamp_result = False
            mix_001.data_type = 'RGBA'
            mix_001.factor_mode = 'UNIFORM'
            mix_001.inputs[0].default_value = 0.20000000298023224
            mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
            mix_001.inputs[2].default_value = 0.0
            mix_001.inputs[3].default_value = 0.0
            mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
            mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
            mix_001.inputs[8].default_value = (0.0, 0.0, 0.0)
            mix_001.inputs[9].default_value = (0.0, 0.0, 0.0)
            color_ramp = cementbreak.nodes.new("ShaderNodeValToRGB")
            color_ramp.name = "Color Ramp"
            color_ramp.color_ramp.color_mode = 'RGB'
            color_ramp.color_ramp.hue_interpolation = 'NEAR'
            color_ramp.color_ramp.interpolation = 'LINEAR'
            color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
            color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
            color_ramp_cre_0.position = 0.0
            color_ramp_cre_0.alpha = 1.0
            color_ramp_cre_0.color = (1.0, 1.0, 1.0, 1.0)
            color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.2318180948495865)
            color_ramp_cre_1.alpha = 1.0
            color_ramp_cre_1.color = (0.0, 0.0, 0.0, 1.0)
            mix_002 = cementbreak.nodes.new("ShaderNodeMix")
            mix_002.name = "Mix.002"
            mix_002.blend_type = 'LIGHTEN'
            mix_002.clamp_factor = True
            mix_002.clamp_result = False
            mix_002.data_type = 'RGBA'
            mix_002.factor_mode = 'UNIFORM'
            mix_002.inputs[0].default_value = 0.14166666567325592
            mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
            mix_002.inputs[2].default_value = 0.0
            mix_002.inputs[3].default_value = 0.0
            mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
            mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
            mix_002.inputs[8].default_value = (0.0, 0.0, 0.0)
            mix_002.inputs[9].default_value = (0.0, 0.0, 0.0)
            color_ramp_001 = cementbreak.nodes.new("ShaderNodeValToRGB")
            color_ramp_001.name = "Color Ramp.001"
            color_ramp_001.color_ramp.color_mode = 'RGB'
            color_ramp_001.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_001.color_ramp.interpolation = 'LINEAR'
            color_ramp_001.color_ramp.elements.remove(color_ramp_001.color_ramp.elements[0])
            color_ramp_001_cre_0 = color_ramp_001.color_ramp.elements[0]
            color_ramp_001_cre_0.position = 0.35454532504081726
            color_ramp_001_cre_0.alpha = 1.0
            color_ramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)
            color_ramp_001_cre_1 = color_ramp_001.color_ramp.elements.new(0.6590911149978638)
            color_ramp_001_cre_1.alpha = 1.0
            color_ramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)
            color_ramp_002 = cementbreak.nodes.new("ShaderNodeValToRGB")
            color_ramp_002.name = "Color Ramp.002"
            color_ramp_002.color_ramp.color_mode = 'RGB'
            color_ramp_002.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_002.color_ramp.interpolation = 'LINEAR'
            color_ramp_002.color_ramp.elements.remove(color_ramp_002.color_ramp.elements[0])
            color_ramp_002_cre_0 = color_ramp_002.color_ramp.elements[0]
            color_ramp_002_cre_0.position = 0.2727271020412445
            color_ramp_002_cre_0.alpha = 1.0
            color_ramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)
            color_ramp_002_cre_1 = color_ramp_002.color_ramp.elements.new(0.61363685131073)
            color_ramp_002_cre_1.alpha = 1.0
            color_ramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)
            mix_003 = cementbreak.nodes.new("ShaderNodeMix")
            mix_003.name = "Mix.003"
            mix_003.blend_type = 'MULTIPLY'
            mix_003.clamp_factor = True
            mix_003.clamp_result = False
            mix_003.data_type = 'RGBA'
            mix_003.factor_mode = 'UNIFORM'
            mix_003.inputs[0].default_value = 0.17874985933303833
            mix_003.inputs[1].default_value = (0.5, 0.5, 0.5)
            mix_003.inputs[2].default_value = 0.0
            mix_003.inputs[3].default_value = 0.0
            mix_003.inputs[4].default_value = (0.0, 0.0, 0.0)
            mix_003.inputs[5].default_value = (0.0, 0.0, 0.0)
            mix_003.inputs[8].default_value = (0.0, 0.0, 0.0)
            mix_003.inputs[9].default_value = (0.0, 0.0, 0.0)
            mix_004 = cementbreak.nodes.new("ShaderNodeMix")
            mix_004.name = "Mix.004"
            mix_004.blend_type = 'MULTIPLY'
            mix_004.clamp_factor = True
            mix_004.clamp_result = False
            mix_004.data_type = 'RGBA'
            mix_004.factor_mode = 'UNIFORM'
            mix_004.inputs[0].default_value = 0.3333333730697632
            mix_004.inputs[1].default_value = (0.5, 0.5, 0.5)
            mix_004.inputs[2].default_value = 0.0
            mix_004.inputs[3].default_value = 0.0
            mix_004.inputs[4].default_value = (0.0, 0.0, 0.0)
            mix_004.inputs[5].default_value = (0.0, 0.0, 0.0)
            mix_004.inputs[8].default_value = (0.0, 0.0, 0.0)
            mix_004.inputs[9].default_value = (0.0, 0.0, 0.0)
            math = cementbreak.nodes.new("ShaderNodeMath")
            math.name = "Math"
            math.operation = 'MINIMUM'
            math.use_clamp = False
            math.inputs[1].default_value = 0.11000001430511475
            math.inputs[2].default_value = 0.5
            noise_texture_002 = cementbreak.nodes.new("ShaderNodeTexNoise")
            noise_texture_002.name = "Noise Texture.002"
            noise_texture_002.noise_dimensions = '3D'
            noise_texture_002.normalize = True
            noise_texture_002.inputs[1].default_value = 0.0
            noise_texture_002.inputs[2].default_value = 53.10000228881836
            noise_texture_002.inputs[3].default_value = 15.0
            noise_texture_002.inputs[4].default_value = 0.699999988079071
            noise_texture_002.inputs[5].default_value = 2.0
            noise_texture_002.inputs[6].default_value = 0.0
            noise_texture_002.inputs[7].default_value = 1.0
            noise_texture_002.inputs[8].default_value = 0.0
            mapping = cementbreak.nodes.new("ShaderNodeMapping")
            mapping.name = "Mapping"
            mapping.vector_type = 'POINT'
            mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
            mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
            bump = cementbreak.nodes.new("ShaderNodeBump")
            bump.name = "Bump"
            bump.invert = False
            bump.inputs[0].default_value = 0.4166666865348816
            bump.inputs[1].default_value = 1.0
            bump.inputs[3].default_value = (0.0, 0.0, 0.0)
            reroute = cementbreak.nodes.new("NodeReroute")
            reroute.name = "Reroute"
            value = cementbreak.nodes.new("ShaderNodeValue")
            value.name = "Value"
            value.outputs[0].default_value = 0.20000000298023224
            combine_xyz = cementbreak.nodes.new("ShaderNodeCombineXYZ")
            combine_xyz.name = "Combine XYZ"
            color_ramp_003 = cementbreak.nodes.new("ShaderNodeValToRGB")
            color_ramp_003.name = "Color Ramp.003"
            color_ramp_003.color_ramp.color_mode = 'RGB'
            color_ramp_003.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_003.color_ramp.interpolation = 'LINEAR'
            color_ramp_003.color_ramp.elements.remove(color_ramp_003.color_ramp.elements[0])
            color_ramp_003_cre_0 = color_ramp_003.color_ramp.elements[0]
            color_ramp_003_cre_0.position = 0.08636365085840225
            color_ramp_003_cre_0.alpha = 1.0
            color_ramp_003_cre_0.color = (1.0, 1.0, 1.0, 1.0)
            color_ramp_003_cre_1 = color_ramp_003.color_ramp.elements.new(0.10454563796520233)
            color_ramp_003_cre_1.alpha = 1.0
            color_ramp_003_cre_1.color = (0.6665030121803284, 0.6665030121803284, 0.6665030121803284, 1.0)
            color_ramp_004 = cementbreak.nodes.new("ShaderNodeValToRGB")
            color_ramp_004.name = "Color Ramp.004"
            color_ramp_004.color_ramp.color_mode = 'RGB'
            color_ramp_004.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_004.color_ramp.interpolation = 'LINEAR'
            color_ramp_004.color_ramp.elements.remove(color_ramp_004.color_ramp.elements[0])
            color_ramp_004_cre_0 = color_ramp_004.color_ramp.elements[0]
            color_ramp_004_cre_0.position = 0.0022728033363819122
            color_ramp_004_cre_0.alpha = 1.0
            color_ramp_004_cre_0.color = (0.2559399902820587, 0.2149450033903122, 0.1782190054655075, 1.0)
            color_ramp_004_cre_1 = color_ramp_004.color_ramp.elements.new(0.10000000149011612)
            color_ramp_004_cre_1.alpha = 1.0
            color_ramp_004_cre_1.color = (0.007591492962092161, 0.007049869745969772, 0.006925624795258045, 1.0)
            color_ramp_004_cre_2 = color_ramp_004.color_ramp.elements.new(0.7454545497894287)
            color_ramp_004_cre_2.alpha = 1.0
            color_ramp_004_cre_2.color = (0.8207942843437195, 0.6549906134605408, 0.5368729829788208, 1.0)
            color_ramp_004_cre_3 = color_ramp_004.color_ramp.elements.new(0.8443177938461304)
            color_ramp_004_cre_3.alpha = 1.0
            color_ramp_004_cre_3.color = (0.255940318107605, 0.21494503319263458, 0.17821893095970154, 1.0)
            color_ramp_004_cre_4 = color_ramp_004.color_ramp.elements.new(1.0)
            color_ramp_004_cre_4.alpha = 1.0
            color_ramp_004_cre_4.color = (0.40715470910072327, 0.4871503412723541, 0.5049578547477722, 1.0)
            reroute_001 = cementbreak.nodes.new("NodeReroute")
            reroute_001.name = "Reroute.001"
            mix_005 = cementbreak.nodes.new("ShaderNodeMix")
            mix_005.name = "Mix.005"
            mix_005.blend_type = 'MIX'
            mix_005.clamp_factor = True
            mix_005.clamp_result = False
            mix_005.data_type = 'VECTOR'
            mix_005.factor_mode = 'UNIFORM'
            mix_005.inputs[1].default_value = (0.5, 0.5, 0.5)
            mix_005.inputs[2].default_value = 0.0
            mix_005.inputs[3].default_value = 0.0
            mix_005.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
            mix_005.inputs[8].default_value = (0.0, 0.0, 0.0)
            mix_005.inputs[9].default_value = (0.0, 0.0, 0.0)
            texture_coordinate = cementbreak.nodes.new("ShaderNodeTexCoord")
            texture_coordinate.name = "Texture Coordinate"
            texture_coordinate.from_instancer = False
            group_input = cementbreak.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            noise_texture_003 = cementbreak.nodes.new("ShaderNodeTexNoise")
            noise_texture_003.name = "Noise Texture.003"
            noise_texture_003.noise_dimensions = '3D'
            noise_texture_003.normalize = True
            noise_texture_003.inputs[1].default_value = 0.0
            noise_texture_003.inputs[2].default_value = 5.0
            noise_texture_003.inputs[3].default_value = 15.0
            noise_texture_003.inputs[4].default_value = 0.574999988079071
            noise_texture_003.inputs[5].default_value = 2.0
            noise_texture_003.inputs[6].default_value = 0.0
            noise_texture_003.inputs[7].default_value = 1.0
            noise_texture_003.inputs[8].default_value = 0.0
            color_ramp_006 = cementbreak.nodes.new("ShaderNodeValToRGB")
            color_ramp_006.name = "Color Ramp.006"
            color_ramp_006.color_ramp.color_mode = 'RGB'
            color_ramp_006.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_006.color_ramp.interpolation = 'LINEAR'
            color_ramp_006.color_ramp.elements.remove(color_ramp_006.color_ramp.elements[0])
            color_ramp_006_cre_0 = color_ramp_006.color_ramp.elements[0]
            color_ramp_006_cre_0.position = 0.33636367321014404
            color_ramp_006_cre_0.alpha = 1.0
            color_ramp_006_cre_0.color = (0.23693320155143738, 0.23693320155143738, 0.23693320155143738, 1.0)
            color_ramp_006_cre_1 = color_ramp_006.color_ramp.elements.new(0.5863640308380127)
            color_ramp_006_cre_1.alpha = 1.0
            color_ramp_006_cre_1.color = (0.33585554361343384, 0.33585554361343384, 0.33585554361343384, 1.0)
            color_ramp_007 = cementbreak.nodes.new("ShaderNodeValToRGB")
            color_ramp_007.name = "Color Ramp.007"
            color_ramp_007.color_ramp.color_mode = 'RGB'
            color_ramp_007.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_007.color_ramp.interpolation = 'LINEAR'
            color_ramp_007.color_ramp.elements.remove(color_ramp_007.color_ramp.elements[0])
            color_ramp_007_cre_0 = color_ramp_007.color_ramp.elements[0]
            color_ramp_007_cre_0.position = 0.31363630294799805
            color_ramp_007_cre_0.alpha = 1.0
            color_ramp_007_cre_0.color = (0.0, 0.0, 0.0, 1.0)
            color_ramp_007_cre_1 = color_ramp_007.color_ramp.elements.new(1.0)
            color_ramp_007_cre_1.alpha = 1.0
            color_ramp_007_cre_1.color = (1.0, 1.0, 1.0, 1.0)
            color_ramp_008 = cementbreak.nodes.new("ShaderNodeValToRGB")
            color_ramp_008.name = "Color Ramp.008"
            color_ramp_008.color_ramp.color_mode = 'RGB'
            color_ramp_008.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_008.color_ramp.interpolation = 'LINEAR'
            color_ramp_008.color_ramp.elements.remove(color_ramp_008.color_ramp.elements[0])
            color_ramp_008_cre_0 = color_ramp_008.color_ramp.elements[0]
            color_ramp_008_cre_0.position = 0.0
            color_ramp_008_cre_0.alpha = 1.0
            color_ramp_008_cre_0.color = (1.0, 1.0, 1.0, 1.0)
            color_ramp_008_cre_1 = color_ramp_008.color_ramp.elements.new(0.2954545021057129)
            color_ramp_008_cre_1.alpha = 1.0
            color_ramp_008_cre_1.color = (0.0, 0.0, 0.0, 1.0)
            color_ramp_009 = cementbreak.nodes.new("ShaderNodeValToRGB")
            color_ramp_009.name = "Color Ramp.009"
            color_ramp_009.color_ramp.color_mode = 'RGB'
            color_ramp_009.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_009.color_ramp.interpolation = 'B_SPLINE'
            color_ramp_009.color_ramp.elements.remove(color_ramp_009.color_ramp.elements[0])
            color_ramp_009_cre_0 = color_ramp_009.color_ramp.elements[0]
            color_ramp_009_cre_0.position = 0.5272727608680725
            color_ramp_009_cre_0.alpha = 1.0
            color_ramp_009_cre_0.color = (0.0, 0.0, 0.0, 1.0)
            color_ramp_009_cre_1 = color_ramp_009.color_ramp.elements.new(1.0)
            color_ramp_009_cre_1.alpha = 1.0
            color_ramp_009_cre_1.color = (1.0, 1.0, 1.0, 1.0)
            mix_006 = cementbreak.nodes.new("ShaderNodeMix")
            mix_006.name = "Mix.006"
            mix_006.blend_type = 'LIGHTEN'
            mix_006.clamp_factor = True
            mix_006.clamp_result = False
            mix_006.data_type = 'RGBA'
            mix_006.factor_mode = 'UNIFORM'
            mix_006.inputs[0].default_value = 0.6083333492279053
            mix_006.inputs[1].default_value = (0.5, 0.5, 0.5)
            mix_006.inputs[2].default_value = 0.0
            mix_006.inputs[3].default_value = 0.0
            mix_006.inputs[4].default_value = (0.0, 0.0, 0.0)
            mix_006.inputs[5].default_value = (0.0, 0.0, 0.0)
            mix_006.inputs[8].default_value = (0.0, 0.0, 0.0)
            mix_006.inputs[9].default_value = (0.0, 0.0, 0.0)
            mix_007 = cementbreak.nodes.new("ShaderNodeMix")
            mix_007.name = "Mix.007"
            mix_007.blend_type = 'MIX'
            mix_007.clamp_factor = True
            mix_007.clamp_result = False
            mix_007.data_type = 'RGBA'
            mix_007.factor_mode = 'UNIFORM'
            mix_007.inputs[0].default_value = 0.06666665524244308
            mix_007.inputs[1].default_value = (0.5, 0.5, 0.5)
            mix_007.inputs[2].default_value = 0.0
            mix_007.inputs[3].default_value = 0.0
            mix_007.inputs[4].default_value = (0.0, 0.0, 0.0)
            mix_007.inputs[5].default_value = (0.0, 0.0, 0.0)
            mix_007.inputs[8].default_value = (0.0, 0.0, 0.0)
            mix_007.inputs[9].default_value = (0.0, 0.0, 0.0)
            voronoi_texture_001 = cementbreak.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture_001.name = "Voronoi Texture.001"
            voronoi_texture_001.distance = 'EUCLIDEAN'
            voronoi_texture_001.feature = 'F1'
            voronoi_texture_001.normalize = False
            voronoi_texture_001.voronoi_dimensions = '3D'
            voronoi_texture_001.inputs[1].default_value = 0.0
            voronoi_texture_001.inputs[2].default_value = 150.0
            voronoi_texture_001.inputs[3].default_value = 0.0
            voronoi_texture_001.inputs[4].default_value = 0.5
            voronoi_texture_001.inputs[5].default_value = 2.0
            voronoi_texture_001.inputs[6].default_value = 1.0
            voronoi_texture_001.inputs[7].default_value = 0.5
            voronoi_texture_001.inputs[8].default_value = 1.0
            voronoi_texture = cementbreak.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture.name = "Voronoi Texture"
            voronoi_texture.distance = 'EUCLIDEAN'
            voronoi_texture.feature = 'F1'
            voronoi_texture.normalize = False
            voronoi_texture.voronoi_dimensions = '3D'
            voronoi_texture.inputs[1].default_value = 0.0
            voronoi_texture.inputs[2].default_value = 500.0
            voronoi_texture.inputs[3].default_value = 0.0
            voronoi_texture.inputs[4].default_value = 0.5
            voronoi_texture.inputs[5].default_value = 2.0
            voronoi_texture.inputs[6].default_value = 1.0
            voronoi_texture.inputs[7].default_value = 0.5
            voronoi_texture.inputs[8].default_value = 1.0
            rgb_curves = cementbreak.nodes.new("ShaderNodeRGBCurve")
            rgb_curves.name = "RGB Curves"
            rgb_curves.mapping.extend = 'EXTRAPOLATED'
            rgb_curves.mapping.tone = 'STANDARD'
            rgb_curves.mapping.black_level = (0.0, 0.0, 0.0)
            rgb_curves.mapping.white_level = (1.0, 1.0, 1.0)
            rgb_curves.mapping.clip_min_x = 0.0
            rgb_curves.mapping.clip_min_y = 0.0
            rgb_curves.mapping.clip_max_x = 1.0
            rgb_curves.mapping.clip_max_y = 1.0
            rgb_curves.mapping.use_clip = True
            rgb_curves_curve_0 = rgb_curves.mapping.curves[0]
            rgb_curves_curve_0_point_0 = rgb_curves_curve_0.points[0]
            rgb_curves_curve_0_point_0.location = (0.0, 0.0)
            rgb_curves_curve_0_point_0.handle_type = 'AUTO'
            rgb_curves_curve_0_point_1 = rgb_curves_curve_0.points[1]
            rgb_curves_curve_0_point_1.location = (1.0, 1.0)
            rgb_curves_curve_0_point_1.handle_type = 'AUTO'
            rgb_curves_curve_1 = rgb_curves.mapping.curves[1]
            rgb_curves_curve_1_point_0 = rgb_curves_curve_1.points[0]
            rgb_curves_curve_1_point_0.location = (0.0, 0.0)
            rgb_curves_curve_1_point_0.handle_type = 'AUTO'
            rgb_curves_curve_1_point_1 = rgb_curves_curve_1.points[1]
            rgb_curves_curve_1_point_1.location = (1.0, 1.0)
            rgb_curves_curve_1_point_1.handle_type = 'AUTO'
            rgb_curves_curve_2 = rgb_curves.mapping.curves[2]
            rgb_curves_curve_2_point_0 = rgb_curves_curve_2.points[0]
            rgb_curves_curve_2_point_0.location = (0.0, 0.0)
            rgb_curves_curve_2_point_0.handle_type = 'AUTO'
            rgb_curves_curve_2_point_1 = rgb_curves_curve_2.points[1]
            rgb_curves_curve_2_point_1.location = (1.0, 1.0)
            rgb_curves_curve_2_point_1.handle_type = 'AUTO'
            rgb_curves_curve_3 = rgb_curves.mapping.curves[3]
            rgb_curves_curve_3_point_0 = rgb_curves_curve_3.points[0]
            rgb_curves_curve_3_point_0.location = (0.0, 0.0)
            rgb_curves_curve_3_point_0.handle_type = 'AUTO'
            rgb_curves_curve_3_point_1 = rgb_curves_curve_3.points[1]
            rgb_curves_curve_3_point_1.location = (0.3863637149333954, 0.5812502503395081)
            rgb_curves_curve_3_point_1.handle_type = 'AUTO'
            rgb_curves_curve_3_point_2 = rgb_curves_curve_3.points.new(1.0, 1.0)
            rgb_curves_curve_3_point_2.handle_type = 'AUTO'
            rgb_curves.mapping.update()
            rgb_curves.inputs[0].default_value = 1.0
            bump_001 = cementbreak.nodes.new("ShaderNodeBump")
            bump_001.name = "Bump.001"
            bump_001.invert = False
            bump_001.inputs[0].default_value = 1.0
            bump_001.inputs[1].default_value = 1.0
            math_001 = cementbreak.nodes.new("ShaderNodeMath")
            math_001.name = "Math.001"
            math_001.operation = 'MINIMUM'
            math_001.use_clamp = False
            math_001.inputs[1].default_value = 0.5
            math_001.inputs[2].default_value = 0.5
            color_ramp_005 = cementbreak.nodes.new("ShaderNodeValToRGB")
            color_ramp_005.name = "Color Ramp.005"
            color_ramp_005.color_ramp.color_mode = 'RGB'
            color_ramp_005.color_ramp.hue_interpolation = 'NEAR'
            color_ramp_005.color_ramp.interpolation = 'LINEAR'
            color_ramp_005.color_ramp.elements.remove(color_ramp_005.color_ramp.elements[0])
            color_ramp_005_cre_0 = color_ramp_005.color_ramp.elements[0]
            color_ramp_005_cre_0.position = 0.2590910792350769
            color_ramp_005_cre_0.alpha = 1.0
            color_ramp_005_cre_0.color = (0.0, 0.0, 0.0, 1.0)
            color_ramp_005_cre_1 = color_ramp_005.color_ramp.elements.new(0.7590910196304321)
            color_ramp_005_cre_1.alpha = 1.0
            color_ramp_005_cre_1.color = (1.0, 1.0, 1.0, 1.0)
            noise_texture_004 = cementbreak.nodes.new("ShaderNodeTexNoise")
            noise_texture_004.name = "Noise Texture.004"
            noise_texture_004.noise_dimensions = '3D'
            noise_texture_004.normalize = True
            noise_texture_004.inputs[0].default_value = (0.0, 0.0, 0.0)
            noise_texture_004.inputs[1].default_value = 0.0
            noise_texture_004.inputs[2].default_value = 5.0
            noise_texture_004.inputs[3].default_value = 2.0
            noise_texture_004.inputs[4].default_value = 0.5
            noise_texture_004.inputs[5].default_value = 2.0
            noise_texture_004.inputs[6].default_value = 0.0
            noise_texture_004.inputs[7].default_value = 1.0
            noise_texture_004.inputs[8].default_value = 0.0
            musgrave_texture_001 = cementbreak.nodes.new("ShaderNodeTexNoise")
            musgrave_texture_001.name = "Musgrave Texture.001"
            musgrave_texture_001.noise_dimensions = '3D'
            musgrave_texture_001.normalize = False
            musgrave_texture_001.inputs[0].default_value = (0.0, 0.0, 0.0)
            musgrave_texture_001.inputs[1].default_value = 0.0
            musgrave_texture_001.inputs[2].default_value = 1.100000023841858
            musgrave_texture_001.inputs[3].default_value = 14.0
            musgrave_texture_001.inputs[4].default_value = 0.999993085861206
            musgrave_texture_001.inputs[5].default_value = 2.0
            musgrave_texture_001.inputs[6].default_value = 0.0
            musgrave_texture_001.inputs[7].default_value = 1.0
            musgrave_texture_001.inputs[8].default_value = 0.0
            musgrave_texture = cementbreak.nodes.new("ShaderNodeTexNoise")
            musgrave_texture.name = "Musgrave Texture"
            musgrave_texture.noise_dimensions = '3D'
            musgrave_texture.normalize = True
            musgrave_texture.inputs[1].default_value = 0.0
            musgrave_texture.inputs[2].default_value = 1.1000001430511475
            musgrave_texture.inputs[3].default_value = 14.0
            musgrave_texture.inputs[4].default_value = 0.999993085861206
            musgrave_texture.inputs[5].default_value = 2.0
            musgrave_texture.inputs[6].default_value = 0.0
            musgrave_texture.inputs[7].default_value = 1.0
            musgrave_texture.inputs[8].default_value = 0.0
            voronoi_texture_002 = cementbreak.nodes.new("ShaderNodeTexVoronoi")
            voronoi_texture_002.name = "Voronoi Texture.002"
            voronoi_texture_002.distance = 'EUCLIDEAN'
            voronoi_texture_002.feature = 'F1'
            voronoi_texture_002.normalize = False
            voronoi_texture_002.voronoi_dimensions = '3D'
            voronoi_texture_002.inputs[1].default_value = 0.0
            voronoi_texture_002.inputs[2].default_value = 800.0
            voronoi_texture_002.inputs[3].default_value = 0.0
            voronoi_texture_002.inputs[4].default_value = 0.5
            voronoi_texture_002.inputs[5].default_value = 2.0
            voronoi_texture_002.inputs[6].default_value = 1.0
            voronoi_texture_002.inputs[7].default_value = 0.5
            voronoi_texture_002.inputs[8].default_value = 1.0
            group_output.location = (2409.496826171875, 4.700616836547852)
            mix.location = (-844.4622192382812, -538.8814697265625)
            noise_texture.location = (-1403.7320556640625, -519.2730102539062)
            noise_texture_001.location = (-1326.6405029296875, -225.45562744140625)
            mix_001.location = (-421.4544372558594, -54.34210968017578)
            color_ramp.location = (-850.6197509765625, 375.56072998046875)
            mix_002.location = (-256.724609375, 243.79571533203125)
            color_ramp_001.location = (-560.8272094726562, 729.0387573242188)
            color_ramp_002.location = (57.46995162963867, 967.9020385742188)
            mix_003.location = (88.06507873535156, 387.72674560546875)
            mix_004.location = (550.5994873046875, 742.3153686523438)
            math.location = (1107.6500244140625, -261.4668884277344)
            noise_texture_002.location = (-1401.4647216796875, -768.8474731445312)
            mapping.location = (-1692.6632080078125, 224.735107421875)
            bump.location = (1472.7996826171875, -466.57196044921875)
            reroute.location = (1623.5645751953125, -243.13201904296875)
            value.location = (-2066.258544921875, -348.52459716796875)
            combine_xyz.location = (-1811.5931396484375, -195.94989013671875)
            color_ramp_003.location = (1790.8411865234375, -396.80963134765625)
            color_ramp_004.location = (1684.4586181640625, -82.11823272705078)
            reroute_001.location = (-1854.75927734375, -310.3528137207031)
            mix_005.location = (-1970.712646484375, 311.1589050292969)
            texture_coordinate.location = (-2236.6181640625, 320.6774597167969)
            group_input.location = (-2266.258544921875, 4.700616836547852)
            noise_texture_003.location = (234.682373046875, -1094.6790771484375)
            color_ramp_006.location = (-1203.8450927734375, -515.0584106445312)
            color_ramp_007.location = (-1201.57763671875, -764.6328735351562)
            color_ramp_008.location = (-827.7008056640625, 67.38945770263672)
            color_ramp_009.location = (-1126.7532958984375, -221.24102783203125)
            mix_006.location = (-664.2039184570312, -297.24774169921875)
            mix_007.location = (769.6298217773438, -959.9237060546875)
            voronoi_texture_001.location = (-1204.466552734375, 573.1106567382812)
            voronoi_texture.location = (-1068.8079833984375, 232.26422119140625)
            rgb_curves.location = (1961.732421875, 272.9335632324219)
            bump_001.location = (1829.7840576171875, -723.1909790039062)
            math_001.location = (1326.8433837890625, -958.500732421875)
            color_ramp_005.location = (435.0121765136719, -1092.592529296875)
            noise_texture_004.location = (-527.187744140625, -805.3812255859375)
            musgrave_texture_001.location = (-534.8563842773438, -539.6189575195312)
            musgrave_texture.location = (-208.22140502929688, 942.1309204101562)
            voronoi_texture_002.location = (-814.999755859375, 701.1802978515625)
            group_output.width, group_output.height = 140.0, 100.0
            mix.width, mix.height = 140.0, 100.0
            noise_texture.width, noise_texture.height = 140.0, 100.0
            noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
            mix_001.width, mix_001.height = 140.0, 100.0
            color_ramp.width, color_ramp.height = 240.0, 100.0
            mix_002.width, mix_002.height = 140.0, 100.0
            color_ramp_001.width, color_ramp_001.height = 240.0, 100.0
            color_ramp_002.width, color_ramp_002.height = 240.0, 100.0
            mix_003.width, mix_003.height = 140.0, 100.0
            mix_004.width, mix_004.height = 140.0, 100.0
            math.width, math.height = 140.0, 100.0
            noise_texture_002.width, noise_texture_002.height = 140.0, 100.0
            mapping.width, mapping.height = 140.0, 100.0
            bump.width, bump.height = 140.0, 100.0
            reroute.width, reroute.height = 16.0, 100.0
            value.width, value.height = 140.0, 100.0
            combine_xyz.width, combine_xyz.height = 140.0, 100.0
            color_ramp_003.width, color_ramp_003.height = 240.0, 100.0
            color_ramp_004.width, color_ramp_004.height = 240.0, 100.0
            reroute_001.width, reroute_001.height = 16.0, 100.0
            mix_005.width, mix_005.height = 140.0, 100.0
            texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
            group_input.width, group_input.height = 140.0, 100.0
            noise_texture_003.width, noise_texture_003.height = 140.0, 100.0
            color_ramp_006.width, color_ramp_006.height = 240.0, 100.0
            color_ramp_007.width, color_ramp_007.height = 240.0, 100.0
            color_ramp_008.width, color_ramp_008.height = 240.0, 100.0
            color_ramp_009.width, color_ramp_009.height = 240.0, 100.0
            mix_006.width, mix_006.height = 140.0, 100.0
            mix_007.width, mix_007.height = 140.0, 100.0
            voronoi_texture_001.width, voronoi_texture_001.height = 140.0, 100.0
            voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
            rgb_curves.width, rgb_curves.height = 240.0, 100.0
            bump_001.width, bump_001.height = 140.0, 100.0
            math_001.width, math_001.height = 140.0, 100.0
            color_ramp_005.width, color_ramp_005.height = 240.0, 100.0
            noise_texture_004.width, noise_texture_004.height = 140.0, 100.0
            musgrave_texture_001.width, musgrave_texture_001.height = 150.0, 100.0
            musgrave_texture.width, musgrave_texture.height = 150.0, 100.0
            voronoi_texture_002.width, voronoi_texture_002.height = 140.0, 100.0
            cementbreak.links.new(mapping.outputs[0], noise_texture_003.inputs[0])
            cementbreak.links.new(bump.outputs[0], bump_001.inputs[3])
            cementbreak.links.new(color_ramp_006.outputs[0], mix.inputs[6])
            cementbreak.links.new(reroute_001.outputs[0], combine_xyz.inputs[2])
            cementbreak.links.new(reroute_001.outputs[0], combine_xyz.inputs[0])
            cementbreak.links.new(combine_xyz.outputs[0], mapping.inputs[3])
            cementbreak.links.new(voronoi_texture.outputs[0], color_ramp_008.inputs[0])
            cementbreak.links.new(mix_007.outputs[2], math_001.inputs[0])
            cementbreak.links.new(color_ramp_001.outputs[0], mix_003.inputs[7])
            cementbreak.links.new(color_ramp_009.outputs[0], mix_006.inputs[7])
            cementbreak.links.new(voronoi_texture_002.outputs[0], color_ramp_001.inputs[0])
            cementbreak.links.new(noise_texture_003.outputs[0], color_ramp_005.inputs[0])
            cementbreak.links.new(mix_003.outputs[2], mix_004.inputs[6])
            cementbreak.links.new(reroute.outputs[0], color_ramp_004.inputs[0])
            cementbreak.links.new(color_ramp_002.outputs[0], mix_004.inputs[7])
            cementbreak.links.new(color_ramp_004.outputs[0], rgb_curves.inputs[1])
            cementbreak.links.new(musgrave_texture.outputs[0], color_ramp_002.inputs[0])
            cementbreak.links.new(color_ramp_008.outputs[0], mix_001.inputs[7])
            cementbreak.links.new(mapping.outputs[0], musgrave_texture.inputs[0])
            cementbreak.links.new(noise_texture.outputs[0], color_ramp_006.inputs[0])
            cementbreak.links.new(reroute_001.outputs[0], combine_xyz.inputs[1])
            cementbreak.links.new(mapping.outputs[0], noise_texture_002.inputs[0])
            cementbreak.links.new(noise_texture_002.outputs[0], color_ramp_007.inputs[0])
            cementbreak.links.new(mapping.outputs[0], voronoi_texture_001.inputs[0])
            cementbreak.links.new(mix.outputs[2], mix_006.inputs[6])
            cementbreak.links.new(mapping.outputs[0], noise_texture_001.inputs[0])
            cementbreak.links.new(mapping.outputs[0], noise_texture.inputs[0])
            cementbreak.links.new(mix_001.outputs[2], mix_002.inputs[6])
            cementbreak.links.new(math.outputs[0], bump.inputs[2])
            cementbreak.links.new(math_001.outputs[0], bump_001.inputs[2])
            cementbreak.links.new(mix_006.outputs[2], mix_001.inputs[6])
            cementbreak.links.new(mix_004.outputs[2], reroute.inputs[0])
            cementbreak.links.new(mapping.outputs[0], voronoi_texture_002.inputs[0])
            cementbreak.links.new(reroute.outputs[0], color_ramp_003.inputs[0])
            cementbreak.links.new(mix_004.outputs[2], math.inputs[0])
            cementbreak.links.new(color_ramp.outputs[0], mix_002.inputs[7])
            cementbreak.links.new(color_ramp_007.outputs[0], mix.inputs[7])
            cementbreak.links.new(mapping.outputs[0], voronoi_texture.inputs[0])
            cementbreak.links.new(voronoi_texture_001.outputs[0], color_ramp.inputs[0])
            cementbreak.links.new(mix_002.outputs[2], mix_003.inputs[6])
            cementbreak.links.new(noise_texture_001.outputs[0], color_ramp_009.inputs[0])
            cementbreak.links.new(bump_001.outputs[0], group_output.inputs[2])
            cementbreak.links.new(color_ramp_003.outputs[0], group_output.inputs[1])
            cementbreak.links.new(rgb_curves.outputs[0], group_output.inputs[0])
            cementbreak.links.new(group_input.outputs[0], reroute_001.inputs[0])
            cementbreak.links.new(texture_coordinate.outputs[0], mix_005.inputs[6])
            cementbreak.links.new(texture_coordinate.outputs[0], mix_005.inputs[4])
            cementbreak.links.new(texture_coordinate.outputs[2], mix_005.inputs[5])
            cementbreak.links.new(group_input.outputs[1], mix_005.inputs[0])
            cementbreak.links.new(mix_005.outputs[1], mapping.inputs[0])
            cementbreak.links.new(color_ramp_005.outputs[0], mix_007.inputs[6])
            cementbreak.links.new(color_ramp_009.outputs[0], mix_007.inputs[7])
            cementbreak.links.new(color_ramp_005.outputs[0], group_output.inputs[3])        
        if mat_name not in ng:
            mat = bpy.data.materials.new(name = "NC_Broken-Concrete")
            mat.use_nodes = True            
            nc_broken_concrete = mat.node_tree
            for node in mat.node_tree.nodes:
                nc_broken_concrete.nodes.remove(node)
            material_output = nc_broken_concrete.nodes.new("ShaderNodeOutputMaterial")
            material_output.name = "Material Output"
            material_output.is_active_output = True
            material_output.target = 'ALL'
            material_output.inputs[2].default_value = (0.0, 0.0, 0.0)
            material_output.inputs[3].default_value = 0.0
            group = nc_broken_concrete.nodes.new("ShaderNodeGroup")
            group.name = "Group"
            group.node_tree = bpy.data.node_groups['CementBreak']
            group.inputs[0].default_value = 0.3
            group.inputs[1].default_value = 0
            principled_bsdf = nc_broken_concrete.nodes.new("ShaderNodeBsdfPrincipled")
            principled_bsdf.name = "Principled BSDF"
            principled_bsdf.distribution = 'MULTI_GGX'
            principled_bsdf.subsurface_method = 'RANDOM_WALK'
            principled_bsdf.inputs[1].default_value = 0.0
            principled_bsdf.inputs[3].default_value = 1.4500000476837158
            principled_bsdf.inputs[4].default_value = 1.0
            principled_bsdf.inputs[6].default_value = 0.0
            principled_bsdf.inputs[7].default_value = 0.0
            principled_bsdf.inputs[8].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
            principled_bsdf.inputs[9].default_value = 0.05000000074505806
            principled_bsdf.inputs[10].default_value = 1.399999976158142
            principled_bsdf.inputs[11].default_value = 0.0
            principled_bsdf.inputs[12].default_value = 0.5
            principled_bsdf.inputs[13].default_value = (1.0, 1.0, 1.0, 1.0)
            principled_bsdf.inputs[14].default_value = 0.0
            principled_bsdf.inputs[15].default_value = 0.0
            principled_bsdf.inputs[16].default_value = (0.0, 0.0, 0.0)
            principled_bsdf.inputs[17].default_value = 0.0
            principled_bsdf.inputs[18].default_value = 0.0
            principled_bsdf.inputs[19].default_value = 0.029999999329447746
            principled_bsdf.inputs[20].default_value = 1.5
            principled_bsdf.inputs[21].default_value = (1.0, 1.0, 1.0, 1.0)
            principled_bsdf.inputs[22].default_value = (0.0, 0.0, 0.0)
            principled_bsdf.inputs[23].default_value = 0.0
            principled_bsdf.inputs[24].default_value = 0.5
            principled_bsdf.inputs[25].default_value = (1.0, 1.0, 1.0, 1.0)
            principled_bsdf.inputs[26].default_value = (1.0, 1.0, 1.0, 1.0)
            principled_bsdf.inputs[27].default_value = 0.0
            principled_bsdf.inputs[28].default_value = 0.0
            principled_bsdf.inputs[29].default_value = 1.3300000429153442
            material_output.location = (3554.216796875, 898.7608642578125)
            group.location = (2579.33447265625, 703.7049560546875)
            principled_bsdf.location = (3074.401611328125, 694.834716796875)
            material_output.width, material_output.height = 140.0, 100.0
            group.width, group.height = 251.53857421875, 100.0
            principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
            nc_broken_concrete.links.new(group.outputs[2], principled_bsdf.inputs[5])
            nc_broken_concrete.links.new(group.outputs[1], principled_bsdf.inputs[2])
            nc_broken_concrete.links.new(group.outputs[0], principled_bsdf.inputs[0])
            nc_broken_concrete.links.new(principled_bsdf.outputs[0], material_output.inputs[0])
            return{'FINISHED'}  

            
class RESET_button(bpy.types.Operator):
    bl_idname = "wm.reset"
    bl_label = "Reset material"
    bl_description ="Reset Noisy Cutter custom materials"
    def execute(self, context):
        
        mat_name="NC_Broken-Concrete"
        ng = bpy.data.materials
        if mat_name in ng:
            material = bpy.data.materials.get(mat_name)
            material.name="NC_Broken-Concrete-RESETED"   
            print("NC_Broken-Concrete reseted")   
            
        mat_name="NC_Preview"
        ng = bpy.data.materials
        if mat_name in ng:
            material = bpy.data.materials.get(mat_name)
            material.name="NC_Preview-RESETED"   
            print("NC_Preview reseted")  

        mat_name="NC_Temp"
        ng = bpy.data.materials
        if mat_name in ng:
            material = bpy.data.materials.get(mat_name)
            material.name="NC_Temp-RESETED"   
            print("NC_Temp reseted") 
                        
                                
        return{'FINISHED'}                        
                                    
class RESET2_button(bpy.types.Operator):
    bl_idname = "wm.reset2"
    bl_label = "Reset tools"
    bl_description ="Reset Noisy Cutter operation. Use it only if something gone wrong"
    def execute(self, context):
                                
        if 'NC_cutternodes' in bpy.data.node_groups:
            group = bpy.data.node_groups['NC_cutternodes']
            group.name='NC_cutternodes-RESETED'   
            print("Geometry Node cutternode reseted")   
        
        if 'CUTTER' in bpy.data.objects:
            cutter = bpy.data.objects.get('CUTTER')
            cutter.name= 'CUTTER-RESETED'
            bpy.data.objects.remove(cutter, do_unlink=True)
            print("CUTTER object deleted")   
                      
        if 'CUTTER_profil' in bpy.data.objects:
            cutter_p = bpy.data.objects.get('CUTTER_profil')
            cutter_p.name= 'CUTTER_profil-RESETED'
            bpy.data.objects.remove(cutter_p, do_unlink=True)
            print("CUTTER_profil curve deleted")   
                                
        return{'FINISHED'}                        
                        
# ------------------------------------------------------------------------
#    Menus
# ------------------------------------------------------------------------


# ------------------------------------------------------------------------
#    Panel in Object Mode
# ------------------------------------------------------------------------
class NoizyCuttPanel:

    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "FRACTURE"
    #bl_context = "objectmode"  
    
class NCMAIN_PT_PANEL(NoizyCuttPanel, bpy.types.Panel):
    bl_idname = "NCMAIN_PT_PANEL"
    bl_label = "NOISY-CUTTER 1.8"
    
                




#    @classmethod
#    def poll(self,context):
#        return context.object is not None

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        my_prop = scene.my_prop
        
        ##### INSTRUCTIONS ###############################
        obj = bpy.context.active_object


        row = layout.row(align=True) 
        curv = [obj for obj in bpy.context.scene.objects if obj.name.startswith("CUTTER_profil")]
        cutt = [obj for obj in bpy.context.scene.objects if obj.name.startswith("CUTTER")]
            
        col = layout.column(align=True)        
        row = layout.row(align=True)    


        
        if bpy.data.objects.get("CUTTER_profil")is None and bpy.data.objects.get("CUTTER") is None:
            row = layout.row(align=True)          
            row.operator("wm.decal",icon='GREASEPENCIL')
            row.scale_y=3
        
        if bpy.data.objects.get("CUTTER_profil") is not None:
            row = layout.row(align=True)  
            row.operator("wm.mesher2",icon='MESH_GRID')
            row.scale_y=3
        if bpy.data.objects.get("CUTTER") is not None and context.active_object.mode == 'EDIT':
            row = layout.row(align=True)  
            row.operator("wm.mesher2",depress=True,icon='MESH_GRID')
            row.scale_y=3
        if bpy.data.objects.get("CUTTER") is not None and context.active_object.mode != 'EDIT':
            row = layout.row(align=True)  
            #row.operator("wm.boolcut",icon='MOD_BOOLEAN')
            
            row.operator("wm.boolcut3",icon='MOD_BOOLEAN')
            row.operator("wm.boolcut2",icon='MOD_BOOLEAN')
            row.scale_y=3
            row = layout.row(align=True)   
            row.operator("wm.reset2",text='Cancel Operation')


            
        if bpy.data.objects.get("CUTTER") is not None:
            if bpy.data.node_groups["NC_cutternodes"].nodes["Set Spline Cyclic"].inputs[2].default_value == False:  
                row = layout.row(align=True)                        
                row.operator("wm.cyc",depress=False,text="Cyclic : off")
                row.scale_y=1
            else:
                row = layout.row(align=True)  
                row.operator("wm.cyc",depress=True,text="Cyclic : on")                
                row.scale_y=1
        



        row = layout.row(align=True)  
        row.prop(my_prop, "my_del")
        #row.prop(my_prop, "my_del2")
        #row.prop(my_prop, "my_boo")


        box = layout.box()
        split = box.split()
        col = split.column(align=True)        
        row = col.row(align=True)
            
          
        row.label(text="Cutter:",icon='GRID')
        row = col.row(align=True)   
        row.prop(my_prop, "my_dens")
        row = col.row(align=True)   
        row.prop(my_prop, "my_dep")
        row.prop(my_prop, "my_dep2")
        row = col.row(align=True)  
        row.label(text="Cut Material:",icon='MATERIAL')
        row.prop(my_prop, "my_enum")
        
        mat_name="NC_Broken-Concrete"
        ng = bpy.data.materials
        if mat_name not in ng:
            row = col.row(align=True)  
            row.operator("wm.mat")
        

class DISPL_PT_PANEL(NoizyCuttPanel, bpy.types.Panel):
    bl_parent_id = "NCMAIN_PT_PANEL"
    bl_label = "Displacement"
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        my_prop = scene.my_prop    
    
        col = layout.column(align=True)        
        row = layout.row(align=True)     

        row.label(text="Noise:",icon='TEXTURE_DATA')
        row = layout.row(align=True)   
        row.prop(my_prop, "my_noiz")
        row.prop(my_prop, "my_scal")
      
        row = layout.row(align=True)  
        row = layout.row(align=True)   
        row.label(text="Texture:",icon='IMAGE_DATA')
        row = layout.row(align=True)   
        row.prop(my_prop, "my_path")
        row.operator("wm.upd",icon='FILE_REFRESH')
        row = layout.row(align=True)   
        row.prop(my_prop, "my_disp")        
        row.prop(my_prop, "my_scale2") 
        row = layout.row(align=True)          
        row.prop(my_prop, "my_rot")


class UTILS_PT_PANEL(NoizyCuttPanel, bpy.types.Panel):
    bl_parent_id = "NCMAIN_PT_PANEL"
    bl_label = "Utils"
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        my_prop = scene.my_prop    
    

        col = layout.column(align=True)        
        row = layout.row(align=True)
        row.operator("wm.wir")
        row = layout.row(align=True)
        row.operator("wm.split",icon='MOD_INSTANCE')
        row.operator("wm.orig",icon='OBJECT_ORIGIN')
        row = layout.row(align=True)
        row.operator("wm.reset")
        row.operator("wm.reset2")
        


        
        
        



# ------------------------------------------------------------------------
#    Registration
# ------------------------------------------------------------------------

classes = (
    MyProperties,
    NCMAIN_PT_PANEL,
    DISPL_PT_PANEL,
    UTILS_PT_PANEL,
    DRAW_button,
    MESHER2_button,
    BOOL_button,
    BOOL2_button,
    BOOL3_button,
    SPLIT_button,
    ORIG_button,
    UPD_button,
    WIR_button,
    CYC_button,
    MAT_button,
    RESET_button,
    RESET2_button,

)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    bpy.types.Scene.my_prop = PointerProperty(type=MyProperties)


def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    del bpy.types.Scene.my_prop
    



if __name__ == "__main__":
    register()