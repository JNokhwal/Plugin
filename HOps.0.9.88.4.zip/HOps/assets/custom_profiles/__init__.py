import os


def profile_path():
    return os.path.dirname(__file__)