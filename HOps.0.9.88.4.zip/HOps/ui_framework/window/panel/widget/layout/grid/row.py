

class Row():

    def __init__(self):

        self.height_percent = 0
        self.columns = []