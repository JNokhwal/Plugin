# -*- coding:utf-8 -*-

# ProFlow Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>


import bpy

##------------------------------------------------------  
#
# Funtions
#
##------------------------------------------------------

def get_addon_preferences():
    addon_key = __package__.split(".")[0]
    return bpy.context.preferences.addons[addon_key].preferences

def set_ref_obj(self, context):
    if len(context.selected_objects) == 1:
        for o in context.selected_objects:
            self.ref_obj = o

def apply_modifiers(self, context):
    self.act_obj = context.active_object

    for obj in context.selected_objects:
        if obj.modifiers:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            for mod in obj.modifiers:
                if mod.type == 'MIRROR':
                    continue
                bpy.ops.object.modifier_apply(modifier=mod.name)

    self.act_obj.select_set(state=True)
    context.view_layer.objects.active = self.act_obj

def update_shading(self, context):
    shading = context.space_data.shading

    if self.shading == 'studio':
        self.update_shading_icons = 'studio'
        shading.light = 'STUDIO'
        shading.color_type = 'MATERIAL'

    elif self.shading == 'matcap':
        self.update_shading_icons = 'matcap'
        shading.light = 'MATCAP'
        shading.color_type = 'MATERIAL'

    elif self.shading == 'flat':
        self.update_shading_icons = 'flat'
        shading.light = 'FLAT'
        shading.color_type = 'SINGLE'

def update_shading_icons(self, context):
    shading = context.space_data.shading

    if self.shading_icons == 'studio':
        self.shading = 'studio'
        shading.light = 'STUDIO'
        shading.color_type = 'MATERIAL'

    elif self.shading_icons == 'matcap':
        self.shading = 'matcap'
        shading.light = 'MATCAP'
        shading.color_type = 'MATERIAL'

    elif self.shading_icons == 'flat':
        self.shading = 'flat'
        shading.light = 'FLAT'
        shading.color_type = 'SINGLE'

def hide_all_modifiers(self, context):
    """SHOW/HIDE MODIFIERS"""

    for obj in context.selected_objects:
        if obj.type != 'MESH':
            continue
        for mod in obj.modifiers:
            mod.show_viewport = self.hide_all_modifiers_prop

def muscles_tickness(self, context):
    """SHOW/HIDE MODIFIERS"""
    self.act_obj = context.active_object
    self.sel = [obj for obj in context.selected_objects if obj.type == 'MESH']

    bpy.ops.object.select_all(action='DESELECT')

    for obj in self.sel:
        if obj.type != 'MESH':
            continue
        context.view_layer.objects.active = obj
        obj.select_set(state=True)
        for mod in obj.modifiers:
            if mod.type == 'SOLIDIFY':
                mod.thickness = self.edit_muscles_tickness

    context.view_layer.objects.active = self.act_obj
    self.act_obj.select_set(state=True)

def muscles_offset(self, context):
    """SHOW/HIDE MODIFIERS"""
    self.act_obj = context.active_object
    self.sel = [obj for obj in context.selected_objects if obj.type == 'MESH']

    bpy.ops.object.select_all(action='DESELECT')

    for obj in self.sel:
        if obj.type != 'MESH':
            continue
        context.view_layer.objects.active = obj
        obj.select_set(state=True)
        for mod in obj.modifiers:
            if mod.type == 'SOLIDIFY':
                mod.offset = self.edit_muscles_offset

    context.view_layer.objects.active = self.act_obj
    self.act_obj.select_set(state=True)

def muscles_factor(self, context):
    """SHOW/HIDE MODIFIERS"""
    self.act_obj = context.active_object
    self.sel = [obj for obj in context.selected_objects if obj.type == 'MESH']

    bpy.ops.object.select_all(action='DESELECT')

    for obj in self.sel:
        if obj.type != 'MESH':
            continue
        context.view_layer.objects.active = obj
        obj.select_set(state=True)
        for mod in obj.modifiers:
            if mod.type == 'SOLIDIFY':
                mod.thickness_vertex_group = self.edit_muscles_factor

    context.view_layer.objects.active = self.act_obj
    self.act_obj.select_set(state=True)

def show_hide_mirror_visibility(self, context):
    """SHOW/HIDE MODIFIERS"""
    self.act_obj = context.active_object
    self.sel = [obj for obj in context.selected_objects]

    bpy.ops.object.select_all(action='DESELECT')

    for obj in self.sel:
        context.view_layer.objects.active = obj
        obj.select_set(state=True)
        for mod in obj.modifiers:
            if mod.type == 'MIRROR':
                mod.show_viewport = self.hide_mirror_modifiers_prop

    context.view_layer.objects.active = self.act_obj
    self.act_obj.select_set(state=True)

