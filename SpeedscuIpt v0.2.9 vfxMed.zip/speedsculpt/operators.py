# -*- coding:utf-8 -*-

# SPEEDSCULPT Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
import os
import bmesh
import sys
from .functions import *
from math import radians
from bpy.types import Operator, Macro
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty)


##------------------------------------------------------
#
# Save Tmp
#
##------------------------------------------------------
def save_tmp():
    """ Save the current blend in the blender tmp file """
    tmp = os.path.join(bpy.app.tempdir, "speedsculpt_backup.blend")
    bpy.ops.wm.save_as_mainfile(copy=True, filepath=tmp, check_existing=False)

class SPEEDSCULPT_OT_cutter_primitives(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_cutter_primitives'
    bl_label = "CUTTER PRIMITIVES"
    bl_description = "Cut the Mesh or create a new one with Primitives"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    launch_cutter_primitives: EnumProperty(
        items=(('rectangle', " ", "Cut or create with a Rectangle", "MESH_PLANE", 0),
               ('vertex', " ", "Cut or create with a Shape", "HANDLE_VECTOR", 1),
               ('curve', " ", "Cut or create with a Curve", "MOD_CURVE", 2),
               ('sphere', " ", "Cut or create with a Sphere", "MESH_UVSPHERE", 3),
               ('cylinder', " ", "Cut or create with a Cylinder", "MESH_CYLINDER", 4),
               ('cube', " ", "Cut or create with a Cube", "MESH_CUBE", 5),
               ('circle', " ", "Cut or create with a Circle", "MESH_CIRCLE", 6)),
        default='rectangle') # type: ignore

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()
        if self.launch_cutter_primitives == 'rectangle':
            speedsculpt.cutter_primitives = 'rectangle'
        elif self.launch_cutter_primitives == 'vertex':
            speedsculpt.cutter_primitives = 'vertex'
        elif self.launch_cutter_primitives == 'curve':
            speedsculpt.cutter_primitives = 'curve'
        elif self.launch_cutter_primitives == 'sphere':
            speedsculpt.cutter_primitives = 'sphere'
        elif self.launch_cutter_primitives == 'cylinder':
            speedsculpt.cutter_primitives = 'cylinder'
        elif self.launch_cutter_primitives == 'cube':
            speedsculpt.cutter_primitives = 'cube'
        elif self.launch_cutter_primitives == 'circle':
            speedsculpt.cutter_primitives = 'circle'

        bpy.ops.object.speedsculpt_cutter('INVOKE_DEFAULT')

        return {'FINISHED'}

class SPEEDSCULPT_OT_add_assets_to_scene(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_add_assets_to_scene'
    bl_label = "ADD ASSETS"
    bl_description = "Add Assets from the Library to the scene"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()

        if context.object is None:
            speedsculpt.primitives_parenting = False

        actObj = context.active_object

        if context.object is not None:
            bpy.ops.object.mode_set(mode='OBJECT')

        if context.object is None and not speedsculpt.ref_obj:
            speedsculpt.add_mirror = False

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
        elif speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_cursor_to_selected()

        bpy.ops.object.speedsculpt_assets_add()
        new_obj = context.active_object

        if speedsculpt.create_primitives == 'cursor':
            if speedsculpt.copy_cursor_orientation:
                new_obj.rotation_euler = context.scene.cursor.rotation_euler.copy()
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        elif speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        elif speedsculpt.create_primitives == 'origin':
            context.scene.cursor.location[:] = (0, 0, 0)
            context.scene.cursor.rotation_euler[:] = (0, 0, 0)
            new_obj.location[:] = (0, 0, 0)



        if speedsculpt.add_mirror:
            if context.object is None:
                self.report({'INFO'}, "Select Mirror Object First", icon='ERROR')
            else:
                mod_mirror = new_obj.modifiers.new("Mirror", 'MIRROR')
                mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
                for prop, axis_index in mirror_axes.items():
                    if getattr(speedsculpt, prop):
                        mod_mirror.use_axis[axis_index] = True
                if speedsculpt.ref_obj:
                    mod_mirror.mirror_object = speedsculpt.ref_obj
                elif len([obj for obj in context.selected_objects]) == 1:
                    mod_mirror.mirror_object = actObj

        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                actObj.select_set(state=True)
                context.view_layer.objects.active = actObj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                actObj.select_set(state=False)
                new_obj.select_set(state=True)
                context.view_layer.objects.active = new_obj

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.transform.translate('INVOKE_DEFAULT')

        return {'FINISHED'}

def snap_faces(self, context):
    bpy.context.scene.tool_settings.use_snap = not bpy.context.scene.tool_settings.use_snap
    if bpy.app.version < (4, 2, 0):
        context.scene.tool_settings.snap_elements = {'FACE'}
    else:
        context.scene.tool_settings.snap_elements = {'FACE'}
    context.scene.tool_settings.use_snap_align_rotation = True
    bpy.context.scene.tool_settings.snap_target = 'MEDIAN'

def has_mirror_modifier(obj):
    # Check if the object exists and has modifiers
    if obj and obj.modifiers:
        # Check if any modifier is of type 'MIRROR'
        return any(mod.type == 'MIRROR' for mod in obj.modifiers)

    return False

def process_selected_objects(context):
    selected_objects = list(context.selected_objects)

    for obj in selected_objects:
        if obj.data.users > 1:
            bpy.ops.object.make_single_user(object=True, obdata=True, material=False, animation=False)

        if obj.get("speedsculpt_muscles"):
            del obj["speedsculpt_muscles"]

        if obj.type == 'ARMATURE':
            bpy.ops.object.convert_armature()

        if obj.type in {'CURVE', 'FONT', 'META'}:
            if obj.mode!= 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.convert(target='MESH')

def toggle_dynamic_topology_sculpt(context):
    for obj in context.selected_objects:
        # Switch to sculpt mode
        context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='SCULPT')

        # Toggle dynamic topology sculpting
        if obj.use_dynamic_topology_sculpting:
            bpy.ops.sculpt.dynamic_topology_toggle()

        # Switch back to object mode
        bpy.ops.object.mode_set(mode='OBJECT')

def contains_extracted_suffix():
    # Parcourir tous les objets sélectionnés
    for obj in bpy.context.selected_objects:
        if "_EXTRACTED" in obj.name:
            return True  # Trouvé un objet avec le suffixe "_EXTRACTED"

    return False  # Aucun objet avec le suffixe "_EXTRACTED" trouvé

def check_smooth_shading(obj):
    """
    Checks if the given Blender object uses smooth shading.

    Parameters:
    obj (bpy.types.Object): The Blender object to check.

    Returns:
    bool: True if the object uses smooth shading, False otherwise.
    """
    # Check if the object has a mesh data
    if obj and obj.type == 'MESH':
        return any(poly.use_smooth for poly in obj.data.polygons)
    return False

class SPEEDSCULPT_OT_remesh_selection(bpy.types.Operator):
    bl_idname = "object.speedsculpt_remesh_selection"
    bl_label = "REMESH SELECTION"
    bl_description = "\nRemesh the selection with the Remesh value and other settings as reference.\n\nDepending on the Value you are using, the complutation can take time."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.ops.ed.undo_push()
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt

        # AUTO SAVE
        if prefs.auto_save and sys.platform.startswith('win'):
            save_tmp()

        act_obj = context.active_object
        mode = act_obj.mode

        act_obj_has_mirror = has_mirror_modifier(act_obj)

# ----- CONVERT ARMATURE AND FONT
        process_selected_objects(context)

        act_obj = context.active_object
        context.view_layer.objects.active = act_obj
        act_obj.select_set(state = True)

# --------- DISABLE DYNTOPO
        toggle_dynamic_topology_sculpt(context)

        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        # APPLY MODIFIERS EXCEPT THE MIRROR
        if len(context.selected_objects)==1:
            for mod in act_obj.modifiers:
                if prefs.apply_mirror:
                    bpy.ops.object.convert(target='MESH')
                else:
                    if mod.type != 'MIRROR':
                        bpy.ops.object.modifier_apply(modifier=mod.name)

        if speedsculpt.cutter_create_boolean == 'create' and not act_obj_has_mirror:
                bpy.ops.object.convert(target='MESH')

        # BOOLEAN OPERATIONS
        if len(context.selected_objects)>=2:

            for obj in context.selected_objects:
                if obj == act_obj:
                    continue

                context.view_layer.objects.active = obj

                # remove mirror modifier if act_obj has a mirror
                if has_mirror_modifier(obj) and act_obj_has_mirror :
                    for mod in obj.modifiers:
                        bpy.ops.object.modifier_remove(modifier=mod.name)
                else:
                    for mod in obj.modifiers:
                        bpy.ops.object.modifier_apply(modifier=mod.name)

            context.view_layer.objects.active = act_obj

            if speedsculpt.boolean_operation == 'union':
                if not contains_extracted_suffix() and prefs.update_remesh:
                    bpy.ops.object.join()
                else:
                    bpy.ops.object.boolean_sculpt_union_difference()

            elif speedsculpt.boolean_operation == 'difference':
                bpy.ops.object.boolean_sculpt_union_difference()

            elif speedsculpt.boolean_operation == 'rebool':
                bpy.ops.object.boolean_sculpt_rebool()

        if prefs.fill_holes:
            fill_holes()

        # REMESH
        if prefs.update_remesh:
            for obj in context.selected_objects:
                bpy.ops.object.mode_set(mode='SCULPT')
                obj.data.remesh_voxel_size = prefs.remesh_mesh_value
                obj.data.remesh_voxel_adaptivity = prefs.remesh_mesh_voxel_adaptivity
                obj.data.use_remesh_fix_poles = prefs.remesh_mesh_fix_poles
                obj.data.use_remesh_preserve_volume = prefs.remesh_mesh_use_remesh_preserve_volume
                if bpy.app.version < (4, 1, 0):
                    obj.data.use_remesh_preserve_paint_mask = prefs.remesh_mesh_preserve_paint_mask
                    obj.data.use_remesh_preserve_sculpt_face_sets = prefs.remesh_mesh_preserve_sculpt_face_sets
                if bpy.app.version >= (4, 1, 0):
                    obj.data.use_remesh_preserve_attributes = prefs.remesh_mesh_preserve_attributes

            if contains_extracted_suffix():
                context.view_layer.objects.active = obj
            bpy.ops.object.voxel_remesh()

            if prefs.smooth_mesh:
                CheckSmoothMesh()

        if not contains_extracted_suffix():
            bpy.ops.object.mode_set(mode=mode)
        else:
            bpy.ops.object.mode_set(mode='OBJECT')

        # Select the first object
        if contains_extracted_suffix():
            selected_objects = [obj for obj in context.selected_objects]
            first_object = selected_objects[0]
            bpy.ops.object.select_all(action='DESELECT')

            context.view_layer.objects.active = first_object
            first_object.select_set(True)

        bpy.ops.object.mode_set(mode='OBJECT')
        if bpy.app.version < (4, 1, 0):
            context.object.data.use_auto_smooth = False
        if prefs.remesh_mesh_smooth_normals:
            bpy.ops.object.shade_smooth()
        else:
            bpy.ops.object.shade_flat()
        bpy.ops.object.mode_set(mode=mode)

        # REMOVE BSURFACE MATERIAL
        if bpy.data.materials.get('BSurfaceMesh'):
            bpy.data.materials.remove(bpy.data.materials['BSurfaceMesh'], do_unlink=True)

        return {'FINISHED'}

# ADD DYNTOPO
def CheckDyntopo():
    prefs = get_addon_preferences()
    sculpt = bpy.context.tool_settings.sculpt

    # Store current Mode
    mode = bpy.context.object.mode

    bpy.ops.view3d.snap_cursor_to_selected()
    saved_cursor_location = bpy.context.scene.cursor.location.copy()

    # Store initial detail and refine methods
    initial_detail_type_method = sculpt.detail_type_method
    initial_detail_refine_method = bpy.context.scene.tool_settings.sculpt.detail_refine_method

    if prefs.update_detail_flood_fill:
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        bpy.ops.object.mode_set(mode='SCULPT')

        # Toggle Dyntopo if not active
        if not bpy.context.sculpt_object.use_dynamic_topology_sculpting:
            bpy.ops.sculpt.dynamic_topology_toggle()

        sculpt.detail_refine_method = 'SUBDIVIDE_COLLAPSE'
        sculpt.detail_type_method = 'CONSTANT'
        
        bpy.context.scene.tool_settings.sculpt.constant_detail_resolution = 12

        bpy.ops.sculpt.detail_flood_fill()
        bpy.ops.sculpt.optimize()
    else:
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        bpy.ops.object.mode_set(mode='SCULPT')

    # Restore initial settings
    sculpt.detail_type_method = initial_detail_type_method
    sculpt.detail_refine_method = initial_detail_refine_method

    # Apply shading based on version and preference
    bpy.ops.object.mode_set(mode='OBJECT')

    if prefs.remesh_mesh_smooth_normals:
        bpy.ops.object.shade_smooth()
    else:
        bpy.ops.object.shade_flat()

    # Restore Mode
    bpy.ops.object.mode_set(mode=mode)

    # Restore cursor and origin
    bpy.context.scene.cursor.location = saved_cursor_location
    bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

# ADD AND APPLY SMOOTH MODIFIER
def CheckSmoothMesh():
    prefs = get_addon_preferences()
    if prefs.smooth_mesh:
        obj = bpy.context.object
        bpy.ops.object.mode_set(mode='OBJECT')
        mod_smooth = obj.modifiers.new("Smooth", 'SMOOTH')
        mod_smooth.factor = 1
        mod_smooth.iterations = prefs.smooth_mesh_value
        bpy.ops.object.modifier_apply(modifier=mod_smooth.name)

class SPEEDSCULPT_OT_smooth_mesh_only(bpy.types.Operator):
    bl_idname = "object.speedsculpt_smooth_mesh_only"
    bl_label = "DIRECT SMOOTH"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "\nDirect Smooth of the Mesh.\n\nIt will only add a Smooth to the Selection, no REMESH/DYNTOPO Update)"

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        prefs = get_addon_preferences()

        act_obj = context.active_object

        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            obj.select_set(state=True)
            mod_smooth = obj.modifiers.new("Smooth", 'SMOOTH')
            mod_smooth.factor = 1
            mod_smooth.iterations = prefs.smooth_mesh_value
            if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier=mod_smooth.name)
            else:
                bpy.ops.object.modifier_apply(apply_as='DATA', modifier=mod_smooth.name)

        context.view_layer.objects.active = act_obj
        act_obj.select_set(state=True)


        return {'FINISHED'}

selection = list()

def clean_and_convert(obj):
    if obj.modifiers:
        for mod in obj.modifiers:
            if mod.type == 'MIRROR':
                if not "Mirror_Skin" in obj.modifiers:
                    mod.use_mirror_merge = False
                    mod.use_clip = False

        bpy.ops.object.convert(target='MESH')

def separate_objects():
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.separate(type='LOOSE')
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]

def fill_holes():
    obj = bpy.context.object

    # Fill Holes
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type='EDGE')
    bm = bmesh.from_edit_mesh(obj.data)
    sel_edges = [e for e in bm.edges if e.select]
    bpy.ops.mesh.select_non_manifold(extend=False, use_wire=False, use_boundary=True, use_multi_face=False,
                                     use_non_contiguous=False, use_verts=False)
    if len(sel_edges) > 0:
        for e in bm.edges:
            if e not in sel_edges: e.select = False
    bpy.ops.mesh.edge_face_add()
    bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')

    bpy.ops.mesh.select_more()
    bpy.ops.mesh.select_more()

    # mask from faces
    bpy.ops.mesh.hide(unselected=False)
    bpy.ops.object.mode_set(mode='SCULPT')
    bpy.ops.paint.mask_flood_fill(mode='VALUE', value=1)
    if bpy.app.version < (4, 2, 0):
        bpy.ops.paint.hide_show(action='SHOW', area='ALL')
    else:
        bpy.ops.paint.hide_show(action='SHOW')
    bpy.ops.paint.mask_flood_fill(mode='VALUE', value=0)

#------------------------------------------------------
# Update Dyntopo
#------------------------------------------------------
class SPEEDSCULPT_OT_update_dyntopo(bpy.types.Operator):
    bl_idname = "object.update_dyntopo"
    bl_label = "REMESH SELECTION - DYNTOPO"
    bl_description = "\nRemesh the selection with the Remesh value and other settings as reference.\n\nDepending on the Value you are using, the complutation can take time."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.ops.ed.undo_push()
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        act_obj = context.active_object
        add_remesh = prefs.add_remesh
        self.sculpt = False

        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()

        context.preferences.edit.use_global_undo = True

        # ----- CONVERT ARMATURE AND FONT
        process_selected_objects(context)

        # APPLY MODIFIERS EXCEPT THE MIRROR
        for mod in act_obj.modifiers:
            if prefs.apply_mirror:
                bpy.ops.object.convert(target='MESH')
            else:
                if mod.type != 'MIRROR':
                    bpy.ops.object.modifier_apply(modifier=mod.name)

        if len(context.selected_objects) >= 2:
            if not contains_extracted_suffix():
                if speedsculpt.boolean_operation in {'union', 'difference'}:
                    bpy.ops.object.boolean_sculpt_union_difference()
                elif speedsculpt.boolean_operation == 'rebool':
                    bpy.ops.object.boolean_sculpt_rebool()

        # Convert Metaballs / Font / Curve
        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            obj.select_set(state = True)

            if obj.type == 'MESH':
                if obj.data.uv_layers:
                    bpy.ops.mesh.uv_texture_remove()

            if obj.data.users > 1:
                bpy.ops.object.make_single_user(object=True, obdata=True, material=False, animation=False)

            if obj.type in { 'CURVE', 'FONT'}:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.convert(target='MESH')
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.remove_doubles()
                bpy.ops.object.mode_set(mode='OBJECT')

            if obj.type == 'META':
                bpy.ops.object.convert(target='MESH')

        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            obj.select_set(state=True)

            if obj.get("speedsculpt_muscles"):
                del obj["speedsculpt_muscles"]

            # SCULPT
            if obj.mode == "SCULPT":
                self.sculpt = True
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.transform_apply(location=True, rotation=False, scale=True)
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
                bpy.ops.object.mode_set(mode='SCULPT')

            # OBJECT
            else:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

                if obj.modifiers:
                    if not "Mirror" in obj.modifiers:
                        clean_and_convert(obj)
                        separate_objects()
                        bpy.ops.object.boolean_sculpt_union_difference()

            # ACTIONS AFTER CONVERTION
            if prefs.fill_holes:
                fill_holes()
                bpy.ops.object.mode_set(mode='OBJECT')

            if add_remesh:
                bpy.ops.object.simple_remesh()
                clean_and_convert(obj)
                separate_objects()

            bpy.ops.object.mode_set(mode='OBJECT')

            CheckDyntopo()
            if not prefs.modal_smooth:
                CheckSmoothMesh()

        if self.sculpt:
            bpy.ops.object.mode_set(mode='SCULPT')

        context.scene.tool_settings.use_snap = False

        return {"FINISHED"}

def apply_modifiers(context):
    has_mirror = any(mod.type == 'MIRROR' for obj in context.selected_objects for mod in obj.modifiers)

    for obj in context.selected_objects:
        if has_mirror:
            for mod in obj.modifiers:
                bpy.ops.object.modifier_apply(modifier=mod.name)
        else:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.convert(target='MESH')

#------------------------------------------------------
# UNION / Difference
#------------------------------------------------------
class SPEEDSCULPT_OT_boolean_sculpt_union_difference(bpy.types.Operator):
    bl_idname = "object.boolean_sculpt_union_difference"
    bl_label = "Boolean Union Difference"
    bl_description = "Combine objects"
    bl_options = {"REGISTER", "UNDO"}

    def unlink_object_from_scene(self, context, o):
        for coll in o.users_collection:
            coll.objects.unlink(o)

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        # AUTO SAVE
        if prefs.auto_save and sys.platform.startswith('win'):
            save_tmp()

        # Check and Activate the Undo
        if not context.preferences.edit.use_global_undo:
            context.preferences.edit.use_global_undo = True

        self.operation_type = 'UNION' if speedsculpt.boolean_operation == 'union' else 'DIFFERENCE'

        # Making objects single-user
        for obj in context.selected_objects:
            if obj.data.users > 1:
                obj.make_single_user(object=True, obdata=True, material=False, animation=False)

        # Separate objects
        if speedsculpt.boolean_operation == 'union' and prefs.dyntopo_or_remesh == 'dyntopo':
            for obj in context.selected_objects:
                clean_and_convert(obj)
                separate_objects()

        # Union
        actObj = context.active_object
        for selObj in context.selected_objects:
            if selObj != actObj and selObj.type == "MESH":
                act_obj = context.active_object
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                # bpy.ops.object.transform_apply({"object": act_obj,
                #                                 "active_object": act_obj,
                #                                 "selected_editable_objects": [act_obj]},
                #                                location=False,
                #                                rotation=False,
                #                                scale=True)

                newMod = act_obj.modifiers.new("Boolean" + selObj.name, "BOOLEAN")
                newMod.operation = self.operation_type
                newMod.object = selObj
                apply_modifiers(context)

                bpy.ops.ed.undo_push()
                
                bpy.ops.object.select_all(action='DESELECT')
                selObj.select_set(state=True)
                bpy.ops.object.delete()
                act_obj.select_set(state=True)

        return {"FINISHED"}

# Boolean Rebool
class SPEEDSCULPT_OT_boolean_sculpt_rebool(bpy.types.Operator):
    bl_idname = "object.boolean_sculpt_rebool"
    bl_label = "Boolean Rebool"
    bl_description = "Slice the active object from your selection"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        prefs = get_addon_preferences()
        add_remesh = prefs.add_remesh

        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()

        # Check and Activate the Undo
        if not context.preferences.edit.use_global_undo:
            context.preferences.edit.use_global_undo = True

        for obj in context.selected_objects:
            if obj.data.users > 1:
                bpy.ops.object.make_single_user(object=True, obdata=True, material=False, animation=False)


        final_list = []
        act_obj = context.active_object
        obj_bool_list = [obj for obj in context.selected_objects if obj != act_obj and obj.type == 'MESH']
        bpy.ops.object.select_all(action='DESELECT')

        final_list.append(act_obj)
        for obj in obj_bool_list:
            act_obj.select_set(state=True)

            boolean_mod = act_obj.modifiers.new("Boolean", 'BOOLEAN')
            boolean_mod.object = obj
            boolean_mod.operation = 'DIFFERENCE'

            bpy.ops.object.duplicate_move()
            tempobj = context.active_object
            final_list.append(tempobj)

            tempobj.modifiers["Boolean"].operation = 'INTERSECT'
            bpy.ops.object.modifier_apply(modifier='Boolean')
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')

            act_obj.select_set(state=True)
            context.view_layer.objects.active = act_obj
            bpy.ops.object.modifier_apply(modifier='Boolean')

            bpy.ops.ed.undo_push()
            act_obj.select_set(state=False)
            tempobj.select_set(state=False)
            obj.select_set(state=True)
            bpy.ops.object.delete(use_global=False)
            act_obj.select_set(state=True)

        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        bpy.ops.object.select_all(action='DESELECT')

        for obj in final_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

            if add_remesh:
                bpy.ops.object.remesh()
                clean_and_convert(obj)
                separate_objects()
            if prefs.dyntopo_or_remesh == "dyntopo":
                if prefs.update_detail_flood_fill:
                    CheckDyntopo()
            else:
                if prefs.update_remesh:
                    bpy.ops.object.speedsculpt_remesh_selection()

            CheckSmoothMesh()
            obj.select_set(state=False)

        context.view_layer.objects.active = act_obj
        act_obj.select_set(state=True)

        if prefs.dyntopo_or_remesh == "dyntopo":
            if add_remesh:
                bpy.ops.object.remesh()
                clean_and_convert(act_obj)
                separate_objects()

        return {"FINISHED"}

class SPEEDSCULPT_OT_pick_remesh_size(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_pick_remesh_size'
    bl_label = "REMESH SIZE"
    bl_options = {'REGISTER'}
    bl_description = "\nPick the Remesh Value on an Object to use it when Remeshing your Mesh"

    @classmethod
    def poll(cls, context):
        if bpy.context.object.type == 'MESH' :
            return True

    def execute(self, context):
        prefs = get_addon_preferences()

        prefs.remesh_mesh_value = context.object.data.remesh_voxel_size

        return {'FINISHED'}

# SCALE
class SPEEDSCULPT_OT_scale_finalize(Operator):
    bl_idname = "speedsculpt.scale_finalize"
    bl_label = "scale Finalize"

    def execute(self, context):
        bpy.ops.transform.resize('INVOKE_DEFAULT', orient_type='LOCAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)),
                                 orient_matrix_type='LOCAL', constraint_axis=(False, False, True),
                                 mirror=True, use_proportional_edit=False,
                                 proportional_edit_falloff='SMOOTH',
                                 proportional_size=1,
                                 use_proportional_connected=False,
                                 use_proportional_projected=False)

        return {'FINISHED'}

# BSURFACE
# End : Snap 3D Cursor and delete empty
class SPEEDSCULPT_OT_bsurface_finalize(Operator):
    bl_idname = "speedsculpt.bsurface_finalize"
    bl_label = "Bsurface Finalize"

    def execute(self, context):
        bpy.ops.wm.tool_set_by_id(name="builtin.select")
        if bpy.data.materials.get('BSurfaceMesh'):
            bpy.data.materials.remove(bpy.data.materials['BSurfaceMesh'], do_unlink=True)
        return {'FINISHED'}

class SPEEDSCULPT_OT_bsurface_start(Operator):
    bl_idname = "speedsculpt.bsurface_start"
    bl_label = "Bsurface Start"

    def execute(self, context):
        bpy.ops.mesh.surfsk_add_surface('INVOKE_DEFAULT')
        return {'FINISHED'}

class SPEEDSCULPT_OT_add_bsurface(Macro):
    bl_idname = "speedsculpt.add_bsurface"
    bl_label = "Speedsculpt Add Bsurface"

# VOXEL -----------------------------------------------------
class SPEEDSCULPT_OT_edit_voxel_size(bpy.types.Operator):
    bl_idname = "object.speedsculpt_edit_voxel"
    bl_label = "speedsculpt edit voxel size"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):

        if context.object.mode == 'EDIT' :
            return {'FINISHED'}

        sculpt_mode = False
        if context.object.mode == 'SCULPT':
            sculpt_mode = True

        if tuple(context.object.scale) != (1, 1, 1):
            if sculpt_mode:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                bpy.ops.object.mode_set(mode='SCULPT')

        if context.object.type != 'MESH':
            bpy.ops.object.convert(target='MESH')
        bpy.ops.object.speedsculpt_voxel_size_edit('INVOKE_DEFAULT')

        return {'FINISHED'}

class SPEEDSCULPT_OT_voxel_size_edit(Macro):
    bl_idname = "object.speedsculpt_voxel_size_edit"
    bl_label = "Speedsculpt Voxel Size Edit"

class SPEEDSCULPT_OT_voxel_size_finalize(Operator):
    bl_idname = "object.speedsculpt_finalize"
    bl_label = "Voxel Size Finalize"

    def execute(self, context):
        context.area.tag_redraw()
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        self.ac_obj = context.active_object
        sculpt_mode = False
        if context.object.mode == 'SCULPT':
            sculpt_mode = True

        prefs.remesh_mesh_value = context.object.data.remesh_voxel_size
        bpy.ops.object.speedsculpt_remesh_selection()

        bpy.ops.object.voxel_remesh()

        prefs.remesh_mesh_value = context.object.data.remesh_voxel_size

        if prefs.modal_smooth:
            if sculpt_mode:
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.speedsculpt_smooth_modal('INVOKE_DEFAULT')
        else:
            if prefs.smooth_mesh:
                CheckSmoothMesh()

        if sculpt_mode:
            bpy.ops.object.mode_set(mode='SCULPT')


        self.report({'INFO'}, "UPDATED REMESH")

        return {'FINISHED'}

class SPEEDSCULPT_OT_remesh_shortcut(Operator):
    bl_idname = "object.speedsculpt_remesh_shortcut"
    bl_label = "Remesh"

    def execute(self, context):

        prefs = get_addon_preferences()
        dyntopo_or_remesh = prefs.dyntopo_or_remesh

        if context.object.mode == 'EDIT':
            return {'FINISHED'}

        if context.object.type=='MESH':
            if context.object.mode == 'SCULPT':
                prefs.sculpt_mode = True
            else:
                prefs.sculpt_mode = False

            if dyntopo_or_remesh == "dyntopo":
                self.report({'INFO'}, "UPDATED DYNTOPO")
                bpy.ops.object.update_dyntopo()
            elif dyntopo_or_remesh == "remesh":
                self.report({'INFO'}, "UPDATED REMESH")
                bpy.ops.object.speedsculpt_remesh_selection()

            # if prefs.modal_smooth:
            if prefs.add_smooth_remesh_modal:
                bpy.ops.object.speedsculpt_smooth_modal('INVOKE_DEFAULT')


        return {'FINISHED'}

class SPEEDSCULPT_OT_scale_macro(Macro):
    bl_idname = "speedsculpt.scale_macro"
    bl_label = "Speedsculpt scale Macro"

class SPEEDSCULPT_OT_set_bsurface_info(Operator):
    bl_idname = 'object.speedsculpt_set_bsurface_info'
    bl_label = "Set Bsurface Info"
    bl_description = "Install or Activate Bsurface to use it with Speedsculpt"
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        return {'FINISHED'}

class SPEEDSCULPT_OT_set_looptools_info(Operator):
    bl_idname = 'object.speedsculpt_set_looptools_info'
    bl_label = "Set Looptools Info"
    bl_description = "Install or Activate Looptools to use it with Speedsculpt"
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        return {'FINISHED'}

########################################################################################################################
#    GEOMESH
########################################################################################################################
class SPEEDSCULPT_OT_append_geomesh(Operator):
    bl_idname = "object.speedsculpt_append_geomesh"
    bl_label = "Create a Geomesh from the selected collection"

    geomesh_name: StringProperty(
        name="Geomesh Name",
        description="Name of the Geomesh object",
        default=""
    ) # type: ignore
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        layout.prop(speedsculpt, "collection_selection", text="Collection")
        
        # Check if name already exists
        name_exists = False
        # test_name = self.geomesh_name + "_Geomesh"
        test_name = self.geomesh_name
        if bpy.data.objects.get(test_name):
            name_exists = True
            
        row = layout.row()
        row.prop(self, "geomesh_name", text="Name")
        if name_exists:
            row = layout.row()
            # row.alert = True
            row.label(text="Name already exists!", icon='ERROR')
    
    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt

        has_object = context.object
        if has_object:
            active_object = context.active_object
            selection = context.selected_objects
            current_mode = active_object.mode

            if active_object and selection:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.select_all(action='DESELECT')
        
        # APPEND -----------------------------------------

        # Get the directory of the current script file
        current_dir = os.path.dirname(os.path.realpath(__file__))
        # Define the base path
        base_path = os.path.join(current_dir, 'library')
        # Get the file path
        file_path = os.path.join(base_path, "geomesh.blend")
        # Append the selected primitive
        with bpy.data.libraries.load(file_path) as (data_from, data_to):
            data_to.objects = [name for name in data_from.objects if name in data_from.objects]

        # APPEND -----------------------------------------

        bpy.ops.object.select_all(action='DESELECT')

        # COLLECTION --------------------------------------

        # Get the master collection (scene collection)
        master_collection = context.scene.collection

        # Move object to master collection
        for obj in data_to.objects:
            # Unlink from current collections
            for collection in obj.users_collection:
                collection.objects.unlink(obj)
            
            # Link to master collection
            master_collection.objects.link(obj)
            context.view_layer.objects.active = obj
        # COLLECTION --------------------------------------

        act_obj = context.active_object

        act_obj.select_set(state=True)
        context.view_layer.objects.active = act_obj
        
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        modifier = act_obj.modifiers.get("GeometryNodes_Geomesh")
        if modifier:
            geo_group = modifier.node_group
            collection_info = geo_group.nodes.get("Collection Info")

            if collection_info:
                if speedsculpt.collection_selection:
                    collection_info.inputs[0].default_value = speedsculpt.collection_selection

            # Update the area of the modifiers
            bpy.context.view_layer.update()
            context.area.tag_redraw()

        # Set name with _Geomesh suffix
        geomesh_name = (self.geomesh_name if self.geomesh_name else speedsculpt.collection_selection.name).replace(" ", "_")
        if not geomesh_name.endswith("_Geomesh"):
            geomesh_name += "_Geomesh"
        
        act_obj.name = geomesh_name
        act_obj.data.name = act_obj.name
        act_obj.hide_select = True
        # Clear Location
        act_obj.location = (0, 0, 0)
        # Add custom property 'Geomesh'
        act_obj["Geomesh"] = True

        # Après avoir créé le geomesh object
        # speedsculpt = context.scene.speedsculpt
        # S'assurer que l'objet a le suffixe _Geomesh
        
        
        # Ajouter l'objet à la collection
        item = speedsculpt.geomesh_objects.add()
        item.name = act_obj.name
        item.value = act_obj.name  # Maintenant ça fonctionne car la propriété existe
        
        # Mettre à jour l'index actif
        speedsculpt.geomesh_active_index = len(speedsculpt.geomesh_objects) - 1

        # Select the object
        bpy.ops.object.select_all(action='DESELECT')
        if has_object:
            for obj in selection:
                obj.select_set(state=True)
                context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode=current_mode)

        return {'FINISHED'}

class SPEEDSCULPT_OT_toggle_geomesh_visibility(bpy.types.Operator):
    bl_idname = "object.speedsculpt_toggle_geomesh_visibility"
    bl_label = "Toggle Geomesh Visibility"
    bl_description = "Toggle visibility of Geomesh and its Geometry Nodes modifier\nThis will improve performance when Editing the Objects in the 3Dview"
    # bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore
    
    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        # Vérifie si l'index est valide
        if 0 <= self.index < len(speedsculpt.geomesh_objects):
            # Récupère l'item
            item = speedsculpt.geomesh_objects[self.index]
            
            # Récupère l'objet Blender correspondant
            obj = bpy.data.objects.get(item.name)
            if obj:
                # Get le modificateur Geometry Nodes
                gn_mod = obj.modifiers.get("GeometryNodes_Geomesh")
                if gn_mod:
                    # Toggle visibility
                    obj.hide_viewport = not obj.hide_viewport
                    gn_mod.show_viewport = not gn_mod.show_viewport
                    
                    # Met à jour l'index actif
                    speedsculpt.geomesh_active_index = self.index
                    
                    # Force la mise à jour de l'interface
                    context.view_layer.update()
                    for area in context.screen.areas:
                        area.tag_redraw()
                    
                    return {'FINISHED'}
                else:
                    self.report({'WARNING'}, "Geometry Nodes modifier not found")
            else:
                self.report({'WARNING'}, "Object not found")
            
        return {'CANCELLED'}

class SPEEDSCULPT_OT_toggle_geomesh_visibility_shortcut(bpy.types.Operator):
    bl_idname = "object.speedsculpt_toggle_geomesh_visibility_shortcut"
    bl_label = "Toggle Geomesh Visibility"
    bl_description = "Toggle visibility of Geomesh object and its Geometry Nodes modifier"
    # bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        # Vérifie si on a des items dans la collection
        if len(speedsculpt.geomesh_objects) > 0:
            # Vérifie si l'index est valide
            if 0 <= speedsculpt.geomesh_active_index < len(speedsculpt.geomesh_objects):
                # Récupère l'item actif
                active_item = speedsculpt.geomesh_objects[speedsculpt.geomesh_active_index]
                
                # Récupère l'objet Blender correspondant
                active_geomesh = bpy.data.objects.get(active_item.name)
                if active_geomesh:
                    # Get son modifier
                    gn_mod = active_geomesh.modifiers.get("GeometryNodes_Geomesh")
                    if gn_mod:
                        # Toggle visibility
                        active_geomesh.hide_viewport = not active_geomesh.hide_viewport
                        gn_mod.show_viewport = not gn_mod.show_viewport
                        
                        # Force viewport update
                        context.view_layer.update()
                        for area in context.screen.areas:
                            if area.type == 'VIEW_3D':
                                area.tag_redraw()
                        
                        return {'FINISHED'}
            
        return {'CANCELLED'}

class SPEEDSCULPT_OT_delete_geomesh(bpy.types.Operator):
    bl_idname = "object.speedsculpt_delete_geomesh"
    bl_label = "Delete Geomesh"
    bl_description = "Delete the selected Geomesh"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    
    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        # Supprimer l'objet Blender
        obj = bpy.data.objects.get(self.object_name)
        if obj:
            bpy.data.objects.remove(obj, do_unlink=True)
        
        # Supprimer l'item de la collection
        speedsculpt.geomesh_objects.remove(self.index)
        
        # Ajuster l'index actif
        if len(speedsculpt.geomesh_objects) > 0:
            # Si on a supprimé le dernier item
            if self.index >= len(speedsculpt.geomesh_objects):
                speedsculpt.geomesh_active_index = len(speedsculpt.geomesh_objects) - 1
            else:
                # Garder le même index si possible
                speedsculpt.geomesh_active_index = self.index
        else:
            # Plus d'items, réinitialiser l'index
            speedsculpt.geomesh_active_index = 0
        
        # Forcer la mise à jour de l'interface
        for area in context.screen.areas:
            area.tag_redraw()
        
        return {'FINISHED'}

class SPEEDSCULPT_OT_lock_geomesh(bpy.types.Operator):
    bl_idname = "object.speedsculpt_lock_geomesh"
    bl_label = "Lock Geomesh"
    bl_description = "Lock/Unlock the Geomesh Selection"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore
    
    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        # Vérifie si l'index est valide
        if 0 <= self.index < len(speedsculpt.geomesh_objects):
            # Récupère l'item
            item = speedsculpt.geomesh_objects[self.index]
            
            # Récupère l'objet Blender correspondant
            obj = bpy.data.objects.get(item.name)
            if obj:
                # Toggle hide_select
                obj.hide_select = not obj.hide_select
                
                # Met à jour l'index actif
                speedsculpt.geomesh_active_index = self.index
                
                # Force la mise à jour de l'interface
                context.view_layer.update()
                for area in context.screen.areas:
                    area.tag_redraw()
                
                return {'FINISHED'}
            
        return {'CANCELLED'}

class SPEEDSCULPT_OT_select_geomesh(bpy.types.Operator):
    bl_idname = "object.speedsculpt_select_geomesh"
    bl_label = "Select Geomesh"
    bl_description = "Select the selected Geomesh and make it active"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: bpy.props.StringProperty()# type: ignore
    index: bpy.props.IntProperty()# type: ignore

    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        # Vérifie si l'index est valide
        if 0 <= self.index < len(speedsculpt.geomesh_objects):
            # Récupère l'item
            item = speedsculpt.geomesh_objects[self.index]
            
            # Désélectionne tous les objets
            bpy.ops.object.select_all(action='DESELECT')
            
            # Récupère et sélectionne l'objet
            obj = bpy.data.objects.get(item.name)
            if obj:
                obj.select_set(True)
                context.view_layer.objects.active = obj
                
                # Met à jour l'index actif dans la UI list
                speedsculpt.geomesh_active_index = self.index
                
                return {'FINISHED'}
        
        return {'CANCELLED'}

class SPEEDSCULPT_OT_rename_geomesh(bpy.types.Operator):
    bl_idname = "object.speedsculpt_rename_geomesh"
    bl_label = "Rename Geomesh"
    bl_description = "Rename the selected Geomesh"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore
    new_name: StringProperty(name="New Name") # type: ignore

    def invoke(self, context, event):
        # Get the object by name
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            self.report({'WARNING'}, "Object not found")
            return {'CANCELLED'}
            
        # Get the base name without _Geomesh
        self.new_name = obj.name[:-8].replace(" ", "_") if obj.name.endswith("_Geomesh") else obj.name.replace(" ", "_")
        
        return context.window_manager.invoke_props_dialog(self, width=200)

    def draw(self, context):
        self.layout.prop(self, "new_name", text="")

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt

        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            self.report({'WARNING'}, "Object not found")
            return {'CANCELLED'}
        
        # Store current selection state
        was_selected = obj.select_get()
        active_obj = context.view_layer.objects.active

        # Rename object and mesh
        new_name = self.new_name + "_Geomesh"
        old_name = obj.name  # Store old name
        obj.name = new_name
        if obj.data:
            obj.data.name = new_name

        # Get all Geomesh objects and sort them
        geomesh_objects = sorted(
            [o for o in bpy.data.objects if o.get('Geomesh', False)],
            key=lambda x: x.name
        )
        
        # Find new index after sorting
        try:
            new_index = geomesh_objects.index(obj)
            speedsculpt.geomesh_active_index = new_index
            
            # Restore selection and active state
            obj.select_set(was_selected)
            if active_obj == obj:
                context.view_layer.objects.active = obj
        except ValueError:
            pass

        # Force UI updates
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        
        return {'FINISHED'}
  
class SPEEDSCULPT_OT_convert_geomesh_to_mesh(bpy.types.Operator):
    bl_idname = "object.speedsculpt_convert_geomesh_to_mesh"
    bl_label = "Convert Geomesh to Mesh"
    bl_description = "Convert Geomesh to regular mesh"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        
        # Vérifie si l'index est valide
        if 0 <= self.index < len(speedsculpt.geomesh_objects):
            # Récupère l'item
            item = speedsculpt.geomesh_objects[self.index]
            
            # Récupère l'objet Blender
            obj = bpy.data.objects.get(item.name)
            if not obj:
                self.report({'WARNING'}, "Object not found")
                return {'CANCELLED'}

            # Store current selection and mode
            has_object = context.object
            if has_object:
                active_object = context.active_object
                selection = context.selected_objects
                current_mode = active_object.mode

            # Deselect all objects
            bpy.ops.object.select_all(action='DESELECT')

            # Select and make active the target object
            obj.select_set(True)
            context.view_layer.objects.active = obj
            obj.hide_select = False
            obj.hide_viewport = False

            # Ensure we're in object mode
            if obj.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            
            for modifier in obj.modifiers:
                if not modifier.show_viewport:
                    obj.modifiers.remove(modifier)
                else:
                    try:
                        bpy.ops.object.modifier_apply(modifier=modifier.name)
                    except:
                        self.report({'WARNING'}, f"Could not apply modifier {modifier.name}")

            # Remove _Geomesh suffix from name
            if obj.name.endswith("_Geomesh"):
                obj.name = obj.name[:-8]
                if obj.data:
                    obj.data.name = obj.name

            # Select the converted object
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj
            obj.show_in_front = False
            obj["Geomesh"] = False

            # Supprimer l'item de la collection
            speedsculpt.geomesh_objects.remove(self.index)
            
            # Ajuster l'index actif
            if len(speedsculpt.geomesh_objects) > 0:
                # Si on a supprimé le dernier item
                if self.index >= len(speedsculpt.geomesh_objects):
                    speedsculpt.geomesh_active_index = len(speedsculpt.geomesh_objects) - 1
                else:
                    # Garder le même index si possible
                    speedsculpt.geomesh_active_index = self.index
            else:
                # Plus d'items, réinitialiser l'index
                speedsculpt.geomesh_active_index = 0

            # Select the object
            bpy.ops.object.select_all(action='DESELECT')
            if has_object:
                for obj in selection:
                    obj.select_set(state=True)
                    context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode=current_mode)

            # Force UI updates
            for area in context.screen.areas:
                area.tag_redraw()

            return {'FINISHED'}
            
        return {'CANCELLED'}

class SPEEDSCULPT_OT_toggle_geomesh_mirror(bpy.types.Operator):
    bl_idname = "object.speedsculpt_toggle_geomesh_mirror"
    bl_label = "Toggle Geomesh Mirror"
    bl_description = "Toggle Geomesh Mirror modifier visibility"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        
        if obj:
            # Cherche un modifier Mirror existant
            mirror_mod = obj.modifiers.get("Mirror")
            
            if mirror_mod:
                # Si le modifier existe, on inverse sa visibilité
                mirror_mod.show_viewport = not mirror_mod.show_viewport
            else:
                # Si pas de modifier Mirror, on en crée un
                mirror_mod = obj.modifiers.new(name="Mirror", type='MIRROR')
                mirror_mod.use_bisect_axis[0] = True
                mirror_mod.show_viewport = True
                
                # Déplace le modifier à la fin de la pile
                for i in range(len(obj.modifiers)-1):
                    bpy.ops.object.modifier_move_down(modifier="Mirror")
            
            # Force le rafraîchissement de l'interface
            context.view_layer.update()
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
                    
        return {'FINISHED'}
    
CLASSES =  [SPEEDSCULPT_OT_toggle_geomesh_mirror,
            SPEEDSCULPT_OT_convert_geomesh_to_mesh,
            SPEEDSCULPT_OT_rename_geomesh,
            SPEEDSCULPT_OT_select_geomesh,
            SPEEDSCULPT_OT_delete_geomesh,
            SPEEDSCULPT_OT_lock_geomesh,
            SPEEDSCULPT_OT_toggle_geomesh_visibility,
            SPEEDSCULPT_OT_toggle_geomesh_visibility_shortcut,
            SPEEDSCULPT_OT_append_geomesh,
            SPEEDSCULPT_OT_boolean_sculpt_rebool,
            SPEEDSCULPT_OT_boolean_sculpt_union_difference,
            SPEEDSCULPT_OT_update_dyntopo,
            SPEEDSCULPT_OT_smooth_mesh_only,
            SPEEDSCULPT_OT_remesh_selection,
            SPEEDSCULPT_OT_add_assets_to_scene,
            SPEEDSCULPT_OT_cutter_primitives,
            SPEEDSCULPT_OT_voxel_size_edit,
            SPEEDSCULPT_OT_voxel_size_finalize,
            SPEEDSCULPT_OT_add_bsurface,
            SPEEDSCULPT_OT_bsurface_start,
            SPEEDSCULPT_OT_bsurface_finalize,
            SPEEDSCULPT_OT_edit_voxel_size,
            SPEEDSCULPT_OT_scale_macro,
            SPEEDSCULPT_OT_scale_finalize,
            SPEEDSCULPT_OT_pick_remesh_size,
            SPEEDSCULPT_OT_remesh_shortcut,
            SPEEDSCULPT_OT_set_bsurface_info,
            SPEEDSCULPT_OT_set_looptools_info
            ]
def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

    SPEEDSCULPT_OT_voxel_size_edit.define("OBJECT_OT_voxel_size_edit")
    SPEEDSCULPT_OT_voxel_size_edit.define("OBJECT_OT_speedsculpt_finalize")

    SPEEDSCULPT_OT_add_bsurface.define("SPEEDSCULPT_OT_bsurface_start")
    SPEEDSCULPT_OT_add_bsurface.define("SPEEDSCULPT_OT_bsurface_finalize")

    SPEEDSCULPT_OT_scale_macro.define("SPEEDSCULPT_OT_scale_finalize")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)

# import random
# # Create Material
# class SPEEDSCULPT_OT_create_random_materials(bpy.types.Operator):
#     bl_idname = 'object.create_random_materials'
#     bl_label = "Create Random Materials"
#     bl_options = {'REGISTER'}
#
#     @classmethod
#     def poll(cls, context):
#         return True
#
#     def execute(self, context):
#         obj = bpy.context.active_object
#         bpy.context.scene.tool_settings.sculpt.show_diffuse_color = True
#
#         for obj in bpy.context.selected_objects:
#             bpy.context.scene.objects.active=obj
#
#             # Create a new material
#             material = bpy.data.materials.new(name=obj.name)
#             material.use_nodes = True
#             material_output = material.node_tree.nodes.get('Material Output')
#             # remove diffuse
#             diffuse = material.node_tree.nodes['Diffuse BSDF']
#             material.node_tree.nodes.remove(diffuse)
#             # add Principled
#             shader = material.node_tree.nodes.new('ShaderNodeBsdfPrincipled')
#             shader.location[0] = 50
#             shader.location[1] = 306
#
#             # link shader to material
#             material.node_tree.links.new(material_output.inputs[0], shader.outputs[0])
#             # set active material to your new material
#             obj.active_material = material
#
#             val = lambda: random.random()
#             C = (val(), val(), val())
#             bpy.context.object.active_material.diffuse_color = (C[0], C[1], C[2])
#             bpy.context.object.active_material.node_tree.nodes['Principled BSDF'].inputs[0].default_value = (
#                 C[0], C[1], C[2], 1)
#
#         return {'FINISHED'}
#
# class SPEEDSCULPT_OT_SC_Remove_Shaders(bpy.types.Operator):
#     bl_idname = 'object.sc_remove_shaders'
#     bl_label = "Remove Shader from selection"
#     bl_options = {'REGISTER'}
#
#     @classmethod
#     def poll(cls, context):
#         return True
#
#     def execute(self, context):
#         selection = bpy.context.selected_objects
#
#         for obj in selection:
#             obj.select_set(state=True)
#             context.view_layer.objects.active = obj
#             if obj.material_slots:
#                 bpy.ops.object.material_slot_remove()
#
#         return {'FINISHED'}
#
#
# class SPEEDSCULPT_OT_Random_Color(bpy.types.Operator):
#     """    RANDOM COLOR
#
#     CLICK - Add Random Color
#     SHIFT - Add the same Shader to Selection
#     CTRL  - Remove Shader
#     ALT    - Link Shader
#     CTRL + SHIFT - Select objects with the same material
#     CTRL + ALT - Single User"""
#
#     bl_idname = "object.random_color"
#     bl_label = "Speedsculpt Random Color"
#     bl_options = {"REGISTER", "UNDO"}
#
#     def invoke(self, context, event):
#         selection = bpy.context.selected_objects
#
#         bpy.context.object.show_transparent = True
#         bpy.context.space_data.show_backface_culling = True
#
#         if event.ctrl and event.shift:
#             bpy.ops.object.select_linked(type='MATERIAL')
#
#         elif event.ctrl and event.alt:
#             bpy.ops.object.make_single_user(type='SELECTED_OBJECTS', object=False, obdata=False, material=True,
#                                             texture=True, animation=False)
#
#         elif event.shift:
#             for obj in selection:
#                 obj.select_set(state=True)
#                 context.view_layer.objects.active = obj
#                 bpy.ops.object.create_random_materials()
#                 bpy.ops.object.make_links_data(type='MATERIAL')
#
#         elif event.ctrl:
#             for obj in selection:
#                 obj.select_set(state=True)
#                 context.view_layer.objects.active = obj
#                 if obj.material_slots:
#                     bpy.ops.object.material_slot_remove()
#
#         elif event.alt:
#             bpy.ops.object.make_links_data(type='MATERIAL')
#
#         else:
#             bpy.ops.object.create_random_materials()
#
#         return {"FINISHED"}
#
#
# def Speedsculpt_Set_Material_Color(self, context):
#     selection = bpy.context.selected_objects
#     WM = bpy.context.window_manager
#
#     for obj in selection:
#         obj.select_set(state=True)
#         context.view_layer.objects.active = obj
#
#         if len(obj.material_slots):
#             bpy.context.object.active_material.diffuse_color = WM.speedsculpt_set_material_color
#             bpy.context.object.active_material.node_tree.nodes['Principled BSDF'].inputs[0].default_value = (
#                 WM.speedsculpt_set_material_color[0], WM.speedsculpt_set_material_color[1],
#                 WM.speedsculpt_set_material_color[2], 1)