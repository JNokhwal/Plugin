# -*- coding:utf-8 -*-

# ProFlow Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy

from .operators import (CheckDyntopo,
                        CheckSmoothMesh)

# from . import get_addon_preferences
# from .functions import *
from .functions import get_addon_preferences
##------------------------------------------------------  
#
# Symmetrize
#
##------------------------------------------------------   
class SPEEDSCULPT_OT_symmetrize(bpy.types.Operator):
    bl_idname = "object.symmetrize"
    bl_label = "Symmetrize"
    bl_description = "Symmetrize the mesh"
    bl_options = {"REGISTER", "UNDO"}
    
    symmetrize_axis : bpy.props.EnumProperty(
        items = (('positive_x', "Positive X", ""),
                 ('negative_x', "Negative X", ""),
                 ('positive_y', "Positive Y", ""),
                 ('negative_y', "Negative Y", ""),
                 ('positive_z', "Positive Z", ""),
                 ('negative_z', "Negative A", "")),
                 default = 'positive_x'
                 ) # type: ignore
    
    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        toolsettings = context.tool_settings
        sculpt = toolsettings.sculpt
        prefs = get_addon_preferences()

        self.act_obj = context.active_object

        self.sculpt_mode = False
        if self.act_obj.mode == 'SCULPT':
            self.sculpt_mode = True

        self.sel = [obj for obj in context.selected_objects]

        # SET DIRECTION
        if self.symmetrize_axis == 'positive_x':
            sculpt.symmetrize_direction = 'POSITIVE_X'
        elif self.symmetrize_axis == 'negative_x':
            sculpt.symmetrize_direction = 'NEGATIVE_X'
        elif self.symmetrize_axis == 'positive_y':
            sculpt.symmetrize_direction = 'POSITIVE_Y'
        elif self.symmetrize_axis == 'negative_y':
            sculpt.symmetrize_direction = 'NEGATIVE_Y'
        elif self.symmetrize_axis == 'positive_z':
            sculpt.symmetrize_direction = 'POSITIVE_Z'
        elif self.symmetrize_axis == 'negative_z':
            sculpt.symmetrize_direction = 'NEGATIVE_Z'

        if len(self.sel) >= 2:
            bpy.ops.object.convert(target='MESH')
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            bpy.ops.object.join()


        bpy.ops.object.mode_set(mode='SCULPT')
        bpy.ops.sculpt.symmetrize()

        # Update Detail Flood fill
        # if prefs.dyntopo_or_remesh == "dyntopo":
        #     if speedsculpt.update_dyntopo:
        #         if bpy.context.sculpt_object.use_dynamic_topology_sculpting:
        #             pass
        #         else:
        #             bpy.ops.sculpt.dynamic_topology_toggle()
        #
        #         bpy.ops.paint.mask_flood_fill(mode='VALUE', value=0)
        if prefs.dyntopo_or_remesh == 'dyntopo':
            if prefs.update_detail_flood_fill:
                bpy.ops.object.update_dyntopo()

        elif prefs.dyntopo_or_remesh == 'remesh':
            if prefs.update_remesh:
                bpy.ops.object.speedsculpt_remesh_selection()

        if prefs.smooth_mesh:
            CheckSmoothMesh()

        # bpy.ops.object.mode_set(mode='OBJECT')

        if self.sculpt_mode:
            bpy.ops.object.mode_set(mode='SCULPT')


        # #Sculpt
        # if context.object.mode == "SCULPT":
        #
        #     #check Symmetrize
        #     if self.symmetrize_axis == 'positive_x':
        #         if context.sculpt_object.use_dynamic_topology_sculpting :
        #             context.scene.tool_settings.sculpt.symmetrize_direction = 'POSITIVE_X'
        #             bpy.ops.sculpt.symmetrize()
        #         else:
        #             bpy.ops.object.mode_set(mode = 'EDIT')
        #             bpy.ops.mesh.select_all(action='SELECT')
        #             bpy.ops.mesh.symmetrize(direction='POSITIVE_X')
        #
        #     elif self.symmetrize_axis == 'negative_x':
        #         if context.sculpt_object.use_dynamic_topology_sculpting :
        #             context.scene.tool_settings.sculpt.symmetrize_direction = 'NEGATIVE_X'
        #             bpy.ops.sculpt.symmetrize()
        #         else:
        #             bpy.ops.object.mode_set(mode = 'EDIT')
        #             bpy.ops.mesh.select_all(action='SELECT')
        #             bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')
        #
        #     elif self.symmetrize_axis == 'positive_y':
        #         if context.sculpt_object.use_dynamic_topology_sculpting :
        #             context.scene.tool_settings.sculpt.symmetrize_direction = 'POSITIVE_Y'
        #             bpy.ops.sculpt.symmetrize()
        #         else:
        #             bpy.ops.object.mode_set(mode = 'EDIT')
        #             bpy.ops.mesh.select_all(action='SELECT')
        #             bpy.ops.mesh.symmetrize(direction='POSITIVE_Y')
        #
        #     elif self.symmetrize_axis == 'negative_y':
        #         if context.sculpt_object.use_dynamic_topology_sculpting :
        #             context.scene.tool_settings.sculpt.symmetrize_direction = 'NEGATIVE_Y'
        #             bpy.ops.sculpt.symmetrize()
        #         else:
        #             bpy.ops.object.mode_set(mode = 'EDIT')
        #             bpy.ops.mesh.select_all(action='SELECT')
        #             bpy.ops.mesh.symmetrize(direction='NEGATIVE_Y')
        #
        #     elif self.symmetrize_axis == 'positive_z':
        #         if context.sculpt_object.use_dynamic_topology_sculpting :
        #             context.scene.tool_settings.sculpt.symmetrize_direction = 'POSITIVE_Z'
        #             bpy.ops.sculpt.symmetrize()
        #         else:
        #             bpy.ops.object.mode_set(mode = 'EDIT')
        #             bpy.ops.mesh.select_all(action='SELECT')
        #             bpy.ops.mesh.symmetrize(direction='POSITIVE_Z')
        #
        #     elif self.symmetrize_axis == 'negative_z':
        #         if context.sculpt_object.use_dynamic_topology_sculpting :
        #             context.scene.tool_settings.sculpt.symmetrize_direction = 'NEGATIVE_Z'
        #             bpy.ops.sculpt.symmetrize()
        #         else:
        #             bpy.ops.object.mode_set(mode = 'EDIT')
        #             bpy.ops.mesh.select_all(action='SELECT')
        #             bpy.ops.mesh.symmetrize(direction='NEGATIVE_Z')
        #
        #
        #     # bpy.ops.object.mode_set(mode = 'SCULPT')
        #     #
        #     #
        #     # bpy.ops.object.mode_set(mode = 'OBJECT')
        #     bpy.ops.object.mode_set(mode = 'SCULPT')

            # #Update Detail Flood fill
            # if prefs.dyntopo_or_remesh == "dyntopo":
            #     if speedsculpt.update_dyntopo :
            #         if bpy.context.sculpt_object.use_dynamic_topology_sculpting:
            #             pass
            #         else:
            #             bpy.ops.sculpt.dynamic_topology_toggle()
            #
            #         bpy.ops.paint.mask_flood_fill(mode='VALUE', value=0)
            # CheckSmoothMesh()
            # bpy.ops.object.mode_set(mode = 'SCULPT')
            
        #Object    
        # elif context.object.mode == "OBJECT":
        #     for obj in context.selected_objects:
        #         bpy.ops.object.select_all(action='DESELECT')
        #         obj.select_set(state=True)
        #         context.view_layer.objects.active = obj
        #
        #         bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        #         bpy.ops.object.mode_set(mode = 'EDIT')
        #         bpy.ops.mesh.select_all(action='SELECT')
        #
        #         #check Symmetrize
        #         if self.symmetrize_axis == 'positive_x':
        #             bpy.ops.mesh.symmetrize(direction='POSITIVE_X')
        #         elif self.symmetrize_axis == 'negative_x':
        #             bpy.ops.mesh.symmetrize(direction='NEGATIVE_X')
        #         elif self.symmetrize_axis == 'positive_y':
        #             bpy.ops.mesh.symmetrize(direction='POSITIVE_Y')
        #         elif self.symmetrize_axis == 'negative_y':
        #             bpy.ops.mesh.symmetrize(direction='NEGATIVE_Y')
        #         elif self.symmetrize_axis == 'positive_z':
        #             bpy.ops.mesh.symmetrize(direction='POSITIVE_Z')
        #         elif self.symmetrize_axis == 'negative_z':
        #             bpy.ops.mesh.symmetrize(direction='NEGATIVE_Z')
        #
        #         bpy.ops.object.mode_set(mode = 'OBJECT')
        #
        #         if prefs.dyntopo_or_remesh == "dyntopo":
        #             CheckDyntopo()
        #
        #         bpy.ops.object.mode_set(mode = 'OBJECT')
        #
        #         CheckSmoothMesh()
        #
        #     for obj in context.selected_objects:
        #         obj.select_set(state=True)
                
        return {"FINISHED"}

CLASSES =  [SPEEDSCULPT_OT_symmetrize
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)