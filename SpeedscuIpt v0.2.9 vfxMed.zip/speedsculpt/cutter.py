# -*- coding:utf-8 -*-

# Speedflow Add-on
# Copyright (C) 2018 Cedric Lepiller aka Pitiwazou & Legigan Jeremy AKA Pistiwique and Stephen Leger
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
from bpy.types import Operator
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       PointerProperty)

import bmesh
import math
from mathutils import Matrix, Vector
import gpu
from gpu_extras.batch import batch_for_shader
import bgl
from .functions import get_addon_preferences
import blf
from bpy_extras.view3d_utils import (region_2d_to_location_3d)
from .operators import (CheckSmoothMesh,save_tmp)


class MyHandleClass:
    _handler = None

    @classmethod
    def add_handler(cls, function, args=()):
        cls._handler = bpy.types.SpaceView3D.draw_handler_add(
                function, args, 'WINDOW', 'POST_PIXEL'
                )

    @classmethod
    def remove_handler(cls):
        if cls._handler is not None:
            bpy.types.SpaceView3D.draw_handler_remove(cls._handler, 'WINDOW')
            cls._handler = None

# ----------------------------------------------------------------------------------------------------------------------
# DRAW TEXT ------------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------------------
font_info = {
    "font_id": 0,
    "handler": None,
}

def Speedsculpt_draw_callback_px(x, y, packed_strings, obj, active_area_hash):
    # addon_pref = get_addon_preferences()
    # Vérifier si nous sommes dans la vue active
    if hash(bpy.context.area) != active_area_hash:
        return


    text_size = 20
    font_id = 0
    dpi = 1
    if bpy.app.version < (4, 0, 0):
        blf.size(font_id, text_size, 72)
    else:
        blf.size(font_id, text_size * dpi)
    # blf.size(font_id, text_size, 72)
    x_offset = 0
    y_offset = 0
    shadow_color = (0, 0, 0, 0.2)
    shadow_x = 2
    shadow_y = -2
    text_pos_x = 0#addon_pref.text_pos_x
    text_pos_y = 80#addon_pref.text_pos_y
    overlap = bpy.context.preferences.system.use_region_overlap
    t_panel_width = 0
    text_shadow = True#addon_pref.text_shadow
    if overlap:
        for region in bpy.context.area.regions:
            if region.type == 'TOOLS':
                t_panel_width = region.width

    width = bpy.context.region.width
    height = bpy.context.region.height

    pos_x = min((width - t_panel_width - 250) * text_pos_x / 100 + t_panel_width, width - 250)
    pos_y = height / 3 + text_pos_y

    line_height = (blf.dimensions(font_id, "M")[1] )

    for command in packed_strings:
        if len(command) == 2:
            pstr, pcol = command
            blf.color(0, *pcol)
            text_width, text_height = blf.dimensions(font_id, pstr)
            if text_shadow:
                blf.enable(0, blf.SHADOW)
                blf.shadow_offset(0, shadow_x, shadow_y)
                blf.shadow(0, 3, shadow_color[0], shadow_color[1], shadow_color[2], shadow_color[3])
            blf.position(font_id, (pos_x + x_offset), (pos_y + y_offset), 0)
            blf.draw(font_id, pstr)
            x_offset += text_width
        else:
            x_offset = 0
            y_offset -= line_height

x = 0
y = 0
y1 = 100
RED = (1, 0, 0, 1)
GREEN = (0, 1, 0, 1)
BLUE = (0, 0, 1, 1)
WHITE = (1,1,1,1)

CR = "Carriage Return"
ps =   [("EDGE TOOL", WHITE),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("Click to add points", GREEN),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("SHIFT + RMB: ", WHITE), ("Place Cursor", GREEN),CR,
        ("", WHITE),CR,
        ("CTRL + LMB: ", WHITE), ("Create on surface", GREEN),CR,
        ("", WHITE),CR,
        ("SPACE/ENTER: ", WHITE), ("Valid", GREEN),CR,
        ("", WHITE),CR,
        ("ESC: ", WHITE), ("Escape", GREEN)
        ]

ps1 =  [("PRIMITIVE TOOLS", WHITE),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("Click & drag to place the primitive", GREEN), CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("SHIFT + RMB: ", WHITE), ("Place Cursor", GREEN),CR,
        ("", WHITE),CR,
        ("CTRL + LMB: ", WHITE), ("Create On Surface", GREEN),CR,
        ("", WHITE), CR,
        ("Numpad 1,3,7: ", WHITE), ("Change View", GREEN), CR,
        ("", WHITE),CR,
        ("SPACE/ENTER: ", WHITE), ("Valid", GREEN),CR,
        ("", WHITE),CR,
        ("ESC: ", WHITE), ("Escape", GREEN)
        ]

ps2 =  [("2D CUTTING TOOLS", WHITE),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("Click & drag create the form", GREEN), CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("SHIFT + RMB: ", WHITE), ("Place Cursor", GREEN),CR,
        ("", WHITE),CR,
        ("CTRL + LMB: ", WHITE), ("Create on surface", GREEN),CR,
        ("", WHITE), CR,
        ("Numpad 1,3,7: ", WHITE), ("Change View", GREEN), CR,
        ("", WHITE), CR,
        ("Numpad 5: ", WHITE), ("Ortho View", GREEN), CR,
        ("", WHITE),CR,
        ("SPACE/ENTER: ", WHITE), ("Valid", GREEN),CR,
        ("", WHITE),CR,
        ("ESC: ", WHITE), ("Escape", GREEN)
        ]

def local_rotate(obj, axis, angle):
    obj.matrix_world @= Matrix.Rotation(math.radians(angle), 4, axis)


# @staticmethod
def gpu_cutter_vertex_line(self, obj, speedsculpt, active_area_hash):
    # Vérifier si nous sommes dans la vue active
    if hash(bpy.context.area) != active_area_hash:
        return


    self.cutter_union_color = (1, 1, 1, 0.5)
    self.cutter_difference_color = (1, 0, 0, 0.5)
    self.cutter_rebool_color = (0, 1, 0, 0.5)
    self.cutter_new_mesh_color = (1, 1, 0, 0.5)

    if speedsculpt.cutter_union:
        self.line_color = self.cutter_union_color
    elif speedsculpt.cutter_difference:
        self.line_color = self.cutter_difference_color
    elif speedsculpt.cutter_rebool:
        self.line_color = self.cutter_rebool_color
    elif speedsculpt.cutter_new_mesh:
        self.line_color = self.cutter_new_mesh_color

    self.point_color = (self.line_color[0]*0.75, self.line_color[1]*0.75, self.line_color[2]*0.75, self.line_color[3] )

    bm = bmesh.from_edit_mesh(obj.data)
    lines_coords = [obj.matrix_world @ vert.co for edge in bm.edges for vert
              in edge.verts]
    points_coords = [obj.matrix_world @ v.co for v in bm.verts]

    if bpy.app.version < (4, 0, 0):
        bgl.glLineWidth(4)
        bgl.glEnable(bgl.GL_LINE_SMOOTH)
        bgl.glEnable(bgl.GL_BLEND)
        bgl.glDisable(bgl.GL_DEPTH_TEST)

        lines_shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        batch_line = batch_for_shader(lines_shader, 'LINES', {"pos": lines_coords})
        lines_shader.bind()
        lines_shader.uniform_float("color", self.line_color)
        batch_line.draw(lines_shader)

        if speedsculpt.cutter_primitives == 'vertex':
            bgl.glPointSize(10)
            bgl.glEnable(bgl.GL_LINE_SMOOTH)
            bgl.glEnable(bgl.GL_BLEND)
            bgl.glDisable(bgl.GL_DEPTH_TEST)

            shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
            batch = batch_for_shader(shader, 'POINTS', {"pos": points_coords})
            shader.bind()
            shader.uniform_float("color", self.point_color)
            batch.draw(shader)
    else:
        # LINES
        lines_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch_line = batch_for_shader(lines_shader, 'LINES', {"pos": lines_coords})
        gpu.state.line_width_set(5)
        gpu.state.point_size_set(5)
        gpu.state.blend_set('ALPHA')
        gpu.state.blend_set('NONE')
        lines_shader.uniform_float("color", self.point_color)
        batch_line.draw(lines_shader)

        if speedsculpt.cutter_primitives == 'vertex':
            # POINTS
            points_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
            batch_points = batch_for_shader(points_shader, 'POINTS', {"pos": points_coords})
            gpu.state.line_width_set(10)
            gpu.state.point_size_set(10)
            gpu.state.blend_set('ALPHA')
            gpu.state.blend_set('NONE')
            points_shader.uniform_float("color", self.point_color)
            batch_points.draw(points_shader)

def gpu_cutter_rectangle(self, context, speedsculpt, active_area_hash):
    # Vérifier si nous sommes dans la vue active
    if hash(bpy.context.area) != active_area_hash:
        return
    
    self.cutter_union_color = (1,1,1,0.1)
    self.cutter_difference_color = (1,0,0,0.1)
    self.cutter_rebool_color = (0,1,0,0.1)
    self.cutter_new_mesh_color = (1,1,0,0.1)

    if speedsculpt.cutter_union:
        self.line_color = self.cutter_union_color
    elif speedsculpt.cutter_difference:
        self.line_color = self.cutter_difference_color
    elif speedsculpt.cutter_rebool:
        self.line_color = self.cutter_rebool_color
    elif speedsculpt.cutter_new_mesh:
        self.line_color = self.cutter_new_mesh_color

    self.face_color = (self.line_color[0], self.line_color[1], self.line_color[2], self.line_color[3] * 0.25)

    deps = context.evaluated_depsgraph_get()
    plan = self.plan.evaluated_get(deps)

    tM = plan.matrix_world
    face_index = (0, 3, 7, 4)
    indices = [(0, 1, 2), (0, 2, 3)]
    points_coords = [tM @ Vector(plan.bound_box[idx]) for idx in face_index]
    lines_index = [0, 1, 2, 3, 0]
    lines_coords = [points_coords[idx] for idx in lines_index]

    if bpy.app.version < (4, 0, 0):
        lines_shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        lines_batch = batch_for_shader(lines_shader, 'LINE_STRIP', {"pos": lines_coords})
        bgl.glEnable(bgl.GL_LINE_SMOOTH)
        bgl.glEnable(bgl.GL_BLEND)
        bgl.glDisable(bgl.GL_DEPTH_TEST)
        lines_shader.bind()
        lines_shader.uniform_float("color", self.line_color)
        bgl.glLineWidth(4)
        lines_batch.draw(lines_shader)

        if self.plan:
            face_shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
            face_batch = batch_for_shader(face_shader, 'TRIS', {"pos": points_coords}, indices=indices)
            face_shader.bind()
            face_shader.uniform_float("color", self.face_color)
            bgl.glEnable(bgl.GL_BLEND)
            face_batch.draw(face_shader)
            bgl.glDisable(bgl.GL_BLEND)

    else:
        # LINES
        lines_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch_line = batch_for_shader(lines_shader, 'LINE_STRIP', {"pos": lines_coords})
        lines_shader.uniform_float("color", self.line_color)
        gpu.state.line_width_set(5)
        gpu.state.point_size_set(5)
        gpu.state.blend_set('ALPHA')
        batch_line.draw(lines_shader)
        gpu.state.blend_set('NONE')

        # POINTS
        points_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        batch_points = batch_for_shader(points_shader, 'POINTS', {"pos": points_coords})
        points_shader.uniform_float("color", self.line_color)
        gpu.state.line_width_set(10)
        gpu.state.point_size_set(10)
        gpu.state.blend_set('ALPHA')
        batch_points.draw(points_shader)
        gpu.state.blend_set('NONE')

        if self.plan:
            # FACE
            gpu.state.blend_set('ALPHA')
            gpu.state.blend_set('NONE')
            face_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
            batch_face = batch_for_shader(face_shader, 'TRIS', {"pos": points_coords}, indices=indices)
            face_shader.uniform_float("color", self.face_color)
            gpu.state.blend_set('ALPHA')
            batch_face.draw(face_shader)
            gpu.state.blend_set('NONE')

class SPEEDSCULPT_OT_cutter(Operator):
    """ CUTTER
        CLICK On Button - Cut
        SHIFT On Button - Union
        CTRL On Button  - Rebool
        ALT On Button    - Create primitive

        CLICK in Modal - Rectangle
        SHIFT in Modal - Circle - not working yet
        CTRL in Modal  - Line - E to extrude
        ALT  in Modal   - Curve
        """
    bl_idname = "object.speedsculpt_cutter"
    bl_label = "Speedsculpt Cutter"
    # bl_options = {"REGISTER", "UNDO_GROUPED"}
    bl_options = {"REGISTER","UNDO"}

    first_mouse_x: IntProperty() # type: ignore
    first_mouse_y: IntProperty() # type: ignore

    @classmethod
    def poll(cls, context):
        return True

    act_obj = None

    prim_plan = False
    prim_cylinder = False
    prim_screw_vertex = False
    prim_screw = False
    prim_curve = False
    prim_vertex_line = False
    prim_sphere = False
    prim_cube = False
    prim_circle =False
    prim_library = False
    prim_bbox_created = False
    z_axis = False
    on_mesh = False
    uniform_scale = 0
    on_surface = False
    has_selection = False
    sculpt_mode = False

    plan = None
    circle = None
    vertex_line = None
    bbox_obj = None

    _handler = None
    count = 0
    active_area_hash = None  # Nouvelle propriété pour stocker le hash

# -------------------------------------
# PRIMITIVES
# -------------------------------------
    def cutter_create_circle(self, context):
        speedsculpt = context.scene.speedsculpt

        bpy.ops.mesh.primitive_plane_add(size=1, enter_editmode=False, align='CURSOR')

        self.circle = context.active_object
        self.prim_circle = True
        speedsculpt.primitive_created = True

        bpy.ops.object.mode_set(mode='EDIT')
        context.tool_settings.mesh_select_mode = (True, False, False)
        bpy.ops.mesh.merge(type='CENTER')
        bpy.ops.mesh.extrude_region_move()

        bpy.ops.object.vertex_group_add()
        context.scene.tool_settings.vertex_group_weight = 1
        bpy.ops.object.vertex_group_assign()

        bpy.ops.object.mode_set(mode='OBJECT')
        if speedsculpt.cutter_create_boolean == 'boolean':
            bpy.context.object.show_in_front = True

        # DISPLACE
        mod_displace = self.circle.modifiers.new("Displace - X", 'DISPLACE')
        mod_displace.mid_level = 0
        mod_displace.direction = 'X'
        mod_displace.strength = 0.1
        mod_displace.vertex_group = "Group"

        # SCREW
        mod_screw = self.circle.modifiers.new("Screw", 'SCREW')
        mod_screw.steps = 48
        mod_screw.use_merge_vertices = True
        mod_screw.use_normal_calculate = True
        mod_screw.show_in_editmode = True

        # DECIMATE
        mod_decimate = self.circle.modifiers.new("decimate", 'DECIMATE')
        mod_decimate.decimate_type = 'DISSOLVE'
        mod_decimate.angle_limit = 0.00872665

        bpy.ops.object.convert(target='MESH')

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.delete(type='ONLY_FACE')
        context.tool_settings.mesh_select_mode = (False, True, False)

    def cutter_create_plan(self, context):
        speedsculpt = context.scene.speedsculpt

        bpy.ops.mesh.primitive_plane_add(size=1, enter_editmode=False, align='CURSOR')

        self.plan = context.active_object
        self.prim_plan = True
        speedsculpt.primitive_created = True

        self.plan.display_type = 'BOUNDS'
        bpy.ops.object.mode_set(mode='EDIT')
        context.tool_settings.mesh_select_mode = (True, False, False)
        bpy.ops.mesh.merge(type='CENTER')

    def cutter_create_bbox(self, context):
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.view3d.snap_cursor_to_selected()
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
        bpy.ops.mesh.primitive_plane_add(enter_editmode=False, align='CURSOR', location=(self.plan.location))

        self.bbox_obj = context.active_object
        speedsculpt = context.scene.speedsculpt
        speedsculpt.primitive_created = True

        # copy transforms
        self.bbox_obj.dimensions = self.plan.dimensions
        self.bbox_obj.rotation_euler = self.plan.rotation_euler

        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    def cutter_create_vertex_line(self, context):
        speedsculpt = context.scene.speedsculpt

        bpy.ops.mesh.primitive_plane_add(size=1, enter_editmode=False, align='CURSOR')

        self.vertex_line = context.active_object
        self.prim_vertex_line = True
        speedsculpt.primitive_created = True

        bpy.ops.object.mode_set(mode='EDIT')
        context.tool_settings.mesh_select_mode = (True, False, False)
        bpy.ops.mesh.merge(type='CENTER')

    def cutter_create_sphere(self, context):
        speedsculpt = context.scene.speedsculpt

        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=5, radius=0.5, enter_editmode=False)
        # self.prim_sphere = context.active_object
        self.prim_sphere = True
        speedsculpt.primitive_created = True

    def cutter_create_cylinder(self, context):
        speedsculpt = context.scene.speedsculpt
        bpy.ops.mesh.primitive_cylinder_add(vertices=48, radius=0.5, depth=0.1, end_fill_type='TRIFAN',enter_editmode=False, align = 'CURSOR')
        # self.prim_cylinder = context.active_object
        self.prim_cylinder = True
        speedsculpt.primitive_created = True

        bpy.ops.object.mode_set(mode='EDIT')
        if speedsculpt.cutter_difference or speedsculpt.cutter_rebool:
            value_z = - context.object.dimensions[2] *  0.3
        elif speedsculpt.cutter_union:
            value_z = context.object.dimensions[2] * 0.3
        else:
            value_z = 0

        bpy.ops.transform.translate(value=(0, 0,value_z), orient_type='LOCAL',
                                    orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL')

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

    def cutter_create_cube(self, context):
        speedsculpt = context.scene.speedsculpt

        bpy.ops.mesh.primitive_cube_add(size=1, enter_editmode=False, align='CURSOR')
        # self.prim_cube = context.active_object
        self.prim_cube = True
        speedsculpt.primitive_created = True

        context.object.scale.z = 0.1
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        bpy.ops.object.mode_set(mode='EDIT')

        if speedsculpt.cutter_difference or speedsculpt.cutter_rebool:
            value_z = - context.object.dimensions[2] *  0.3
        elif speedsculpt.cutter_union:
            value_z = context.object.dimensions[2] * 0.3
        else:
            if speedsculpt.cutter_create_boolean == 'create' and self.on_surface :
                value_z = context.object.dimensions[2]* 0.1
            else:
                value_z = 0

        bpy.ops.transform.translate(value=(0, 0,value_z), orient_type='LOCAL',
                                    orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL')

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

    def cutter_create_curve(self, context):
        speedsculpt = context.scene.speedsculpt

        bpy.ops.curve.primitive_bezier_curve_add(radius=1, enter_editmode=False, align='CURSOR')
        # self.prim_curve = context.active_object
        self.prim_curve = True
        speedsculpt.primitive_created = True

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.curve.delete(type='VERT')

        if bpy.app.version >= (2, 90, 0):
            context.space_data.overlay.display_handle = 'NONE'
            context.space_data.overlay.show_curve_normals = False
        else:
            context.space_data.overlay.show_curve_normals = False
            context.space_data.overlay.show_curve_handles = False

# -------------------------------------
# UNLINK OBJECTS
# -------------------------------------
    def unlink_object_from_scene(self, context, o):
        for coll in o.users_collection:
            coll.objects.unlink(o)

# -------------------------------------
# LOCAL MOVE
# -------------------------------------
    def cutter_move(self):
        bpy.ops.transform.translate('INVOKE_DEFAULT', orient_matrix_type='LOCAL',
                                    constraint_axis=(True, True, False), release_confirm=True)

# -------------------------------------
# CLEAN VARIABLES
# -------------------------------------
    def clean_variables(self):
        speedsculpt = bpy.context.scene.speedsculpt

        self.act_obj = None
        self.prim_plan = False
        self.prim_cylinder = False
        self.prim_screw_vertex = False
        self.prim_screw = False
        self.prim_curve = False
        self.prim_vertex_line = False
        self.prim_sphere = False
        self.prim_cube = False
        self.prim_circle = False
        self.prim_bbox_created = False
        # self.z_axis = False
        self.on_mesh = False
        self.bbox_obj = None
        # self.on_surface = False
        self.remesh_obj = False

        speedsculpt.primitive_created = False

# -------------------------------------
# FINALISE CUTTING
# -------------------------------------
    def cutter_finalize_cutting(self,context,speedsculpt,prefs):

        MyHandleClass.remove_handler()
        context.area.tag_redraw()

        # REMOVE HANDLER
        if self.prim_plan or self.prim_circle or self.prim_vertex_line:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')

        # CREATE FACES FOR LINE AND CIRCLE
        if self.prim_vertex_line or self.prim_circle:
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.edge_face_add()
            bpy.ops.mesh.normals_make_consistent(inside=False)

        # CREATE CURVE
        if self.prim_curve:
            bpy.ops.object.mode_set(mode='EDIT')
            context.object.data.dimensions = '2D'
            context.object.data.resolution_u = 12
            context.object.data.splines[0].use_cyclic_u = True
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.convert(target='MESH')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            context.tool_settings.mesh_select_mode = (True, False, False)
            bpy.ops.mesh.fill()

        bpy.ops.object.mode_set(mode='OBJECT')

        # APPLY TRANSFORM FOR CIRCLE
        if self.prim_circle:
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        # CREATE PLAN FROM BOUNDING BOX FOR THE PLAN PRIMITIVE
        if self.prim_plan:
            self.cutter_create_bbox(context)

        bpy.ops.object.mode_set(mode='OBJECT')

        # SET CURRENT OBJECT
        self.remesh_obj = context.active_object

        # ADD MIRROR
        if speedsculpt.add_mirror:
            print("MIRROR ON")
            mirror_mod = self.remesh_obj.modifiers.new("Mirror", 'MIRROR')
            mirror_mod.use_axis = [speedsculpt.mirror_x, speedsculpt.mirror_y, speedsculpt.mirror_z]
            if speedsculpt.ref_obj:
                mirror_mod.mirror_object = speedsculpt.ref_obj
        else:
            print("MIRROR OFF")

        # PARENTING
        if speedsculpt.primitives_parenting:
            # print("PARENTING ON")
            if not context.active_object.parent:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                self.act_obj.select_set(state=False)
                self.remesh_obj.select_set(state=True)
                context.view_layer.objects.active = self.remesh_obj
        # else:
        #     print("PARENTING OFF")

        if not speedsculpt.copy_cursor_orientation and not speedsculpt.add_mirror:
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

        if speedsculpt.cutter_create_boolean == 'create':
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')

        # ADD SOLIDIFY
        if speedsculpt.cutter_primitives in {'rectangle', 'vertex', 'curve', 'circle'}:
            mod_solidify = self.remesh_obj.modifiers.new('Solidify', 'SOLIDIFY')
            mod_solidify.use_even_offset = True
            mod_solidify.use_quality_normals = True
            mod_solidify.use_rim = True
            mod_solidify.offset = 0
            if speedsculpt.cutter_new_mesh or speedsculpt.boolean_operation == 'union':
                if prefs.dyntopo_or_remesh == 'dyntopo':
                    mod_solidify.thickness = speedsculpt.cutter_creation_width + 0.1
                else:
                    mod_solidify.thickness = speedsculpt.cutter_creation_width
            else:
                mod_solidify.thickness = self.act_obj.dimensions[0] + self.act_obj.dimensions[1] + self.act_obj.dimensions[2]

            bpy.ops.object.modifier_apply(modifier=mod_solidify.name)

        if not speedsculpt.cutter_new_mesh:
            self.act_obj.select_set(state=True)
            context.view_layer.objects.active = self.act_obj

            # Create Boolean
            if speedsculpt.cutter_difference :
                bpy.ops.object.boolean_sculpt_union_difference()

            elif speedsculpt.cutter_rebool:
                bpy.ops.object.boolean_sculpt_rebool()

        elif speedsculpt.cutter_union:
            self.act_obj.select_set(state=True)
            context.view_layer.objects.active = self.act_obj

        if prefs.dyntopo_or_remesh == "dyntopo":
            bpy.ops.object.update_dyntopo()

        elif prefs.dyntopo_or_remesh == "remesh":
            if prefs.update_remesh:
                bpy.ops.object.speedsculpt_remesh_selection()

        if prefs.smooth_mesh and not prefs.update_remesh:
            CheckSmoothMesh()

        # if speedsculpt.cutter_create_boolean == 'boolean':
        #     speedsculpt.add_mirror = False

        if self.prim_plan:
            o = self.plan
            self.unlink_object_from_scene(context,o)
            bpy.data.objects.remove(self.plan, do_unlink=True)
            self.plan = None

        bpy.ops.wm.tool_set_by_id(name="builtin.select")

        self.act_obj = None
        self.prim_plan = False
        self.prim_cylinder = False
        self.prim_screw_vertex = False
        self.prim_screw = False
        self.prim_curve = False
        self.prim_vertex_line = False
        self.prim_sphere = False
        self.prim_cube = False
        self.prim_circle = False
        self.prim_bbox_created = False
        # self.z_axis = False
        self.on_mesh = False
        self.remesh_obj = None
        # self.on_surface = False

        speedsculpt.primitive_created = False

        # if self.parent_is_true :
        #     speedsculpt.primitives_parenting = True
        #     self.parent_is_true = False

    def cancel_exit(self, context):
        speedsculpt = context.scene.speedsculpt

        

        MyHandleClass.remove_handler()
        context.area.tag_redraw()

        for obj in context.selected_objects:
            if obj.mode == 'EDIT':
                bpy.ops.object.mode_set(mode='OBJECT')
                self.unlink_object_from_scene(context, obj)
                bpy.data.objects.remove(obj, do_unlink=True)

        if self.act_obj :
            context.view_layer.objects.active = self.act_obj
            self.act_obj.select_set(state=True)

            # Restaure la mesh originale
            self.act_obj.data = self.original_mesh.copy()

        bpy.ops.wm.tool_set_by_id(name="builtin.select")

        

        if self.prim_plan or self.prim_circle or self.prim_vertex_line:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')

        self.act_obj = None
        self.prim_plan = False
        self.prim_cylinder = False
        self.prim_screw_vertex = False
        self.prim_screw = False
        self.prim_curve = False
        self.prim_vertex_line = False
        self.prim_sphere = False
        self.prim_cube = False
        self.prim_circle = False
        self.prim_bbox_created = False
        # self.z_axis = False
        self.on_mesh = False
        self.remesh_obj = None
        # self.on_surface = False

        speedsculpt.primitive_created = False

# -------------------------------------
# MODAL
# -------------------------------------
    # MODAL
    def modal(self, context, event):
        context.area.tag_redraw()
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

# -------------------------------------------------------------------------
# ----- PASS THROUGH EVENTS
# -------------------------------------------------------------------------

        if event.type == "Z" and event.ctrl:
            return {"RUNNING_MODAL"}

        # CURSOR
        if event.shift and event.type == 'RIGHTMOUSE':
            return {'PASS_THROUGH'}

        # VIEWS
        if event.type in {'NUMPAD_1', 'NUMPAD_3', 'NUMPAD_7', 'NUMPAD_5'} or event.ctrl and event.type in {'NUMPAD_1',
                                                                                                           'NUMPAD_3',
                                                                                                           'NUMPAD_7',
                                                                                                           'NUMPAD_5'}:
            return {'PASS_THROUGH'}

        if event.alt and event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
            return {'PASS_THROUGH'}

        if event.alt and event.type == 'MIDDLEMOUSE' and event.value == 'DRAG':
            return {'PASS_THROUGH'}

        if event.type == 'MIDDLEMOUSE':
            return {'PASS_THROUGH'}

# -------------------------------------------------------------------------
# ----- LEFTMOUSE
# -------------------------------------------------------------------------
        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS' and not speedsculpt.primitive_created :

            # CURSOR
            if not speedsculpt.cutter_curve :
                bpy.ops.wm.tool_set_by_id(name="builtin.cursor")
                if speedsculpt.cutter_view_surface == 'surface' or event.ctrl :
                    self.on_surface = True
                    bpy.ops.view3d.cursor3d('INVOKE_DEFAULT', use_depth=True, orientation='GEOM')
                else:
                    bpy.ops.view3d.cursor3d('INVOKE_DEFAULT', use_depth=False, orientation='VIEW')

            # LIBRARY
            if speedsculpt.cutter_primitives == 'library':
                self.add_lib_object(context)
                bpy.ops.object.speedsculpt_scale_rotate('INVOKE_DEFAULT')

            # VERTEX LINE
            elif speedsculpt.cutter_primitives == 'vertex':
                self.cutter_create_vertex_line(context)
                bpy.ops.mesh.extrude_region_move()
                bpy.ops.transform.translate('INVOKE_DEFAULT', release_confirm=False)
                args = (self, self.vertex_line, speedsculpt, self.active_area_hash)
                self._handle = bpy.types.SpaceView3D.draw_handler_add(gpu_cutter_vertex_line, args, 'WINDOW',
                                                                      'POST_VIEW')

            # CURVE
            elif speedsculpt.cutter_primitives == 'curve':
                self.cutter_create_curve(context)
                bpy.ops.wm.tool_set_by_id(name="builtin.draw")
                bpy.ops.curve.draw('INVOKE_DEFAULT', error_threshold=0.05, fit_method='SPLIT', corner_angle=60,
                                   use_cyclic=True,
                                   stroke=[],
                                   wait_for_input=False)

            # SPHERE
            elif speedsculpt.cutter_primitives == 'sphere':
                self.cutter_create_sphere(context)
                bpy.ops.object.speedsculpt_scale_rotate('INVOKE_DEFAULT')

            # CYLINDER
            elif speedsculpt.cutter_primitives == 'cylinder':
                self.cutter_create_cylinder(context)
                bpy.ops.object.speedsculpt_scale_rotate('INVOKE_DEFAULT')

            # CUBE
            elif speedsculpt.cutter_primitives == 'cube':
                self.cutter_create_cube(context)
                bpy.ops.object.speedsculpt_scale_rotate('INVOKE_DEFAULT')

            # CIRCLE
            elif speedsculpt.cutter_primitives == 'circle':
                self.cutter_create_circle(context)
                bpy.ops.object.speedsculpt_scale_rotate('INVOKE_DEFAULT')
                args = (self, self.circle, speedsculpt, self.active_area_hash)
                self._handle = bpy.types.SpaceView3D.draw_handler_add(gpu_cutter_vertex_line, args, 'WINDOW',
                                                                      'POST_VIEW')

            elif speedsculpt.cutter_primitives == 'rectangle':
                self.cutter_create_plan(context)
                bpy.ops.mesh.duplicate_move()
                self.cutter_move()

                # args = (self, None, speedsculpt)
                args = (self, context, speedsculpt, self.active_area_hash)
                self._handle = bpy.types.SpaceView3D.draw_handler_add(gpu_cutter_rectangle, args, 'WINDOW', 'POST_VIEW')

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE' and speedsculpt.primitive_created and self.prim_vertex_line:
            bpy.ops.mesh.extrude_region_move()
            bpy.ops.transform.translate('INVOKE_DEFAULT', release_confirm=False)

        if event.value == 'RELEASE' and speedsculpt.primitive_created and \
                (self.prim_plan or self.prim_cube or self.prim_sphere or self.prim_cylinder or self.prim_curve
                 or self.prim_circle):

            MyHandleClass.remove_handler()
            self.cutter_finalize_cutting(context,speedsculpt,prefs)

            if self.has_selection and self.sculpt_mode:
                bpy.ops.object.mode_set(mode='SCULPT')
            self.has_selection = False
            self.sculpt_mode = False
            return {'FINISHED'}

        # CANCEL AND EXIT
        # elif event.type in {'ESC', 'RIGHTMOUSE'} and not speedsculpt.primitive_created and event.value == 'PRESS' :
        elif event.type in {'ESC', 'RIGHTMOUSE'}:
            self.cancel_exit(context)

            if self.has_selection and self.sculpt_mode:
                bpy.ops.object.mode_set(mode='SCULPT')

            self.has_selection = False
            self.sculpt_mode = False
            return {'CANCELLED'}


        # FINILIZE CUTTING
        elif event.type in {'SPACE', 'RET', 'ENTER'} and event.value == 'RELEASE' and speedsculpt.primitive_created:
            # args = (self, context, speedsculpt,prefs)
            self.cutter_finalize_cutting(context,speedsculpt,prefs)

            self.clean_variables()

            if self.has_selection and self.sculpt_mode:
                bpy.ops.object.mode_set(mode='SCULPT')

            self.has_selection = False
            self.sculpt_mode = False
            return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        # Stocker le hash de la vue active
        self.active_area_hash = hash(context.area)

        bpy.ops.ed.undo_push(message="Add an undo step")

        if context.area.type == 'VIEW_3D':
            speedsculpt = context.scene.speedsculpt
            prefs = get_addon_preferences()
            context.preferences.edit.use_global_undo = True

            # Sauvegarde de la mesh originale
            if context.object:
                self.original_mesh = context.object.data.copy()


            # check for mirror
            if context.object is not None and context.selected_objects:
                self.first_selection = context.active_object
                self.act_obj = context.active_object

            # self.primitive_mode = speedsculpt.create_primitives
            context.scene.transform_orientation_slots[0].type = 'LOCAL'

            # Disable Auto Merge
            tool_settings = context.tool_settings
            tool_settings.use_mesh_automerge = False

            speedsculpt.cutter_difference = False
            speedsculpt.primitive_created = False
            speedsculpt.cutter_union = False
            speedsculpt.cutter_rebool = False
            speedsculpt.cutter_new_mesh = False
            speedsculpt.cutter_plan = True
            speedsculpt.cutter_cylinder = False
            speedsculpt.cutter_vertex_line = False
            speedsculpt.cutter_curve = False
            speedsculpt.cutter_sphere = False

            # Check if Selection
            if context.selected_objects:
                self.has_selection = True
                if not speedsculpt.create_primitives == 'cursor':
                    bpy.ops.view3d.snap_cursor_to_selected()
            else:
                speedsculpt.cutter_create_boolean = 'create'

            if self.has_selection:
                if context.object.mode == 'SCULPT':
                    self.sculpt_mode = True
                if context.object.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')

            # From buttons
            if speedsculpt.cutter_create_boolean == 'boolean':
                speedsculpt.cutter_new_mesh = False
                if speedsculpt.boolean_operation == 'union':
                    speedsculpt.cutter_new_mesh = True
                    speedsculpt.cutter_union = True
                    speedsculpt.cutter_difference = False
                    speedsculpt.cutter_rebool = False
                elif speedsculpt.boolean_operation == 'difference':
                    speedsculpt.cutter_union = False
                    speedsculpt.cutter_difference = True
                    speedsculpt.cutter_rebool = False
                elif speedsculpt.boolean_operation == 'rebool':
                    speedsculpt.cutter_union = False
                    speedsculpt.cutter_difference = False
                    speedsculpt.cutter_rebool = True

            elif speedsculpt.cutter_create_boolean == 'create':
                bpy.ops.object.select_all(action='DESELECT')
                speedsculpt.cutter_new_mesh = True
                speedsculpt.cutter_difference = False
                speedsculpt.cutter_rebool = False
                speedsculpt.cutter_union = False

            # HANDLES
            MyHandleClass.remove_handler()
            if speedsculpt.cutter_primitives == 'vertex':
                MyHandleClass.add_handler(Speedsculpt_draw_callback_px, (x, y, ps, context.object, self.active_area_hash))
            elif speedsculpt.cutter_primitives in { 'sphere', 'cylinder', 'cube'}:
                MyHandleClass.add_handler(Speedsculpt_draw_callback_px, (x, y, ps1, context.object, self.active_area_hash))
            elif speedsculpt.cutter_primitives in { 'rectangle', 'curve', 'circle'}:
                MyHandleClass.add_handler(Speedsculpt_draw_callback_px, (x, y, ps2, context.object, self.active_area_hash))


            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_scale_rotate(bpy.types.Operator):
    """Move an object with the mouse, example"""
    bl_idname = "object.speedsculpt_scale_rotate"
    bl_label = "Scale and rotate at the same time"

    first_mouse_x: IntProperty() # type: ignore
    x_value: FloatProperty() # type: ignore
    first_mouse_y: IntProperty() # type: ignore
    primitive_created = False

    def get_spin(self):
        obj = bpy.context.active_object
        return obj.rotation_euler.to_matrix().to_euler('ZYX').z

    def set_spin(self, value):
        obj = bpy.context.active_object
        rot = obj.rotation_euler.to_matrix().to_euler('ZYX')
        rot.z = value
        obj.rotation_euler = rot.to_matrix().to_euler(obj.rotation_mode)

    def get_scale_x(self):
        obj = bpy.context.active_object
        return obj.scale.x

    def set_scale_x(self, value):
        obj = bpy.context.active_object
        obj.scale.x = value

    def get_scale_y(self):
        obj = bpy.context.active_object
        return obj.scale.y

    def set_scale_y(self, value):
        obj = bpy.context.active_object
        obj.scale.y = value

    def get_scale_z(self):
        obj = bpy.context.active_object
        return obj.scale.z

    def set_scale_z(self, value):
        obj = bpy.context.active_object
        obj.scale.z = value

    spin: FloatProperty(
        unit='ROTATION',
        get=get_spin,
        set=set_spin, ) # type: ignore

    scaling_x: FloatProperty(
        unit='ROTATION',
        get=get_scale_x,
        set=set_scale_x, ) # type: ignore

    scaling_y: FloatProperty(
        unit='ROTATION',
        get=get_scale_y,
        set=set_scale_y, ) # type: ignore

    scaling_z: FloatProperty(
        unit='ROTATION',
        get=get_scale_z,
        set=set_scale_z, ) # type: ignore

    def modal(self, context, event):
        speedsculpt = context.scene.speedsculpt
        obj = bpy.context.active_object

        if event.type == 'MOUSEMOVE':
            delta_y = self.first_mouse_y + event.mouse_y
            speed = 0.33 if event.shift else 1

            # ROTATE
            self.spin = delta_y * 0.005 * speed * 0.85

            # SCALE
            self.scaling_x = obj.scale.x + (event.mouse_x - event.mouse_prev_x) * 0.05 * speed
            self.scaling_y = obj.scale.y + (event.mouse_x - event.mouse_prev_x) * 0.05 * speed
            self.scaling_z = obj.scale.z + (event.mouse_x - event.mouse_prev_x) * 0.05 * speed

        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            if speedsculpt.cutter_primitives in {'cylinder','cube'} :
                bpy.ops.object.speedsculpt_scale_z('INVOKE_DEFAULT')
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:

            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):

        if context.object:
            self.first_mouse_x = event.mouse_x
            self.first_mouse_y = event.mouse_y

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_scale_cutter(bpy.types.Operator):
    """Scale mesh with mouse"""
    bl_idname = "object.speedsculpt_scale_cutter"
    bl_label = "Speedsculpt Scale"
    bl_options = {'GRAB_CURSOR','BLOCKING'}

    first_mouse_x: IntProperty() # type: ignore
    first_value: FloatProperty() # type: ignore
    action_scale = False

    obj_matrix_save = None
    start_end_cap = False
    random = False
    start = False
    def modal(self, context, event):
        speedsculpt = context.scene.speedsculpt
        if event.type == 'MOUSEMOVE' :
            if speedsculpt.cutter_primitives == 'circle':
                speed = 4 if event.shift else 40
            else:
                speed = 1 if event.shift else 10

            delta = (event.mouse_x - self.first_mouse_x) * 0.005 * speed
            MS = self.MW @ Matrix.Scale(1 + delta, 4)
            context.object.matrix_world = MS

        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE' :
            self.act_obj = None
            if speedsculpt.cutter_primitives in {'cylinder','cube'} :
                bpy.ops.object.speedsculpt_scale_z('INVOKE_DEFAULT')
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            context.object.location.x = self.first_value
            self.act_obj = None
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.act_obj = context.active_object

        if context.object:
            self.MW = context.object.matrix_world.copy()
            self.first_mouse_x = event.mouse_x
            self.first_value = sum(context.object.scale[:]) / 3


            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}

        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_scale_z(bpy.types.Operator):
    """Move an object with the mouse, example"""
    bl_idname = "object.speedsculpt_scale_z"
    bl_label = "Scale Z"

    first_mouse_x: IntProperty() # type: ignore
    first_value: FloatProperty() # type: ignore

    def modal(self, context, event):
        speedsculpt = context.scene.speedsculpt

        if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            delta = self.first_mouse_x - event.mouse_x
            context.object.scale.z = self.first_value_z - delta * 0.1

        if event.type == 'LEFTMOUSE':
            # if speedsculpt.cutter_create_boolean == 'create' and speedsculpt.cutter_primitives == 'cube':
            #
            #
            #     local_rotate(self.array_empty, 'Z', angle)

            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            context.object.location.x = self.first_value
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        # self.start = True

        if context.object:
            self.first_mouse_x = event.mouse_x
            self.first_value_z = context.object.scale.z

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

CLASSES =  [SPEEDSCULPT_OT_cutter,
            SPEEDSCULPT_OT_scale_cutter,
            SPEEDSCULPT_OT_scale_z,
            SPEEDSCULPT_OT_scale_rotate
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)

