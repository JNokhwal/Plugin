# -*- coding:utf-8 -*-

# ProFlow Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
import bmesh
from bpy.types import Operator, Macro
from bpy.props import (StringProperty, 
                       BoolProperty, 
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty)
from .functions import get_addon_preferences

# Go in Sculpt to add Mask
class SPEEDSCULPT_OT_add_extract_mask(Operator):
    bl_idname = "object.add_extract_mask"
    bl_label = "Add Mask"
    bl_description = "Add a mask to the object"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        for obj in context.selected_objects:
            for mod in obj.modifiers:
                if mod.type == 'HOOK':
                    mod.show_viewport = False
        if context.object.mode != "SCULPT":
            bpy.ops.object.mode_set(mode='SCULPT')
        bpy.ops.paint.brush_select(sculpt_tool='MASK')

        return {"FINISHED"}

class SPEEDSCULPT_OT_clean_boundary(Operator):
    bl_idname = "object.speedsculpt_clean_boundary"
    bl_label = "Clean Boundary"
    bl_description = "Clean the Boundaries of the Mesh to fix some issues"
    bl_options = {"REGISTER","UNDO"}

    remove_double : FloatProperty(name="Remove Double",
                                  description="Merge distance",
                                  min=0.0001,
                                  max=1.00,
                                  default=0.01) # type: ignore

    def remove_doubles(self):
        act_obj = bpy.context.active_object
        mode = act_obj.mode

        # Remove Double on Boundary
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.region_to_loop()
        bpy.ops.mesh.remove_doubles(threshold=self.remove_double)

        bpy.ops.object.mode_set(mode=mode)

    def execute(self, context):
        self.remove_doubles()

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'remove_double', text="Remove Double")

def extract_masked_part():

    # Go in object duplicate and deselect faces
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.duplicate_move()
    bpy.ops.object.shade_smooth()
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='DESELECT')

    # hide non masked faces
    bpy.ops.object.mode_set(mode='SCULPT')    
    bpy.ops.paint.hide_show_masked(action='HIDE')

    # Go in edit and delete those faces
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.normals_make_consistent(inside=False)
    bpy.ops.mesh.delete(type='FACE')

    # Clean Boundary
    bpy.ops.object.speedsculpt_clean_boundary()

    # Go in sculpt and unhide faces
    bpy.ops.object.mode_set(mode='SCULPT')
    bpy.ops.paint.hide_show_all(action='SHOW')

    bpy.ops.paint.mask_flood_fill(mode='VALUE', value=0)
    bpy.ops.object.mode_set(mode='OBJECT')

    bpy.ops.ed.undo_push(message="Add an undo step")

def delete_masked_part():

    #check the mode
    if bpy.context.object.mode != 'SCULPT':
        bpy.ops.object.mode_set(mode='SCULPT')

    # hide non masked faces
    bpy.ops.paint.mask_flood_fill(mode='INVERT')
    bpy.ops.paint.hide_show_masked(action='HIDE')

    # Go in edit and delete those faces
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.normals_make_consistent(inside=False)
    bpy.ops.mesh.delete(type='FACE')

    # Go in sculpt and unhide faces
    bpy.ops.object.mode_set(mode='SCULPT')
    bpy.ops.paint.hide_show_all(action='SHOW')

    bpy.ops.paint.mask_flood_fill(mode='VALUE', value=0)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='DESELECT')

    # Clean Boundary
    bpy.ops.object.speedsculpt_clean_boundary()

    bpy.ops.object.mode_set(mode='OBJECT')

    bpy.ops.ed.undo_push(message="Add an undo step")

def slice_mask():
    act_obj = bpy.context.active_object

    # Duplicate the mesh to a new object
    extract_masked_part()

    # Go back to object mode
    bpy.ops.object.mode_set(mode='OBJECT')

    # The new object is the only one selected now, set it as the active object
    new_obj = [obj for obj in bpy.context.selected_objects if obj != act_obj][0]
    bpy.context.view_layer.objects.active = new_obj
    new_obj.name = act_obj.name + "_EXTRACTED"

    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = act_obj
    act_obj.select_set(True)

    # remove the masked part
    delete_masked_part()

    new_obj.select_set(True)

    bpy.ops.ed.undo_push(message="Add an undo step")

def delete_face_set():

    act_obj = bpy.context.active_object

    mode = act_obj.mode
    # Select the faces
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')

    bpy.ops.mesh.delete(type='FACE')
    bpy.ops.object.mode_set(mode=mode)
    if act_obj.mode == 'SCULPT':
        if bpy.app.version < (4, 1, 0):
            bpy.ops.sculpt.reveal_all()
        else:
            bpy.ops.paint.hide_show_all(action='SHOW')
    
    bpy.ops.ed.undo_push(message="Add an undo step")

def extract_face_set():
    act_obj = bpy.context.active_object
    
    # Select the faces
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')

    # Duplicate the selected faces and separate them into a new object
    bpy.ops.mesh.duplicate_move()

    bpy.ops.mesh.separate(type='SELECTED')

    # Clean Boundary
    bpy.ops.object.speedsculpt_clean_boundary()

    # Go back to object mode
    bpy.ops.object.mode_set(mode='OBJECT')

    # deselect the first Object
    act_obj.select_set(False)

    # The new object is the only one selected now, set it as the active object
    new_obj = [obj for obj in bpy.context.selected_objects if obj != act_obj][0]
    bpy.context.view_layer.objects.active = new_obj
    new_obj.name = act_obj.name + "_EXTRACTED"

    bpy.ops.ed.undo_push(message="Add an undo step")

def slice_face_set():
    act_obj = bpy.context.active_object

    # Select the faces
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')

    # Duplicate the selected faces and separate them into a new object
    bpy.ops.mesh.duplicate_move()
    bpy.ops.mesh.separate(type='SELECTED')

    # Clean Boundary
    bpy.ops.object.speedsculpt_clean_boundary()

    # Go back to object mode
    bpy.ops.object.mode_set(mode='OBJECT')

    # The new object is the only one selected now, set it as the active object
    new_obj = [obj for obj in bpy.context.selected_objects if obj != act_obj][0]
    bpy.context.view_layer.objects.active = new_obj
    new_obj.name = act_obj.name + "_EXTRACTED"
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = act_obj
    act_obj.select_set(True)

    # Delete unwanted Faces
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.delete(type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.region_to_loop()

    # Clean Boundary
    bpy.ops.object.speedsculpt_clean_boundary()

    # Show the entire mesh
    bpy.ops.object.mode_set(mode='SCULPT')
    if bpy.app.version < (4, 1, 0):
        bpy.ops.sculpt.reveal_all()
    else:
        bpy.ops.paint.hide_show(action='SHOW')
    bpy.ops.object.mode_set(mode='OBJECT')

    new_obj.select_set(True)

    bpy.ops.ed.undo_push(message="Add an undo step")

def add_solidify():
    speedsculpt = bpy.context.scene.speedsculpt

    for obj in bpy.context.selected_objects:

        obj.select_set(state=True)
        bpy.context.view_layer.objects.active = obj

        mod_solidify = bpy.context.object.modifiers.new("Solidify", 'SOLIDIFY')
        mod_solidify.use_even_offset = True
        mod_solidify.use_quality_normals = True
        mod_solidify.offset = speedsculpt.solidify_offset
        mod_solidify.thickness = speedsculpt.solidify_thickness
        mod_solidify.use_rim_only = speedsculpt.rim_only

    bpy.ops.ed.undo_push(message="Add an undo step")

class SPEEDSCULPT_OT_apply_solidify(Operator):
    bl_idname = 'object.speedsculpt_apply_solidify'
    bl_label = "Apply Solidify Modifier"
    bl_options = {'REGISTER'}

    def execute(self, context):
        self.act_obj = context.active_object

        for obj in context.selected_objects:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            for mod in obj.modifiers:
                if mod.type == 'SOLIDIFY':
                    bpy.ops.object.modifier_apply(modifier=mod.name)

        self.act_obj.select_set(state=True)
        context.view_layer.objects.active = self.act_obj
        return {'FINISHED'}

# Remove the Mirror modifier
class SPEEDSCULPT_OT_remove_solidify(Operator):
    bl_idname = "object.speedsculpt_remove_solidify"
    bl_label = "Remove Solidify"
    bl_description = "Delete the Solidify modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        if context.object:
            for mod in context.object.modifiers:
                if mod.type == 'SOLIDIFY':
                    bpy.ops.object.modifier_remove(modifier="Solidify")
        return {"FINISHED"}

def check_hidden_faces(obj):
    """
    Checks if the given Blender object's mesh has any hidden faces.

    Parameters:
    obj (bpy.types.Object): The Blender object to check.

    Returns:
    bool: True if the mesh has hidden faces, False otherwise.
    """
    if obj and obj.type == 'MESH':
        # Ensure we're working on the mesh data
        mesh = obj.data
        # Check if any of the faces are hidden
        return any(face.hide for face in mesh.polygons)
    return False

class SPEEDSCULPT_OT_extract_operation(Operator):
    bl_idname = 'object.speedsculpt_extract_operation'
    bl_label = "Extract Operations"
    # bl_description = "FACE SET OPERATIONS\n\nEXTRACT - Duplicate the visible Face Set/Masked Part to a new Object\n\n" \
    #                  "CUT - Delete the Faces from the Face set/Masked Part\n\n" \
    #                  "SLICE - Slice the Mesh from the Face Set/Masked Part into two Objects\n\n" \
    #                  "Note: For the Face Set, you need to isolate it with SHIFT + H"

    face_set_mask_action : EnumProperty(
        items=(('extract_mask', "Extract Mask", "Extract the Masked Part to a new Object"),
               ('cut_mask', "Cut Mask", "Delete the Masked Part"),
               ('slice_mask', "Slice", "Slice the Mesh from the Face Set"),
               ('extract_face_set', "Extract Face Set", "Extract the visible Face Set to a new Object"),
               ('cut_face_set', "Cut Face Set", "Delete the visible Face Set"),
               ('slice_face_set', "Slice Face Set", "Slice the Mesh from the visible Face Set")),
        default='extract_mask'  
    ) # type: ignore

    @classmethod
    def description(cls, context, properties):
        if properties.face_set_mask_action == 'extract_mask':
            return f"FACE SET OPERATIONS\n\nEXTRACT - Duplicate the Masked Part to a new Object"
        elif properties.face_set_mask_action == 'cut_mask':
            return f"FACE SET OPERATIONS\n\nCUT - Delete the Faces from the Masked Part"
        elif properties.face_set_mask_action == 'extract_face_set':
            return f"FACE SET OPERATIONS\n\nEXTRACT - Duplicate the visible Face Set to a new Object\n\n" \
                     "Note: to make it work, you need to isolate the Face Set with SHIFT + H"
        elif properties.face_set_mask_action == 'cut_face_set':
            return f"FACE SET OPERATIONS\n\nCUT - Delete the visible Face Set\n\n" \
                     "Note: to make it work, you need to isolate the Face Set with SHIFT + H"






    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        auto_merge = bpy.context.scene.tool_settings.use_mesh_automerge
        context.scene.tool_settings.use_mesh_automerge = False

        # Store setting
        fill_holes = prefs.fill_holes
        update_r = prefs.update_remesh
        update_d = prefs.update_detail_flood_fill
        add_s = speedsculpt.add_solidify

        if self.face_set_mask_action == 'extract_mask':
            extract_masked_part()
            self.report({'INFO'}, "Mask Extracted")
        
        elif self.face_set_mask_action == 'extract_face_set':
            extract_face_set()
            self.report({'INFO'}, "Face Set Extracted")

        elif self.face_set_mask_action == 'cut_mask':
            delete_masked_part()
            self.report({'INFO'}, "Masked Part Removed")
        
        elif self.face_set_mask_action == 'cut_face_set':
            delete_face_set()
            self.report({'INFO'}, "Face Set Part Removed")

        elif self.face_set_mask_action == 'slice_mask':
            slice_mask()
            self.report({'INFO'}, "Masked Part Sliced")
        
        elif self.face_set_mask_action == 'slice_face_set':
            slice_face_set()
            self.report({'INFO'}, "Face Set Part Sliced")

        if speedsculpt.add_solidify:
            add_solidify()

        fill_hole = prefs.fill_holes

        # Update Remesh Or Dyntopo
        if prefs.dyntopo_or_remesh == 'remesh':
            if prefs.update_remesh:
                prefs.fill_holes = True
                bpy.ops.object.speedsculpt_remesh_selection()
                prefs.fill_holes = fill_hole
                prefs.update_remesh = update_r

        elif prefs.dyntopo_or_remesh == 'dyntopo':
            if prefs.update_detail_flood_fill:
                prefs.fill_holes = True
                bpy.ops.object.update_dyntopo()
                prefs.fill_holes = fill_hole
                prefs.update_detail_flood_fill = update_d

        # Go back in Sculpt
        if speedsculpt.comeback_in_sculpt_mode:
            bpy.ops.object.mode_set(mode='SCULPT')

        speedsculpt.add_solidify = add_s
        prefs.fill_holes = fill_holes
        prefs.update_remesh = update_r
        prefs.update_detail_flood_fill = update_d

        context.scene.tool_settings.use_mesh_automerge = auto_merge
        return {'FINISHED'}

CLASSES =  [SPEEDSCULPT_OT_clean_boundary,
            SPEEDSCULPT_OT_extract_operation,
            SPEEDSCULPT_OT_apply_solidify,
            SPEEDSCULPT_OT_remove_solidify,
            SPEEDSCULPT_OT_add_extract_mask,
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
        
                        