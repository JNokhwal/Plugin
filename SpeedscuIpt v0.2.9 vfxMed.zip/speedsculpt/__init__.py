'''-*- coding:utf-8 -*-
SpeedSculpt Add-on
Copyright (C) 2020 Cedric Lepiller aka Pitiwazou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

<pep8 compliant>'''

bl_info = {
    "name": "SpeedSculpt",
    "description": "Create models for sculpt and manage Dyntopo sculpt",
    "author": "pitiwazou",
    "version": (0, 2, 9),
    "blender": (4, 3, 2),
    "location": "Property Panel, Press N in the 3DView",
    "doc_url": "https://blscripts.notion.site/SPEEDSCULPT-607c7a94883248b6aed67ded368714f4",
    "category": "3D View"}

# Import des modules
if "bpy" in locals():
    import importlib
    reloadable_modules = [
        "armature",
        "curves",
        "extract_mask",
        "lattice",
        "operators",
        "primitives",
        "quick_pose",
        "remesh_decimate",
        "solo",
        "symmetrize",
        "ui",
        "preview",
        "modals",
        "cutter"
    ]
    for module in reloadable_modules:
        if module in locals():
            importlib.reload(locals()[module])

from . import  (armature,
                curves,
                extract_mask,
                functions,
                operators,
                lattice,
                operators,
                primitives,
                quick_pose,
                remesh_decimate,
                solo,
                symmetrize,
                ui,
                preview,
                modals,
                cutter,
                )

import bpy
from bpy.types import Operator, Menu, Panel, PropertyGroup, AddonPreferences, Scene, WindowManager, BlendData
from bpy.props import (StringProperty,
                       BoolProperty,
                       PointerProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       BoolVectorProperty,
                       CollectionProperty)
import urllib.request
import json
import sys
import os
from .ui import *
from .icon.icons import load_icons
from .remesh_decimate import RemeshOctreeDepth
from .primitives import UpdateMetaballs, ClippingMerge
from .lattice import HideLattice, LatticeInterpolation
from .remesh_decimate import HideRemeshSmooth,RemeshSmoothRepeat, Hidedecimate, DecimateRatio
from .functions import *
import rna_keymap_ui
from bpy.app.handlers import persistent

##------------------------------------------------------  
#
# Preferences
#
##------------------------------------------------------  

# CATEGORY
def SC_update_panel(self, context):
    prefs = context.preferences.addons[__name__].preferences
    if hasattr(bpy.types, 'SPEEDSCULPT_PT_panel'):
        try:
            bpy.utils.unregister_class(bpy.types.SPEEDSCULPT_PT_panel)
        except:
            pass
    SPEEDSCULPT_PT_panel.bl_category = prefs.category
    bpy.utils.register_class(SPEEDSCULPT_PT_panel)

# -----------------------------------------------------
# LIBRARY
# -----------------------------------------------------
class SPEEDSCULPT_PropertyGroup_categories(PropertyGroup):
    path : StringProperty(subtype = 'DIR_PATH') # type: ignore

class SPEEDSCULPT_OT_add_categories_path(Operator):
    bl_idname = "object.speedsculpt_add_categories_path"
    bl_label = "Add Categories Path"
    bl_description = ""
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        addon_pref = get_addon_preferences()
        addon_pref.categories.add()
        return {'FINISHED'}

class SPEEDSCULPT_OT_remove_categories_path(Operator):
    bl_idname = "object.speedsculpt_remove_categories_path"
    bl_label = "Add Categories Path"
    bl_description = ""
    bl_options = {'REGISTER', 'UNDO'}

    index : IntProperty() # type: ignore

    def execute(self, context):
        addon_pref = get_addon_preferences()
        addon_pref.categories.remove(self.index)
        return {'FINISHED'}

def call_back_enum(self, context):
    addon_pref = get_addon_preferences()
    directory = os.path.join(os.path.dirname(__file__), "library")
    mes_reps = ["body_parts", "muscles"]
    categories = [(os.path.join(directory, rep), rep, "" ) for rep in mes_reps]

    for cat in addon_pref.categories:
        root, dirs, files = next(os.walk(cat.path)) # on liste le path, reps et noms de fichiers
        if "files" in dirs and "icons" in dirs:
            categories.append((cat.path, os.path.basename(os.path.abspath(cat.path)), ""))

    return categories

def check_for_updates_and_notify():
    # Define the addon name; usually, this should be dynamically set to __name__ in real scenarios
    addon_idname = __name__

    # URL where the JSON file is hosted
    url = 'https://www.blscripts.com/blscripts_addons_updates.json'
    response = urllib.request.urlopen(url)
    data = json.load(response)

    # Get local version from bl_info directly
    local_version = bl_info['version']
    local_version_str = '.'.join(map(str, local_version))  # Convert tuple to string for comparison

    update_message = ""

    # Check for update specific to this addon
    if addon_idname in data:
        addon_data = data[addon_idname]
        if local_version_str != addon_data['version'] and addon_data['version'] > local_version_str:
            update_message = f"New version available: {addon_data['version']} (current: {local_version_str})\n"
            print("Add-on Name: " + addon_idname + "New Version: " + addon_data['version'])
        else:
            update_message = "No updates available."
            print(addon_idname + ": No Update Available")
    else:
        update_message = "No updates available."
        print(addon_idname + ": No Update Available")

    # Set the update message in preferences
    preferences = bpy.context.preferences.addons[addon_idname].preferences
    preferences.update_available = update_message

    return update_message

class SPEEDSCULPT_OT_check_updates(bpy.types.Operator):
    bl_idname = "wm.speedsculpt_check_updates"
    bl_label = "Check for Updates"

    def execute(self, context):
        check_for_updates_and_notify()
        update_message = check_for_updates_and_notify()
        self.report({'INFO'}, update_message)
        return {'FINISHED'}

class SPEEDSCULPT_MT_addon_prefs(AddonPreferences):
    bl_idname = __name__
        
    prefs_tabs : EnumProperty(
        items=(('info', "Info", "Information about the Addon"),
               ('options', "Options", "Options of the Addon"),
               ('keymaps','Keymaps', 'Keymaps of the addon'),
               ('links', "Links", "Links")),
               default='info'
               ) # type: ignore
    category : StringProperty(name="Category",description="Choose a name for the category of the panel",default="Tools",
            update=SC_update_panel) # type: ignore
    show_help : BoolProperty(default=True,description="Show the help on the Addon", name="") # type: ignore
    auto_save : BoolProperty(default=True,description="Auto save the scene when updating a mesh or making booleans", name="") # type: ignore
    smooth_mesh : BoolProperty(default=True,description="\nAdd a Smooth Modifier when updating the REMESH/DYNTOPO.\n\nYou can Edit the Value of the Remesh in the Settings", name="") # type: ignore
    smooth_mesh_value: IntProperty(min=1,max=10,default=2,description="Smooth Mesh Value", name="") # type: ignore
    fill_holes : BoolProperty(default=False,description="Close holes on the mesh", name="") # type: ignore
    update_detail_flood_fill : BoolProperty(default=True,description="Triangulate the Mesh", name="") # type: ignore
    add_remesh : BoolProperty(default=False,description="Add a Remesh Modifier to cut objects", name="") # type: ignore
    remesh_value : IntProperty(min=0,max=15,default=6,description="remesh value",update=RemeshOctreeDepth, name="") # type: ignore
    apply_mirror: BoolProperty(default=False, description="Apply Mirror") # type: ignore
    mirror_settings: BoolProperty(default=False, description="Show Mirror Settings") # type: ignore
    mirror_smooth_settings: BoolProperty(default=False, description="Show Mirror Settings") # type: ignore
    # SOLO
    sc_solo_color: FloatVectorProperty(name="", default=(0.2, 0.7, 1, 0.3), min=0, max=1, size=4,
                                       subtype='COLOR_GAMMA') # type: ignore
    remesh_description = "Use REMESH to automatically rebuild the geometry into Quads.\n\n" \
                         "It's faster than Dyntopo and then it's better to use it to Combine/Cut or Rebool Objects.\n\n" \
                         "You can select several Objects and combine them on the fly.\n\n" \
                         "Note: When Updating, it will Remesh the entire Mesh, you will lose details."
    dyntopo_description = "Use DYNTOPO to add details to your Sculpting.\n\n" \
                          "Dyntopo is a dynamic tessellation sculpting method that produce Tris.\n\n" \
                          "It preserve details when updating it contrary to REMESH."
    dyntopo_or_remesh : EnumProperty(
        items=(('remesh', "REMESH", remesh_description, "SPHERE", 0),
               ('dyntopo', "DYNTOPO", dyntopo_description, "MESH_ICOSPHERE", 1)),
        default='remesh') # type: ignore
    # REMESH
    remesh_mesh_value_description = "\n"\
                                    "Value for the Remeshing in Quads.\n" \
                                    "Smaller Value gives smaller quads.\n\n" \
                                    "Note: With huge Meshes and small values, it can take time,\n" \
                                    "make some tests before if you can"
    remesh_mesh_value: FloatProperty(default=0.1,min=0.0001, max=1000,precision=3,description=remesh_mesh_value_description, name="REMESH VALUE") # type: ignore
    remesh_mesh_voxel_adaptivity: FloatProperty(default=0,min=0, max=10,precision=3,description="Remesh Voxel Adaptivity") # type: ignore
    remesh_mesh_smooth_normals: BoolProperty(default=True,description="Smooth the normals of the mesh", name="") # type: ignore
    remesh_mesh_use_remesh_preserve_volume: BoolProperty(default=True,description="Preserve Volume", name="") # type: ignore
    remesh_mesh_preserve_paint_mask: BoolProperty(default=False,description="Preserve Paint Mask") # type: ignore
    remesh_mesh_fix_poles: BoolProperty(default=True,description="Fix Poles", name="") # type: ignore
    remesh_mesh_preserve_sculpt_face_sets: BoolProperty(default=False,description="Preserve Sculpt Face Sets", name="") # type: ignore
    remesh_mesh_preserve_attributes: BoolProperty(default=False,description="Preserve Attributes", name="") # type: ignore
    update_remesh: BoolProperty(default=True, 
                                description="\nUpdate the Topology of the mesh in REMESH/DYNTOPO according to the Settings.\n\n" \
                                "You can disable it if you want to only make some Operations.\n" \
                                "It will not Remesh the Mesh.", 
                                name="Update Topology") # type: ignore
    remesh_mesh_preserve_vertex_colors: BoolProperty(default=False,description="Preserve Vertex Color", name="") # type: ignore
    modal_smooth: BoolProperty(default=True, description="Adjust the Smooth of the Mesh with the mouse", name="") # type: ignore
    # LIBRARY
    show_path_info: BoolProperty(default=False) # type: ignore
    preview_scale: IntProperty(name="", default=4, min=2, max=10, description="Size of the Preview Images") # type: ignore
    preview_scale_popup: IntProperty(name="", default=5, min=2, max=10, description="Size of the Preview Images in the Popup") # type: ignore
    preview_show_labels: BoolProperty(name='', default=True, description="Show the Label of the Images") # type: ignore
    categories: CollectionProperty(type=SPEEDSCULPT_PropertyGroup_categories) # type: ignore
    # SHOWS
    show_remesh_settings: BoolProperty(default=False, description="Show/Hide Remesh Settings") # type: ignore
    show_dyntopo_settings: BoolProperty(default=False, description="Show/Hide Dyntopo Settings") # type: ignore
    show_library_settings: BoolProperty(default=False, description="Show/Hide Assets Library Settings") # type: ignore
    show_general_settings: BoolProperty(default=True, description="Show/Hide General Settings") # type: ignore
    show_shading_settings: BoolProperty(default=True, description="Show/Hide Shading Settings") # type: ignore
    show_references_settings: BoolProperty(default=True, description="Show/Hide References Settings") # type: ignore
    show_extract_remesh_settings: BoolProperty(default=False, description="Show/Hide Extract Settings") # type: ignore
    show_extract_dyntopo_settings: BoolProperty(default=False, description="Show/Hide Extract Settings") # type: ignore
    show_face_set_settings: BoolProperty(default=False, description="Show/Hide Face Set Settings") # type: ignore
    show_mask_settings: BoolProperty(default=False, description="Show/Hide Face Set Settings") # type: ignore
    show_geomesh: BoolProperty(default=False, description="Show/Hide Geomesh Settings") # type: ignore

    
    add_smooth_remesh_modal: BoolProperty(default=True, name="", description="Add Smooth Remesh Modal") # type: ignore

    info: BoolProperty(
        name="",
        default=False,
        description="INFO") # type: ignore
    
    update_available: bpy.props.StringProperty(
        name="Update Available",
        description="Message indicating if there is an update available.",
        default="") # type: ignore

    check_for_updates: BoolProperty(name="Check for Updates",description="Check for Updates",default=False)# type: ignore
    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        wm = context.window_manager

        row= layout.row(align=True)
        row.scale_y = 1.5   
        row.prop(self, "prefs_tabs", expand=True)
        if self.prefs_tabs == 'info':

            # UPDATE
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.prop(self, "check_for_updates")
            if self.check_for_updates:
                show_update = False
                if bpy.app.version < (4, 1, 0):
                    show_update = True

                elif bpy.app.version >= (4, 2, 0) and bpy.context.preferences.system.use_online_access:
                        show_update = True
                
                # box = layout.box()
                if show_update:
                    row = box.row(align=True)
                    update = True if self.update_available == "No updates available." else False
                    row.alert = update
                    row.label(text=self.update_available if self.update_available else "No updates available.")
                    row.alert = False
                    row.operator("wm.speedsculpt_check_updates", text="Check for Updates", icon='FILE_REFRESH')
                
                if bpy.app.version >= (4, 2, 0):
                    if not bpy.context.preferences.system.use_online_access:
                        row = box.row(align=True)
                        row.alert = True
                        row.label(text="Activate Allow Online Acess in the System/Network to check for updates", icon="ERROR")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="BLENDER MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/speedsculpt"
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://pitiwazou-1.gumroad.com/l/SpeedSculpt"
            icon = icons.get("icon_artstation")
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://pitiwazou.artstation.com/store/JmKn/speedsculpt"

            # CUSTOMERS
            box = layout.box()
            icon = icons.get("icon_discord")
            row = box.row(align=True)
            row.scale_y = 2
            row.operator("wm.url_open", text="SUPPORT ON DISCORD FOR CUSTOMERS",
                         icon_value=icon.icon_id).url = "https://discord.gg/8M8mFVegZ8"
            row.scale_x = 2
            row.prop(self, 'info', icon='INFO')
            if self.info:
                box = layout.box()
                split = box.split()
                col = split.column()
                row = col.row(align=True)
                row.label(text="Join our Discord community for customer support! As a valued customer, you’ll gain access to exclusive benefits:")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="1. Add-on Support Channel: To access this channel, simply send us a copy of your receipt to our email address below.")
                row = col.row(align=True)
                row.label(text="2. Latest Builds: Stay up-to-date with the latest builds of our add-ons.")
                row = col.row(align=True)
                row.label(text="3. Feature Requests: Have a feature in mind? Feel free to ask—we’re here to listen!")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="🔗 Discord Invite Link: https://discord.gg/8M8mFVegZ8")
                row = col.row(align=True)
                row.label(text="📧 Email: mail.blscripts@gmail.com")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="Thank you for supporting our work! If you haven’t purchased the add-on yet, ")
                row = col.row(align=True)
                row.label(text="consider doing so it helps sustain years of effort and support for all our add-ons.")

            box = layout.box()
            box.label(text="Welcome to SpeedSculpt, this addon allows you to create objects for sculpting")
            box.label(text="You can make booleans, adjust the Detail Size etc")
            box.separator()
            box.label(text="Note: The Addon is located in the Property Panel, Press N in the 3DView.")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_youtube")
            row.operator("wm.url_open", text="DOCUMENTATION",
                            icon_value=icon.icon_id).url = "https://youtu.be/6BFCV7jobrM"

        if self.prefs_tabs == 'options':

    # ----- GENERAL SETTINGS
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="", icon='SETTINGS')
            row.prop(self, "show_general_settings", text="GENERAL SETTINGS",
                     icon='TRIA_UP' if self.show_general_settings else 'TRIA_RIGHT')
            if self.show_general_settings:
                split = box.split()
                col = split.column()
                col.label(text="Change Category")
                col = split.column(align=True)
                col.prop(self, "category", text="")

                box = layout.box()
                split = box.split()
                col = split.column()
                col.label(text="Show Help")
                col = split.column(align=True)
                col.prop(self, "show_help")

                if sys.platform.startswith('win'):
                    split = box.split()
                    col = split.column()
                    col.label(text="Auto Save Scene")
                    col = split.column(align=True)
                    col.prop(self, "auto_save")

                box = layout.box()
                split = box.split()
                col = split.column()
                col.label(text="Smooth the Mesh")
                col = split.column(align=True)
                col.prop(self, "smooth_mesh")

                split = box.split()
                col = split.column()
                col.label(text="Smooth Mesh Value")
                col = split.column(align=True)
                col.prop(self, "smooth_mesh_value", text="")

                split = box.split()
                col = split.column()
                col.label(text="Fill Holes")
                col = split.column(align=True)
                col.prop(self, "fill_holes")

                split = box.split()
                col = split.column()
                col.label(text="Add Smooth in the Remesh Modal")
                col = split.column(align=True)
                col.prop(self, "add_smooth_remesh_modal", text="")


    # ----- REMESH SETTINGS
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="", icon='SPHERE')
            row.prop(self, "show_remesh_settings", text="REMESH SETTINGS",
                     icon='TRIA_UP' if self.show_remesh_settings else 'TRIA_RIGHT')
            if self.show_remesh_settings:
                split = box.split()
                col = split.column()
                col.label(text="Remesh Value")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_value", text="")

                split = box.split()
                col = split.column()
                col.label(text="Voxel Adaptibility")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_voxel_adaptivity", text="")

                split = box.split()
                col = split.column()
                col.label(text="Fix Poles")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_fix_poles")

                if bpy.app.version < (4, 1, 0):
                    split = box.split()
                    col = split.column()
                    col.label(text="Smooth Normals")
                    col = split.column(align=True)
                    col.prop(self, "remesh_mesh_smooth_normals")

                split = box.split()
                col = split.column()
                col.label(text="Preserve Volume")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_use_remesh_preserve_volume")

                if bpy.app.version < (4, 1, 0):
                    split = box.split()
                    col = split.column()
                    col.label(text="Preserve Paint Mask")
                    col = split.column(align=True)
                    col.prop(self, "remesh_mesh_preserve_paint_mask")

                    split = box.split()
                    col = split.column()
                    col.label(text="Preserve Sculpt Face Sets")
                    col = split.column(align=True)
                    col.prop(self, "remesh_mesh_preserve_sculpt_face_sets")

                    split = box.split()
                    col = split.column()
                    col.label(text="Preserve Vertex Colors")
                    col = split.column(align=True)
                    col.prop(self, "remesh_mesh_preserve_vertex_colors")

                if bpy.app.version >= (4, 1, 0):
                    split = box.split()
                    col = split.column()
                    col.label(text="Preserve Attributes")
                    col = split.column(align=True)
                    col.prop(self, "remesh_mesh_preserve_attributes")

                split = box.split()
                col = split.column()
                col.label(text="Modal Smooth")
                col = split.column(align=True)
                col.prop(self, "modal_smooth")


    # ----- DYNTOPO SETTINGS
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="", icon='MESH_ICOSPHERE')
            row.prop(self, "show_dyntopo_settings", text="DYNTOPO SETTINGS",
                     icon='TRIA_UP' if self.show_dyntopo_settings else 'TRIA_RIGHT')
            if self.show_dyntopo_settings:
                split = box.split()
                col = split.column()
                col.label(text="Update the Mesh")
                col = split.column(align=True)
                col.prop(self, "update_detail_flood_fill")

                split = box.split()
                col = split.column()
                col.label(text="Smooth Shading")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_smooth_normals")

                split = box.split()
                col = split.column()
                col.label(text="Add Remesh Modifier to cut object")
                col = split.column(align=True)
                col.prop(self, "add_remesh")

                split = box.split()
                col = split.column()
                col.label(text="Remesh Value")
                col = split.column(align=True)
                col.prop(self, "remesh_value", text="")

    # ----- SHADING
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="", icon='SHADING_RENDERED')
            row.prop(self, "show_shading_settings", text="SHADING",
                     icon='TRIA_UP' if self.show_shading_settings else 'TRIA_RIGHT')
            if self.show_shading_settings:
                split = box.split()
                col = split.column()
                col.label(text="Solo Color")
                col = split.column(align=True)
                col.prop(self, "sc_solo_color", text="")

    # ----- LIBRARY
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="", icon='MONKEY')
            row.prop(self, "show_library_settings", text="ASSETS LIBRARY SETTINGS",
                     icon='TRIA_UP' if self.show_library_settings else 'TRIA_RIGHT')
            if self.show_library_settings:
                split = box.split()
                col = split.column()
                row = col.row(align=True)
                row.label(text="ASSET LIBRARY SETTINGS")
                row = col.row(align=True)
                row.label(text="Preview Thumbnails Scale")
                row.prop(self, "preview_scale")
                row = col.row(align=True)
                row.label(text="Popup Thumbnails Scale")
                row.prop(self, "preview_scale_popup")
                row = col.row(align=True)
                row.label(text="Show thumbnails Labels")
                row.prop(self, "preview_show_labels", text="      ")

                split = box.split()
                col = split.column()
                row = col.row(align=True)
                row.label(text="LIBRARY PATH")
                row.alignment = 'RIGHT'
                row.scale_y = 1.5
                row.operator("object.speedsculpt_add_categories_path", text="ADD NEW CATEGORY", icon='ADD')
                row.prop(self, "show_path_info", text="", icon='QUESTION')

                if self.show_path_info:
                    box = layout.box()
                    box.label(text="ADD ASSET MANAGEMENT PATH", icon='QUESTION')
                    box.label(text="")
                    box.label(text="To add assets from the Asset Management Addon, you need to select a category.")
                    box.label(text="")
                    box.label(text="- Click on 'ADD NEW CATEGORY'", icon='ADD')
                    box.label(text="- A new Path will be created", icon='GRIP')
                    box.label(text="- Click on the folder", icon='FILEBROWSER')
                    box.label(text="- Go to you Asset Management library", icon='MENU_PANEL')
                    box.label(text="- Enter in a category", icon='COPY_ID')
                    box.label(text="- Press ENTER to validate", icon='EVENT_RETURN')
                    box.label(text="")
                    box.label(text="Note 1:", icon='INFO')
                    box.label(text="A Category is a directory and inside it, you have 2 folders")
                    box.label(text="'files'", icon='BLENDER')
                    box.label(text="'icons'", icon='IMAGE_DATA')
                    box.label(text="If you don't see them, you are not in a Category")
                    box.label(text="")
                    box.label(text="Note 2:", icon='INFO')
                    box.label(text="If you don't have the Asset Management Add-on,")
                    box.label(text="you still can add another library or create your own")
                    box.label(text="You just need to follow the same hierarchy")
                    box.label(text="")
                    box.label(text="LIBRARY FOLDER > CATEGORY > files and icons")
                    box.label(text="")
                    box.label(text="You can add as many categories as you want!")
                    box.label(text="")
                    box.label(text="Note 3:", icon='INFO')
                    box.label(text="Even if you could copy files into the addon library,")
                    box.label(text="It's better to add a custom path to an external library.")
                    box.label(text="You will not lose your files when updating the addon.")

                for index, cat in enumerate(self.categories):
                    if self.show_path_info:
                        box = layout.box()
                        split = box.split()
                        col = split.column()

                    row = col.row(align=True)
                    row.prop(cat, 'path', text="")
                    row.operator('object.speedsculpt_remove_categories_path', text="", icon='REMOVE').index = index

        if self.prefs_tabs == 'keymaps':
            AddonKeymaps.draw_keymap_items(wm, layout)
            box = layout.box()
            split = box.split()
            col = split.column()
            row = col.row(align=True)
            row.label(text="If you want to use the same keys as blender for the remesh and Voxel Size")
            row = col.row(align=True)
            row.label(text="Disable them in the Blender Preference > Keymap")
            row = col.row(align=True)
            row.label(text="And set the Speedsculpt Keymaps with the keys")
            row = col.row(align=True)
            row.label(text="Remesh: CTRL + R")
            row = col.row(align=True)
            row.label(text="Voxel Size: SHIFT + R")
            row = col.row(align=True)
            row.operator("wm.url_open", text="EDIT BLENDER KEYMAPS",
                         icon ='FILE_MOVIE').url = "http://blscripts.com/speedsculpt_videos/Speedsculpt_keymaps.mp4"
            #

        if self.prefs_tabs == 'links':

            # TUTORIALS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="TUTORIALS & ADD-ONS")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://pitiwazou-1.gumroad.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            row.operator("wm.url_open", text="GUMROAD - SPEEDFLOW",
                         icon_value=icon.icon_id).url = "https://pitiwazou.gumroad.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/creators/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_artstation")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/a/651436"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_flipped_normals")
            row.operator("wm.url_open", text="FLIPPED NORMALS",
                         icon_value=icon.icon_id).url = "https://flippednormals.com/creator/pitiwazou?tagIds=1"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_youtube")
            row.operator("wm.url_open", text="YOUTUBE",
                         icon_value=icon.icon_id).url = "https://www.youtube.com/user/pitiwazou"

            # LINKS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SOCIAL")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_web")
            row.operator("wm.url_open", text="PITIWAZOU.COM",
                         icon_value=icon.icon_id).url = "http://www.pitiwazou.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_artstation")
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/artist/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_twitter")
            row.operator("wm.url_open", text="TWITTER",
                         icon_value=icon.icon_id).url = "https://twitter.com/#!/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_facebook")
            row.operator("wm.url_open", text="FACEBOOK",
                         icon_value=icon.icon_id).url = "https://www.facebook.com/Pitiwazou-C%C3%A9dric-Lepiller-120591657966584/"

# -----------------------------------------------------
# PROPERTYGROUP
# -----------------------------------------------------
class SPEEDSCULPT_GeomeshItem(PropertyGroup):
    name: StringProperty(name="Name") # type: ignore
    value: StringProperty(name="Value") # type: ignore

class SPEEDSCULPT_PropertyGroup(bpy.types.PropertyGroup):
    boolean_operation: EnumProperty(
        items=(('union', "Union", "Make an Union (Boolean Operations can take time)"),
               ('difference', "Difference", "Remove a part of your Mesh (Boolean Operations can take time)"),
               ('rebool', "rebool", "Slice the active object from your selection (Boolean Operations can take time)")),
        default='union') # type: ignore
    sculpt_mode : BoolProperty(default=False,description="The Active Object is in sculpt mode") # type: ignore
    ref_obj: PointerProperty(type=bpy.types.Object) # type: ignore
    create_primitives: EnumProperty(
        items=(('mouse', "Mouse", "MOUSE\n\nCreate the Primitive on your mouse to place it in the 3Dview."),
               ('origin', "Origin", "ORIGIN\n\nCreate the primitive at the scene origin, regardless of cursor location and rotation."),
               ('cursor', "Cursor", "CURSOR\n\nCreate the Primitive on the Cursor.\nYou can use the Cursor Rotation Option Just below"),
               ('selection', "Selection", "SELECTION\n\nCreate the Primitive on the selection.\nIf you selected several Objects, it will Create the primitive at the Center of them.")),
        default='origin') # type: ignore
    copy_cursor_orientation: BoolProperty(name="Cursor Rotation",default=False, description="Copy Cursor Orientation for the Primitives/Assets") # type: ignore
    add_mirror : BoolProperty(default=False,description="Add a Mirror Modifier to the New Object.\n\nIt will take the current Selection as Reference Object for the Modifier.", update=set_ref_obj) # type: ignore
    mirror_x : BoolProperty(default=True,description="X Axis") # type: ignore
    mirror_y : BoolProperty(default=False,description="Y Axis") # type: ignore
    mirror_z : BoolProperty(default=False,description="Z Axis") # type: ignore
    primitives_parenting : BoolProperty(default=False,description="Make the new object children to the active object") # type: ignore
    metaballs_pos_neg : EnumProperty(
        items=(('positive', "Positive", ""),
               ('negative', "Negative", "")),
        default='positive',
        update=UpdateMetaballs) # type: ignore
    use_clipping : BoolProperty(default=False,description="Use Clipping/Merger",update=ClippingMerge) # type: ignore
    # CURVE
    bbox : BoolProperty(default=False, description="Add Solidify") # type: ignore
    direct_cut : BoolProperty(default=False, description="Cut Directly the mesh") # type: ignore
    direct_rebool : BoolProperty(default=False, description="Directly Rebool") # type: ignore
    create_lathe : BoolProperty(default=False, description="Create Lathe") # type: ignore
    bbox_bevel : FloatProperty(min=0, max=100, default=0.1,description="Bbox Bevel") # type: ignore
    bbox_depth : FloatProperty(min=0, max=100, default=1,description="Bbox Depth") # type: ignore
    bbox_offset : FloatProperty(min=-100, max=100, default=-0.1,description="Bbox Offset") # type: ignore
    bbox_apply_solidify : BoolProperty(default=True,description="Apply solidify") # type: ignore
    bbox_convert : BoolProperty(default=False,description="Convert to Dyntopo") # type: ignore
    smooth_result : BoolProperty(default=False,description="Smooth the object") # type: ignore
    
    # LATTICE
    copy_orientation : BoolProperty(name="Copy orientation",description="Copy the orientation of the active Object",
                                    default=False) # type: ignore
    hide_lattice : BoolProperty(default=True,description="Hide Lattice on selected objects",update=HideLattice) # type: ignore
    lattice_u : IntProperty(min=2, max=100, default=2) # type: ignore
    lattice_v : IntProperty(min=2, max=100, default=2) # type: ignore
    lattice_w : IntProperty(min=2, max=100, default=2) # type: ignore
    lattice_interp : EnumProperty(
        items=(('KEY_LINEAR', 'linear', ""),
               ('KEY_BSPLINE', 'bspline', ""),
               ('KEY_CATMULL_ROM', 'catmull_rom', ""),
               ('KEY_CARDINAL', 'cardinal', "")),
        default='KEY_BSPLINE',
        update=LatticeInterpolation) # type: ignore
    
    # REMESH
    hide_remesh_smooth : BoolProperty(default=True,description="Hide Remesh and smooth",update=HideRemeshSmooth) # type: ignore
    remesh_smooth_repeat : IntProperty(min=0,max=100,default=10,update=RemeshSmoothRepeat) # type: ignore
    
    # DECIMATE
    hide_decimate : BoolProperty(default=True,description="Hide Decimate",update=Hidedecimate) # type: ignore
    decimate_ratio : FloatProperty(min=0,max=1,default=1,update=DecimateRatio,description="Decimate Ratio") # type: ignore
    
    # EXTRACT MASK
    extract_cut_delete : EnumProperty(
        items=(('extract', "Extract", "Extract Mask to New Object"),
               ('cut', "Cut", "Cut the Masked Part"),
               ('duplicate', "Duplicate", "Duplicate the Masked Part")),
        default='extract') # type: ignore
    face_set_or_mask_operation : EnumProperty(
            items=(('FACE_SET', "Face Sets", ""),
                   ('MASK', "Mask", ""),
                   ),
            default='FACE_SET',
            description="Select the Operation you want to perform") # type: ignore
    add_solidify : BoolProperty(name="Add Solidify",description="Add Solidify to the extracted object",default=False) # type: ignore
    comeback_in_sculpt_mode : BoolProperty(default=False, description="Comme Back in Sculpt mode",) # type: ignore
    apply_solidify : BoolProperty(default=True,description="Apply Solidify") # type: ignore

    update_dyntopo : BoolProperty(default=True,description="Update Dyntopo") # type: ignore
    rim_only : BoolProperty(default=False,name="Rim Only",description="Use Rim Only") # type: ignore
    solidify_thickness : FloatProperty(min=0.01, max=300, default=0.1,description="Solidify Thickness") # type: ignore
    solidify_offset : FloatProperty(min=-1, max=1, default=0.6,description="Solidify Offset") # type: ignore
    
    # QUICK POSE
    use_mask : BoolProperty(name="Use Mask",description="Use Mask",default=True) # type: ignore
    
    # SHOW/HIDE MENUS
    show_options : BoolProperty(default=False,description="\nSettings for REMESH/DYNTOPO\n\nYou can setup the Remeshing in this menu.", name="SETTINGS") # type: ignore
    show_basic_primitives: BoolProperty(default=False, description="PRIMITIVES\n\nAdd Basic Primitive to your Scene.\n\n" \
                                        "They will use the Options Selected UPDATE REMESH/MOUSE/ORIGIN/CURSOR ROTATION, etc.\n\n" \
                                        "You can combine POLY and METABALLS Primitives.") # type: ignore
    show_shading : BoolProperty(default=False,description="SHADING SETTINGS\n\nEdit the settings of the Shading for the Viewport.") # type: ignore
    creation_tools_description = "CREATION TOOLS\n\n" \
                                 "A bunch of Tools to create your sculpts as fast as possible!\n" \
                                 "You can add Primitives or assets from your library and combine them.\n\n" \
                                 "There are also other usefull Tools"
    show_creation_tools : BoolProperty(default=False,description=creation_tools_description, name="CREATION TOOLS") # type: ignore
    show_extract : BoolProperty(default=False,description="MASK TOOLS\n\nExtract, Duplicate, etc, parts of your Mesh using Masks") # type: ignore
    show_symmetrize : BoolProperty(default=False,description="SYMMETRIZE TOOLS\n\nSymmetrize your Mesh by choosing the direction") # type: ignore
    show_remesh : BoolProperty(default=False,description="REMESH TOOLS\n\nREMESH/DECIMATE/RETOPOLOGIZE your Mesh") # type: ignore
    show_lattice : BoolProperty(default=False,description="LATTICE TOOLS\n\nCreate a Lattice from Selection of Mask") # type: ignore
    show_quickpose : BoolProperty(default=False,description="QUICK POSE TOOLS\n\nMake a Quick Pose of your Mesh or only a part of it using Masks") # type: ignore
    show_geo_remesh : BoolProperty(default=False,description="GEO REMESH TOOLS\n\nCreate a Geo Remesh from Selection of Mask") # type: ignore
    show_muscles : BoolProperty(default=False,description="MUSCLES TOOLS\n\nCreate Muscles from the Library") # type: ignore
    show_draw_mesh: BoolProperty(default=False, description="DRAW MESH TOOLS\n\nDraw Mesh in the 3Dview.\nYou can set the Size in the Settings") # type: ignore
    show_cutter: BoolProperty(default=False, description="CUTTER TOOLS\n\nCut or Create Meshes") # type: ignore
    show_draw_surface: BoolProperty(default=False, 
                                    description="SURFACE TOOL\n\nCreate Mesh in the 3Dview on on the surface of other Meshes.\n\n" \
                                    "You can Edit the Settings") # type: ignore
    
    # LIBRARY
    show_asset_lib: BoolProperty(default=False, description="ASSET LIBRARY\n\n" \
                                "Add Asset from your Library to the Scene.\n\n" \
                                "You can add your own Assets to the Library or link Assets from The Asset Management Addon.\n\n" \
                                "Check the Preferences of the Addon.") # type: ignore
    ui_categories : EnumProperty(name="", items=call_back_enum) # type: ignore
    snap_to_faces : BoolProperty(default=False, description="Snap To Faces", update=snap_faces) # type: ignore
    
    # DRAW REMESH
    draw_remesh_size : FloatProperty(min=0.001, max=100, default=0.5, description="Width of the Mesh you will create") # type: ignore
    draw_remesh_placement: EnumProperty(
        items=(('surface', "Surface", "Draw the Mesh on the Surface of other Meshes", "FACESEL", 0),
               ('cursor', "Cursor", "Draw the Mesh on the Cursor Location", "CURSOR", 1),
               ),
        default='cursor') # type: ignore

    # DRAW SURFACE
    draw_surface_thickness: FloatProperty(min=0.001, max=100, default=1, description="Thickness of the Mesh you will create",precision=3) # type: ignore
    draw_surface_offset: FloatProperty(min=-1, max=1, default=1,
                                          description="Offset of the Mesh you will create", precision=3) # type: ignore
    draw_surface_update_remesh: BoolProperty(default=True, description="Update the Remesh") # type: ignore
    draw_surface_placement: EnumProperty(
        items=(('SURFACE', "Surface", "Draw the Surface on the Surface of the Mesh", "FACESEL", 0),
               ('CURSOR', "Cursor", "Draw the Surface on the Cursor Location", "CURSOR", 1)),
        default='SURFACE') # type: ignore
    
    # CUTTER
    cutter_new_mesh: BoolProperty(default=False) # type: ignore
    cutter_difference: BoolProperty(default=False, description="Remove a part of your mesh from your selection") # type: ignore
    cutter_rebool: BoolProperty(default=False, description="Slice the active object from your selection") # type: ignore
    cutter_union: BoolProperty(default=False, description="Make an union of your selection") # type: ignore
    primitive_created: BoolProperty(default=False, description="The Primitive has been created") # type: ignore
    cutter_new_mesh: BoolProperty(default=False, description="Create a new Mesh") # type: ignore
    cutter_plan: BoolProperty(default=False, description="Create or Cut from a Rectangle") # type: ignore
    cutter_vertex_line: BoolProperty(default=False, description="Create or Cut from a Form made from Edges") # type: ignore
    cutter_curve: BoolProperty(default=False, description="Create or Cut from a Curve") # type: ignore
    cutter_sphere: BoolProperty(default=False, description="Create or Cut from a Sphere") # type: ignore
    cutter_cylinder: BoolProperty(default=False, description="Create or Cut from a Cylinder") # type: ignore
    cutter_cube: BoolProperty(default=False, description="Create or Cut from a Cube") # type: ignore
    cutter_circle: BoolProperty(default=False, description="Create or Cut from a Circle") # type: ignore
    from_library: BoolProperty(default=False, description="") # type: ignore
    operation_type_union : BoolProperty(default=False, description="Make an union of your selection") # type: ignore
    operation_type_difference : BoolProperty(default=False, description="Remove a part of your mesh from your selection") # type: ignore
    operation_type_rebool : BoolProperty(default=False, description="Slice the active object from your selection") # type: ignore
    cutter_creation_width: FloatProperty(min=0.01, max=1000, default=1, description="With of the Cutter Creation") # type: ignore
    cutter_create_boolean: EnumProperty(
        items=(('create', "Create", "Create a new mesh"),
               ('boolean', "Boolean", "Add/Remove a part of your Mesh"),),
        default='boolean') # type: ignore
    cutter_view_surface: EnumProperty(
        items=(('view', "View", "Cut or create from the view or the surface of a Mesh"),
               ('surface', "Surface", "Cut or create from the the surface of a Mesh")),
        default='view') # type: ignore
    cutter_primitives: EnumProperty(
        items=(('rectangle', " ", "Cut or create with a Rectangle", "MESH_PLANE", 0),
               ('circle', " ", "Cut or create with a Circle", "MESH_CIRCLE", 1),
               ('vertex', " ", "Cut or create with a Shape", "HANDLE_VECTOR", 2),
               ('curve', " ", "Cut or create with a Curve", "MOD_CURVE", 3)),
                default='rectangle') # type: ignore
    
    # SHADING
    shading: EnumProperty(
        items=(('studio', "Studio", "Studio", "", 0),
               ('matcap', "Matcap", "Matcap", "", 1),
               ('flat', "Flat", "Flat", "", 2)),
        default='matcap',
        update = update_shading) # type: ignore
    shading_icons: EnumProperty(
        items=(('studio', "", "STUDIO MODE\n\nYou can rotate the Environment with CTRL SHIFT MMB", "LIGHT_SPOT", 0),
               ('matcap', "", "MATCAP MODE", "NODE_MATERIAL", 1),
               ('flat', "", "SILOUHETE MODE\n\nTo check the Proportions of your Mesh\n\nYou can change the Color in the Shading Settings)", "OUTLINER_OB_VOLUME", 2)),
        default='matcap',
        name="",
        update=update_shading_icons) # type: ignore
    hide_mirror_modifiers_prop: BoolProperty(default=True, update=show_hide_mirror_visibility) # type: ignore
    
    # MUSCLES
    hide_all_modifiers_prop: BoolProperty(default=True, update=hide_all_modifiers) # type: ignore
    edit_muscles_tickness: FloatProperty(min=0.001, max=1000, default=0.1,
                                         description="Thickness of the Mesh you will create",
                                         precision=3,
                                         update=muscles_tickness) # type: ignore
    edit_muscles_offset: FloatProperty(min=-1, max=1, default=0,
                                         description="Offset of the Mesh you will create",
                                         precision=3,
                                         update=muscles_offset) # type: ignore
    edit_muscles_factor: FloatProperty(min=0.001, max=1, default=0.1,
                                         description="Factor of the Mesh you will create",
                                         precision=3,
                                         update=muscles_factor) # type: ignore
    
    # GEOMESH
    collection_selection: PointerProperty(
        type=bpy.types.Collection, 
        name="Select Collection", 
        description="Select a collection from the available collections")# type: ignore
    
    def get_collection_info(self):
        act_obj = bpy.context.active_object
        if not act_obj:
            return ""
        
        modifier = act_obj.modifiers.get("GeometryNodes_Geomesh")
        if modifier:
            geo_group = modifier.node_group
            collection_info = geo_group.nodes.get("Collection Info")
            if collection_info and collection_info.inputs[0].default_value:
                return collection_info.inputs[0].default_value.name
        return ""

    def set_collection_info(self, value):
        act_obj = bpy.context.active_object
        if not act_obj:
            return
        
        modifier = act_obj.modifiers.get("GeometryNodes_Geomesh")
        if modifier:
            geo_group = modifier.node_group
            collection_info = geo_group.nodes.get("Collection Info")
            if collection_info:
                collection = bpy.data.collections.get(value)
                if collection:
                    collection_info.inputs[0].default_value = collection
                    bpy.context.view_layer.update()

    collection_info_selection: StringProperty(
        name="Select Collection",
        description="Select a collection from the available collections",
        get=get_collection_info,
        set=set_collection_info
    ) # type: ignore

    active_geomesh_name: StringProperty(default="") # type: ignore

    geomesh_name: StringProperty(name="Geomesh Name")# type: ignore

    
    
    # NEW ---------------------------------------------------
    
    def update_show_in_front(self, context):
        """Met à jour la propriété show_in_front de l'objet Geomesh actif"""
        speedsculpt = context.window_manager.speedsculpt
        
        # Vérifie si on a des items dans la collection
        if len(speedsculpt.geomesh_objects) > 0:
            # Vérifie si l'index est valide
            if 0 <= speedsculpt.geomesh_active_index < len(speedsculpt.geomesh_objects):
                # Récupère l'item actif
                active_item = speedsculpt.geomesh_objects[speedsculpt.geomesh_active_index]
                
                # Récupère l'objet Blender correspondant
                active_geomesh = bpy.data.objects.get(active_item.name)
                if active_geomesh:
                    # Met à jour show_in_front
                    active_geomesh.show_in_front = self.show_in_front
                    
                    # Force la mise à jour de l'interface
                    context.view_layer.update()
                    for area in context.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.tag_redraw()

    show_in_front: BoolProperty(
        name="Show In Front",
        description="Show the object in front of other objects",
        default=False,
        update=update_show_in_front
    ) # type: ignore

    # Collection pour stocker les geomesh objects
    geomesh_objects: CollectionProperty(
        type=SPEEDSCULPT_GeomeshItem,
        name="Geomesh Objects"
    ) # type: ignore
    
    geomesh_active_index: IntProperty(default=0) # type: ignore

################################
# KEYMAPS                      #
################################
class AddonKeymaps:
    _addon_keymaps = []
    _keymaps = {}

    @classmethod
    def new_keymap(cls, name, kmi_name, kmi_value=None, km_name='3D View',
                   space_type="VIEW_3D", region_type="WINDOW",
                   event_type=None, event_value=None, ctrl=False, shift=False,
                   alt=False, key_modifier="NONE"):

        cls._keymaps.update({name: [kmi_name, kmi_value, km_name, space_type,
                                    region_type, event_type, event_value,
                                    ctrl, shift, alt, key_modifier]
                             })

    @classmethod
    def add_hotkey(cls, kc, keymap_name):

        items = cls._keymaps.get(keymap_name)
        if not items:
            return

        kmi_name, kmi_value, km_name, space_type, region_type = items[:5]
        event_type, event_value, ctrl, shift, alt, key_modifier = items[5:]
        km = kc.keymaps.new(name=km_name, space_type=space_type,
                            region_type=region_type)

        kmi = km.keymap_items.new(kmi_name, event_type, event_value,
                                  ctrl=ctrl,
                                  shift=shift, alt=alt,
                                  key_modifier=key_modifier
                                  )
        if kmi_value:
            kmi.properties.name = kmi_value

        kmi.active = True

        cls._addon_keymaps.append((km, kmi))

    @staticmethod
    def register_keymaps():
        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        # In background mode, there's no such thing has keyconfigs.user,
        # because headless mode doesn't need key combos.
        # So, to avoid error message in background mode, we need to check if
        # keyconfigs is loaded.
        if not kc:
            return

        for keymap_name in AddonKeymaps._keymaps.keys():
            AddonKeymaps.add_hotkey(kc, keymap_name)

    @classmethod
    def unregister_keymaps(cls):
        kmi_values = [item[1] for item in cls._keymaps.values() if item]
        kmi_names = [item[0] for item in cls._keymaps.values() if
                     item not in ['wm.call_menu', 'wm.call_menu_pie']]

        for km, kmi in cls._addon_keymaps:
            # remove addon keymap for menu and pie menu
            if hasattr(kmi.properties, 'name'):
                if kmi_values:
                    if kmi.properties.name in kmi_values:
                        km.keymap_items.remove(kmi)

            # remove addon_keymap for operators
            else:
                if kmi_names:
                    if kmi.idname in kmi_names:
                        km.keymap_items.remove(kmi)

        cls._addon_keymaps.clear()

    @staticmethod
    def get_hotkey_entry_item(name, kc, km, kmi_name, kmi_value, col):

        # for menus and pie_menu
        if kmi_value:
            for km_item in km.keymap_items:
                if km_item.idname == kmi_name and km_item.properties.name == kmi_value:
                    col.context_pointer_set('keymap', km)
                    rna_keymap_ui.draw_kmi([], kc, km, km_item, col, 0)
                    return

            col.label(text=f"No hotkey entry found for {name}")
            col.operator(TEMPLATE_OT_restore_hotkey.bl_idname,
                         text="Restore keymap",
                         icon='ADD').km_name = km.name

        # for operators
        else:
            if km.keymap_items.get(kmi_name):
                col.context_pointer_set('keymap', km)
                rna_keymap_ui.draw_kmi([], kc, km, km.keymap_items[kmi_name],
                                       col, 0)

            else:
                col.label(text=f"No hotkey entry found for {name}")
                col.operator(TEMPLATE_OT_restore_hotkey.bl_idname,
                             text="Restore keymap",
                             icon='ADD').km_name = km.name

    @staticmethod
    def draw_keymap_items(wm, layout):
        kc = wm.keyconfigs.user

        for name, items in AddonKeymaps._keymaps.items():
            kmi_name, kmi_value, km_name = items[:3]
            box = layout.box()
            split = box.split()
            col = split.column()
            col.label(text=name)
            col.separator()
            km = kc.keymaps[km_name]
            AddonKeymaps.get_hotkey_entry_item(name, kc, km, kmi_name,
                                             kmi_value, col)

class TEMPLATE_OT_restore_hotkey(Operator):
    bl_idname = "template.restore_hotkey"
    bl_label = "Restore hotkeys"
    bl_options = {'REGISTER', 'INTERNAL'}

    km_name: StringProperty() # type: ignore

    def execute(self, context):
        context.preferences.active_section = 'KEYMAP'
        wm = context.window_manager
        kc = wm.keyconfigs.addon
        km = kc.keymaps.get(self.km_name)
        if km:
            km.restore_to_default()
            context.preferences.is_dirty = True
        context.preferences.active_section = 'ADDONS'
        return {'FINISHED'}

@persistent
def load_post_handler(dummy):
    """Handler appelé après le chargement d'un fichier"""
    # print("Load post handler called")
    scene = bpy.context.scene
    # if not hasattr(scene, "speedsculpt"):
    #     print("No speedsculpt in scene")
    #     return
        
    # Réinitialiser la liste
    scene.speedsculpt.geomesh_objects.clear()
    
    # Ajouter tous les objets Geomesh existants
    for obj in scene.objects:
        if obj.name.endswith("_Geomesh"):
            # print(f"Found Geomesh: {obj.name}")
            item = scene.speedsculpt.geomesh_objects.add()
            item.name = obj.name
            item.value = obj.name
    
    # print(f"Total Geomesh objects: {len(scene.speedsculpt.geomesh_objects)}")

##################################
# REGISTER
##################################
CLASSES =  [
            SPEEDSCULPT_GeomeshItem,
            SPEEDSCULPT_OT_add_categories_path,
            SPEEDSCULPT_PropertyGroup_categories,
            SPEEDSCULPT_OT_remove_categories_path,
            SPEEDSCULPT_MT_addon_prefs,
            SPEEDSCULPT_PropertyGroup,
            TEMPLATE_OT_restore_hotkey,
            SPEEDSCULPT_OT_check_updates
           ]

def register():
    armature.register()
    curves.register()
    extract_mask.register()
    lattice.register()
    operators.register()
    primitives.register()
    quick_pose.register()
    remesh_decimate.register()
    solo.register()
    symmetrize.register()
    ui.register()
    preview.register()
    modals.register()
    cutter.register()

    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")
    
    global preferences
    preferences = bpy.context.preferences.addons[__name__].preferences

    if not hasattr(bpy.types, "ASSETM_OT_ibl_manupilate"):
        AddonKeymaps.new_keymap('IBL Manipulate', 'speedsculpt.ibl_manipulate', None,
                                '3D View Generic', 'VIEW_3D', 'WINDOW', 'MIDDLEMOUSE',
                                'PRESS', True, True, False, 'NONE'
                                )

    AddonKeymaps.new_keymap('Voxel Remesh', 'object.speedsculpt_remesh_shortcut', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'R',
                            'PRESS', True, False, False, 'NONE'
                            )

    AddonKeymaps.new_keymap('Voxel Size Edition', 'object.speedsculpt_edit_voxel', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'R',
                            'PRESS', False, True, False, 'NONE'
                            )

    AddonKeymaps.new_keymap('Smooth Mesh', 'object.speedsculpt_smooth_modal', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'R',
                            'PRESS', False, False, True, 'NONE'
                            )
    
    AddonKeymaps.new_keymap('Toggle Geomesh Visibility', 'object.speedsculpt_toggle_geomesh_visibility_shortcut', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'Q',
                            'PRESS', True, True, False, 'NONE'
                            )

    AddonKeymaps.register_keymaps()

    # PROPERTYGROUP
    # bpy.types.WindowManager.speedsculpt = PointerProperty(type=SPEEDSCULPT_PropertyGroup)
    bpy.types.Scene.speedsculpt = PointerProperty(type=SPEEDSCULPT_PropertyGroup)

    bpy.app.handlers.load_post.append(load_post_handler)

    # Thumbnails
    bpy.types.WindowManager.speedsculpt_previews = EnumProperty(name="Thumbnails", items=speedsculpt_generate_previews,
                                                            description="Select a Mesh")

    # Library
    pcoll = bpy.utils.previews.new()
    pcoll.images_location = ""
    pcoll.speedsculpt_previews = ()
    speedsculpt_collection["main"] = pcoll

    # CATEGORY
    SC_update_panel(None, bpy.context)

    # CHECK FOR UPDATE
    if preferences.check_for_updates:
        check_update = False
        if bpy.app.version < (4, 2, 0):
            check_update = True

        if bpy.app.version >= (4, 2, 0) and bpy.context.preferences.system.use_online_access:
            check_update = True
            
        if check_update:
            check_for_updates_and_notify()

def unregister():
    AddonKeymaps.unregister_keymaps()
    armature.unregister()
    curves.unregister()
    extract_mask.unregister()
    lattice.unregister()
    operators.unregister()
    primitives.unregister()
    quick_pose.unregister()
    remesh_decimate.unregister()
    solo.unregister()
    symmetrize.unregister()
    ui.unregister()
    preview.unregister()
    modals.unregister()
    cutter.unregister()

    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES:
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)

    for previews in speedsculpt_collection.values():
        bpy.utils.previews.remove(previews)

    speedsculpt_collection.clear()

    bpy.app.handlers.load_post.remove(load_post_handler)


