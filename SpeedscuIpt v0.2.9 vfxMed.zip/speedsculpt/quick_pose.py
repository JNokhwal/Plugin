# -*- coding:utf-8 -*-

# ProFlow Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy

quickpose=[]

class SPEEDSCULPT_OT_update_armature(bpy.types.Operator):
    bl_idname = "object.update_armature"
    bl_label = "Update Armature"
    bl_description = "Update the Armature"
    bl_options = {"REGISTER","UNDO"}


    def execute(self, context):
        
        armature = context.active_object
        #Suis en edit, je passe en pose, je met en rest pose et je passe en object
        bpy.ops.object.mode_set(mode='POSE')
#        bpy.ops.pose.transforms_clear()
        bpy.ops.object.mode_set(mode='OBJECT')
        
        #je selectionne la hierarchie parent et enfant
        bpy.ops.object.select_more()
        
        #je selectionne le mesh supprime le parentage
        bpy.ops.object.select_grouped(extend=False, type='CHILDREN_RECURSIVE')
        # bpy.ops.object.select_hierarchy(direction='CHILD', extend=False)
        bpy.ops.object.parent_clear(type='CLEAR')
        
        mesh_object = context.active_object
        #je vire l armature et les vertex groups
        bpy.ops.object.modifier_remove(modifier="Armature")
        
        obj = context.active_object
        #Remove Vgroups
        for vgroup in obj.vertex_groups:
            if vgroup.name == 'Mask_Group':
            # if vgroup.name.startswith("B"):
                obj.vertex_groups.remove(vgroup)
        
        armature.select_set(state=True)
        context.view_layer.objects.active = armature
        
        bpy.ops.object.parent_set(type='ARMATURE_AUTO')
            
        bpy.ops.object.select_all(action='DESELECT')
        context.view_layer.objects.active=obj
        obj.select_set(state=True)
        
        
        armature_mod = context.object.modifiers.get("Armature")
        if armature_mod :
            armature_mod.vertex_group = "Mask_Group"
            armature_mod.use_deform_preserve_volume = True
            armature_mod.show_in_editmode = True
            armature_mod.show_on_cage = True

            # context.object.modifiers["Armature"].vertex_group = "Mask_Group"
            # context.object.modifiers["Armature"].use_deform_preserve_volume = True
            # context.object.modifiers["Armature"].show_in_editmode = True
            # context.object.modifiers["Armature"].show_on_cage = True


        bpy.ops.object.select_all(action='DESELECT')  


        armature.select_set(state=True)
        context.view_layer.objects.active = armature
        bpy.ops.object.posemode_toggle()
        return {"FINISHED"}
    
class SPEEDSCULPT_OT_symmetrize_bones(bpy.types.Operator):
    bl_idname = "object.symmetrize_bones"
    bl_label = "Symmetrize Bones"
    bl_description = "Symmetrize Bones"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        
        bpy.ops.object.mode_set(mode='EDIT')
        # bpy.ops.armature.select_all(action='SELECT')
        bpy.ops.armature.autoside_names(type='XAXIS')
        bpy.ops.armature.symmetrize()
        
        bpy.ops.object.update_armature()
        

        
        return {"FINISHED"}
        
class SPEEDSCULPT_OT_quick_pose_add_mask(bpy.types.Operator):
    bl_idname = "object.quick_pose_add_mask"
    bl_label = "Quick Pose Add Mask"
    bl_description = "Add Mask to make a Quick Pose"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        obj = context.active_object
        paint = context.tool_settings.image_paint
        
        del(quickpose[:])  
        
        bpy.ops.object.mode_set(mode='SCULPT')
        context.scene.tool_settings.sculpt.use_symmetry_x = False
        if bpy.app.version < (4, 3, 0):
            bpy.ops.paint.brush_select(sculpt_tool='MASK')
        else:
            bpy.ops.wm.tool_set_by_id(name="builtin_brush.mask")

        return {"FINISHED"}
          
class SPEEDSCULPT_OT_edit_quick_pose_mask(bpy.types.Operator):
    bl_idname = "object.edit_quick_pose_mask"
    bl_label = "Edit Quick Pose Mask"
    bl_description = "Edit the Quick Pose mask"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        armature_mod = context.object.modifiers.get("Armature")
        armature_mod.show_viewport = False
        bpy.ops.object.mode_set(mode='SCULPT')
        if bpy.app.version < (4, 3, 0):
            bpy.ops.paint.brush_select(sculpt_tool='MASK')
        else:
            bpy.ops.wm.tool_set_by_id(name="builtin_brush.mask")
        return {"FINISHED"}
            
class SPEEDSCULPT_OT_valid_quick_pose_mask(bpy.types.Operator):
    bl_idname = "object.valid_quick_pose_mask"
    bl_label = "Valide Quick Pose Mask"
    bl_description = "Valid the Quick Pose mask"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        
        obj_list = [obj for obj in context.selected_objects]
        obj = context.active_object
        for obj in obj_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

            
            #Remove Vgroups
            for vgroup in obj.vertex_groups:
                if vgroup.name == 'Mask_Group':
                    obj.vertex_groups.remove(vgroup)
            
            # bpy.ops.paint.hide_show(action='HIDE', area='MASKED')
            bpy.ops.paint.hide_show_masked(action='HIDE')

            bpy.ops.object.mode_set(mode='EDIT')
            
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.select_all(action='INVERT')
            bpy.ops.mesh.reveal()                           
            
            #Add Vgroup
            obj.vertex_groups.new(name="Mask_Group")
            for vgroup in obj.vertex_groups:
                if vgroup.name == 'Mask_Group':
                    bpy.ops.object.vertex_group_assign()
            
            bpy.ops.object.quick_pose_smooth_mask()

        armature_mod = context.object.modifiers.get("Armature")
        armature_mod.show_viewport = True
            
        return {"FINISHED"}   

class SPEEDSCULPT_OT_quick_pose_smooth_mask(bpy.types.Operator):
    bl_idname = "object.quick_pose_smooth_mask"
    bl_label = "Quick Pose Smooth Mask"
    bl_description = "Smooth The Mask"
    bl_options = {"REGISTER", "UNDO"}


    def execute(self, context):
        obj = context.active_object
        for vgroup in obj.vertex_groups:
            if vgroup.name.startswith("M"):
                bpy.ops.object.mode_set(mode = 'EDIT')
                bpy.ops.mesh.select_all(action='DESELECT')

                bpy.ops.object.mode_set(mode='WEIGHT_PAINT') 
                context.object.data.use_paint_mask_vertex = True
                bpy.ops.object.vertex_group_set_active(group='Mask_Group')
                bpy.ops.object.vertex_group_select()
                bpy.ops.object.vertex_group_smooth(factor=1)
                bpy.ops.object.vertex_group_smooth(repeat=500)
                context.object.data.use_paint_mask_vertex = False
                bpy.ops.object.mode_set(mode = 'OBJECT')
        return {"FINISHED"}
             
class SPEEDSCULPT_OT_quick_pose_create_bones(bpy.types.Operator):
    bl_idname = "object.quick_pose_create_bones"
    bl_label = "Create Quick Pose Bones"
    bl_description = "Quick Pose Create Bones"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        
        for obj in context.selected_objects:
            quickpose.append(obj)
        
        if speedsculpt.use_mask:
            #Create Vgroup from mask
            obj_list = [obj for obj in context.selected_objects]
            obj = context.active_object
            for obj in obj_list:
                obj.select_set(state=True)
                context.view_layer.objects.active = obj

                
                #Remove Vgroups
                for vgroup in obj.vertex_groups:
                    if vgroup.name == 'Mask_Group':
                        obj.vertex_groups.remove(vgroup)
                
                # bpy.ops.paint.hide_show(action='HIDE', area='MASKED')
                bpy.ops.paint.hide_show_masked(action='HIDE')

                bpy.ops.object.mode_set(mode='EDIT')
                
                bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.select_all(action='INVERT')
                bpy.ops.mesh.reveal()  
                
                #Add Vgroup
                obj.vertex_groups.new(name="Mask_Group")
                for vgroup in obj.vertex_groups:
                    if vgroup.name == 'Mask_Group':
                        bpy.ops.object.vertex_group_assign()
                
                
                #Smooth Vertex Group
                bpy.ops.object.mode_set(mode='WEIGHT_PAINT') 
                context.object.data.use_paint_mask_vertex = True
                bpy.ops.object.vertex_group_smooth(group_select_mode='ALL', factor=1, repeat=500, expand=0)

                # bpy.ops.object.vertex_group_smooth(factor=1, source='ALL')
                # bpy.ops.object.vertex_group_smooth(repeat=500)
                context.object.data.use_paint_mask_vertex = False
                bpy.ops.object.mode_set(mode = 'OBJECT')        
        
        
        #Add snap Volume
        context.scene.tool_settings.use_snap = True
        if bpy.app.version < (4, 2, 0):
            context.scene.tool_settings.snap_elements = {'VOLUME'}
        else:
            context.scene.tool_settings.snap_elements_base = {'VOLUME'}
        context.scene.tool_settings.snap_target = 'MEDIAN'
            
        #Add Vertex
        if speedsculpt.create_primitives == 'cursor':
        # if not WM.origin:
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.mesh.primitive_plane_add()
        context.active_object.name = "BS_Vertex"
        
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.merge(type='CENTER')

        # bpy.ops.view3d.toggle_xray()
        shading = context.space_data.shading
        shading.show_xray = True
        # if context.screen.shading.show_xray == True:
        #     context.screen.shading.show_xray = False
        # else:
        #     pass

        # if context.space_data.use_occlude_geometry == True :
        #     context.space_data.use_occlude_geometry = False
        # else :
        #     pass
        
        
        # if not WM.origin:
        if speedsculpt.create_primitives == 'cursor':
            bpy.ops.transform.translate('INVOKE_DEFAULT')
        else:
            bpy.ops.transform.translate('INVOKE_DEFAULT')
#            bpy.ops.transform.translate('INVOKE_DEFAULT', contraint_axis(False, False, True))        
#        bpy.ops.transform.translate('INVOKE_DEFAULT')
        context.scene.cursor.location[0] = 0
        context.scene.cursor.location[1] = 0
        context.scene.cursor.location[2] = 0
        
        return {"FINISHED"}
 
class SPEEDSCULPT_OT_quick_pose_convert_bones(bpy.types.Operator):
    bl_idname = "object.quick_pose_convert_bones"
    bl_label = "Quick PoseConvert Bones"
    bl_description = "Convert vertex to bones"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        act_obj = context.active_object
           
        bpy.ops.object.mode_set(mode='OBJECT')
        mod_skin = act_obj.modifiers.new("Skin", 'SKIN')
        bpy.ops.object.skin_armature_create(modifier=mod_skin.name)

        context.active_object.name = "Armature_Quick_Pose"
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)


        bpy.ops.object.select_all(action='DESELECT')

        act_obj.select_set(state=True)
        bpy.ops.object.delete()
        bpy.data.objects["Armature_Quick_Pose"].select_set(state=True)
        Armature = context.active_object
            
        for obj in quickpose :
            obj.select_set(state=True)
            bpy.ops.object.parent_set(type='ARMATURE_AUTO')
            
            bpy.ops.object.select_all(action='DESELECT')
            context.view_layer.objects.active=obj
            obj.select_set(state=True)
            
            
            armature = context.object.modifiers.get("Armature")
            if armature :
                armature.vertex_group = "Mask_Group"
                armature.use_deform_preserve_volume = True
                armature.show_in_editmode = True
                armature.show_on_cage = True


        bpy.ops.object.select_all(action='DESELECT')  
        

        Armature.select_set(state=True)
        context.view_layer.objects.active = Armature
        bpy.ops.object.posemode_toggle()
        
        bpy.context.scene.tool_settings.use_snap = False

        return {"FINISHED"}

class SPEEDSCULPT_OT_remove_quick_pose(bpy.types.Operator):
    bl_idname = "object.remove_quick_pose_modifier"
    bl_label = "Remove Quick Pose Modifier"
    bl_description = "Remove Quick Pose Modifier"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        act_obj = context.active_object

        #Delete Armature
        for mod in act_obj.modifiers:
            if mod.type == 'ARMATURE':
                # self.bones = mod.object
                bpy.ops.object.modifier_remove(modifier=mod.name)

        #Remove Vgroups    
        bpy.ops.object.vertex_group_remove(all=True)

        del(quickpose[:])  
          
        return {"FINISHED"}  

class SPEEDSCULPT_OT_apply_quick_pose(bpy.types.Operator):
    bl_idname = "object.apply_quick_pose_modifier"
    bl_label = "Apply Quick Pose Modifier"
    bl_description = "Apply Quick Pose Modifier"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        act_obj = context.active_object
        
        #Apply Armature  
        armature = context.object.modifiers.get("Armature")
        if armature:
            if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier="Armature")
            else:
                bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Armature")
        
        #Remove Mask
        bpy.ops.object.mode_set(mode='SCULPT') 
        bpy.ops.paint.mask_flood_fill(mode='VALUE', value=0)
        bpy.ops.object.mode_set(mode='OBJECT') 
 
        #Remove Vgroups    
        bpy.ops.object.vertex_group_remove(all=True)
         
        bpy.ops.object.select_all(action='DESELECT') 
        
        bpy.data.objects['Armature_Quick_Pose'].select_set(state=True)
        bpy.ops.object.mode_set(mode='OBJECT')  
        bpy.ops.object.delete(use_global=False)

        act_obj.select_set(state=True)
        context.view_layer.objects.active = act_obj


        del(quickpose[:])           

        return {"FINISHED"}

CLASSES =  [SPEEDSCULPT_OT_apply_quick_pose,
            SPEEDSCULPT_OT_remove_quick_pose,
            SPEEDSCULPT_OT_quick_pose_convert_bones,
            SPEEDSCULPT_OT_quick_pose_create_bones,
            SPEEDSCULPT_OT_quick_pose_smooth_mask,
            SPEEDSCULPT_OT_valid_quick_pose_mask,
            SPEEDSCULPT_OT_edit_quick_pose_mask,
            SPEEDSCULPT_OT_quick_pose_add_mask,
            SPEEDSCULPT_OT_symmetrize_bones,
            SPEEDSCULPT_OT_update_armature
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)

            
        