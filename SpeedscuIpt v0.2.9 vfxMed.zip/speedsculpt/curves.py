'''-*- coding:utf-8 -*-

ProFlow Add-on
Copyright (C) 2020 Cedric Lepiller aka Pitiwazou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

<pep8 compliant>'''

import bpy


from .operators import (CheckDyntopo,
                        save_tmp,
                        CheckSmoothMesh,
                        clean_and_convert,
                        separate_objects
)
from .functions import get_addon_preferences
from bpy.types import Operator
     
class SPEEDSCULPT_OT_create_lathe(Operator):
    bl_idname = "object.create_lathe"
    bl_label = "CREATE LATHE"
    bl_description = "CREATE LATHE\n\nDraw a Lathe in the 3Dview.\n\nIt uses the Cursor or the Selection as Center.\n\nYou can Edit the settings and then Remesh it."
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()


        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
        elif speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_cursor_to_selected()

        if context.object is None and not speedsculpt.ref_obj :
            speedsculpt.add_mirror = False

        self.has_selection = False
        if context.object is not None and context.selected_objects and len(context.selected_objects) == 1:
            self.has_selection = True
            self.actObj = context.active_object
            if self.actObj :
                bpy.ops.object.mode_set(mode='OBJECT')

        #Create Curve
        bpy.ops.curve.primitive_bezier_curve_add(align='WORLD')
        new_obj = context.active_object
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.curve.delete(type='VERT')

        #Create Modifier
        mod_screw = new_obj.modifiers.new("Screw", 'SCREW')
        mod_screw.use_normal_flip = False
        mod_screw.steps = 48

        if self.has_selection and len(context.selected_objects) == 1 and not speedsculpt.create_primitives == 'selection':
            if not speedsculpt.add_mirror:
                mod_screw.object = self.actObj

        if speedsculpt.create_primitives == 'origin':
            context.scene.cursor.location[:] = (0, 0, 0)
            context.scene.cursor.rotation_euler[:] = (0, 0, 0)
            new_obj.location[:] = (0, 0, 0)

        elif speedsculpt.create_primitives == 'cursor':
            if speedsculpt.copy_cursor_orientation:
                new_obj.rotation_euler = context.scene.cursor.rotation_euler.copy()

        elif speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        if speedsculpt.add_mirror :
            if context.object is None :
                self.report({'INFO'},"Select Mirror Object First", icon='ERROR')
            else :
                mod_mirror = new_obj.modifiers.new("Mirror", 'MIRROR')
                mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
                for prop, axis_index in mirror_axes.items():
                    if getattr(speedsculpt, prop):
                        mod_mirror.use_axis[axis_index] = True
                if speedsculpt.ref_obj:
                    mod_mirror.mirror_object = speedsculpt.ref_obj
                elif self.has_selection :
                    mod_mirror.mirror_object = self.actObj

        #Parenting
        if self.has_selection:
            if speedsculpt.primitives_parenting  :
                bpy.ops.object.mode_set(mode='OBJECT')
                if not context.active_object.parent:
                    self.actObj.select_set(state=True)
                    context.view_layer.objects.active = self.actObj
                    bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                    self.actObj.select_set(state=False)
                    new_obj.select_set(state=True)
                    context.view_layer.objects.active = new_obj

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.transform.translate('INVOKE_DEFAULT')

        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.curve.draw('INVOKE_DEFAULT')
        bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')

        # Set Handles
        bpy.ops.curve.spline_type_set(type='BEZIER')
        bpy.ops.curve.handle_type_set(type='AUTOMATIC')
        bpy.context.space_data.overlay.display_handle = 'ALL'
        bpy.context.space_data.overlay.show_curve_normals = False


        
        return {"FINISHED"}

class SPEEDSCULPT_OT_create_empty(Operator):
    bl_idname = "object.speedsculpt_create_empty"
    bl_label = "Create Empty"
    bl_description = ""
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        curve_obj = context.active_object if context.object is not None else None

        if context.object is not None :
            bpy.ops.object.mode_set(mode = 'OBJECT')
        
        bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')   
        
        #create Empty 
        bpy.ops.object.empty_add(type='PLAIN_AXES')
        empty_obj = context.active_object
        # bpy.context.object.show_x_ray = True
        bpy.ops.transform.resize(value=(2, 2, 2))

        bpy.ops.object.select_all(action='DESELECT')

        #Select Curve and add empty as ref object
        curve_obj.select_set(state=True)
        context.view_layer.objects.active = curve_obj

        screw_mod = context.object.modifiers.get("Screw")
        screw_mod.object = empty_obj

        # bpy.context.object.modifiers["Screw"].object = empty_obj
        bpy.ops.object.select_all(action='DESELECT')
        
        #Select Empty
        empty_obj.select_set(state=True)
        context.view_layer.objects.active = empty_obj
        bpy.ops.transform.translate('INVOKE_DEFAULT')

        bpy.context.scene.cursor.location[0] = 0
        bpy.context.scene.cursor.location[1] = 0
        bpy.context.scene.cursor.location[2] = 0


        return {"FINISHED"}        

class SPEEDSCULPT_OT_bbox(Operator):
    bl_idname = "object.bbox"
    bl_label = "Bbox"
    bl_description = "Create surface from curve"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()


        if bpy.context.object.mode == "OBJECT":
            bpy.ops.object.mode_set(mode = 'EDIT')
            bpy.ops.curve.cyclic_toggle()
            context.object.data.dimensions = '2D'
            context.object.data.resolution_u = 12
            context.object.data.fill_mode = 'BOTH'
            context.object.data.bevel_depth = speedsculpt.bbox_bevel
            context.object.data.offset = speedsculpt.bbox_offset
            context.object.data.bevel_resolution = 5
            context.object.data.extrude = speedsculpt.bbox_depth
            
        elif bpy.context.object.mode == "EDIT":
            bpy.ops.curve.cyclic_toggle()
            context.object.data.dimensions = '2D'
            context.object.data.resolution_u = 12
            context.object.data.fill_mode = 'BOTH'
            context.object.data.bevel_depth = speedsculpt.bbox_bevel
            context.object.data.offset = speedsculpt.bbox_offset
            context.object.data.bevel_resolution = 5
            context.object.data.extrude = speedsculpt.bbox_depth
         
        #Convert poly
        if not speedsculpt.bbox_convert :
            bpy.ops.object.mode_set(mode = 'OBJECT') 
            bpy.ops.object.convert(target='MESH')
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
            bpy.ops.object.mode_set(mode='EDIT')  
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.remove_doubles()
            bpy.ops.object.mode_set(mode = 'OBJECT')

            if prefs.dyntopo_or_remesh == "dyntopo":
                CheckDyntopo()
            else:
                bpy.ops.object.speedsculpt_remesh_selection()

            CheckSmoothMesh()
            
            if speedsculpt.smooth_result:
                bpy.ops.object.mode_set(mode = 'EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.vertices_smooth(repeat=100)
                bpy.ops.object.mode_set(mode = 'OBJECT')

        new_obj = context.active_object

        if speedsculpt.add_mirror :
            if context.object is None :
                self.report({'INFO'},"Select Mirror Object First", icon='ERROR')
            else :
                mod_mirror = new_obj.modifiers.new("Mirror", 'MIRROR')
                mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
                for prop, axis_index in mirror_axes.items():
                    if getattr(speedsculpt, prop):
                        mod_mirror.use_axis[axis_index] = True
                if speedsculpt.ref_obj:
                    mod_mirror.mirror_object = speedsculpt.ref_obj
                # elif len([obj for obj in context.selected_objects]) == 1:
                #     mod_mirror.mirror_object = actObj

        # Parenting
        # if speedsculpt.primitives_parenting:
        #     if not context.active_object.parent:
        #         actObj.select_set(state=True)
        #         context.view_layer.objects.active = actObj
        #         bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
        #         actObj.select_set(state=False)
        #         new_obj.select_set(state=True)
        #         context.view_layer.objects.active = new_obj

        # bpy.context.object.show_x_ray = False
        return {"FINISHED"}       

class SPEEDSCULPT_OT_create_curve(Operator):
    bl_idname = "object.speedsculpt_create_curve"
    bl_label = "CREATE CURVE"
    bl_description = "CREATE CURVE\n\nDraw a curve in the 3Dview.\n\nYou can edit the settings, Keep and edit the Curve or make a new object from it"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()
        actObj = context.active_object if context.object is not None else None

        if context.object is None or not context.object.visible_get(view_layer=context.view_layer) :
            speedsculpt.primitives_parenting = False
            speedsculpt.add_mirror = False
        else:
            bpy.ops.object.mode_set(mode = 'OBJECT')
            bpy.ops.object.select_all(action='DESELECT')

        bpy.ops.curve.primitive_bezier_curve_add(radius=1, enter_editmode=True, align='VIEW')
        context.scene.tool_settings.curve_paint_settings.curve_type = 'BEZIER'
        context.scene.tool_settings.curve_paint_settings.depth_mode = 'CURSOR'

        bpy.ops.curve.delete(type='VERT')
        context.active_object.name= "BS_Curve"
        new_obj = context.active_object

        # if speedsculpt.add_mirror :
        #     if context.object is None :
        #         self.report({'INFO'},"Select Mirror Object First", icon='ERROR')
        #     else :
        #         mod_mirror = new_obj.modifiers.new("Mirror", 'MIRROR')
        #         mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
        #         for prop, axis_index in mirror_axes.items():
        #             if getattr(speedsculpt, prop):
        #                 mod_mirror.use_axis[axis_index] = True
        #         if speedsculpt.ref_obj:
        #             mod_mirror.mirror_object = speedsculpt.ref_obj
        #         elif len([obj for obj in context.selected_objects]) == 1:
        #             mod_mirror.mirror_object = actObj

        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                actObj.select_set(state=True)
                context.view_layer.objects.active = actObj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                actObj.select_set(state=False)
                new_obj.select_set(state=True)
                context.view_layer.objects.active = new_obj

        bpy.ops.curve.draw('INVOKE_DEFAULT', error_threshold=0.05, fit_method='SPLIT', corner_angle=60,
                           use_cyclic=False,
                           stroke=[],
                           wait_for_input=True)

        
        return {"FINISHED"} 

class SPEEDSCULPT_OT_Convert_Curve_To_Skin(Operator):
    bl_idname = "object.convert_curve_to_skin"
    bl_label = "Convert Curve To Skin"
    bl_description = "Convert Curve To Skin"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        actObj = context.active_object
        
        if "Mirror" in actObj.modifiers:
            bpy.ops.object.modifier_remove(modifier="Mirror")

        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.curve.spline_type_set(type='POLY')
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.convert(target='MESH')
        
        #Add Subdiv base
        newSubdiv = actObj.modifiers.new("Smooth_skin","SUBSURF")
        newSubdiv.levels = 2
        
        #Add Skin modifier
        newSkin = actObj.modifiers.new("Skin","SKIN")
        newSkin.use_smooth_shade = True
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.object.skin_root_mark()
        bpy.ops.object.mode_set(mode = 'OBJECT')
        
        # Add Subdiv
        newMod = actObj.modifiers.new("Subsurf","SUBSURF")
        newMod.levels = 3

        #Enter in edit mode
        bpy.ops.object.mode_set(mode = 'EDIT')

        if speedsculpt.add_mirror :
            newMirror = actObj.modifiers.new("Mirror","MIRROR")
            newMirror.use_axis[0] = True
            newMirror.use_mirror_merge = False

            if speedsculpt.ref_obj :
                newMirror.mirror_object = speedsculpt.ref_obj


            bpy.ops.object.modifier_move_up(modifier="Mirror")
            bpy.ops.object.modifier_move_up(modifier="Mirror")
            bpy.ops.object.modifier_move_up(modifier="Mirror")
            bpy.ops.object.modifier_move_up(modifier="Mirror")
            bpy.ops.object.modifier_move_up(modifier="Mirror") 
            bpy.ops.object.modifier_move_up(modifier="Mirror") 
            bpy.ops.object.modifier_move_up(modifier="Mirror")  
        return {"FINISHED"}

class SPEEDSCULPT_OT_cut_boolean(Operator):
    bl_idname = "object.cut_boolean"
    bl_label = "Cut Boolean"
    bl_description = "Cut Object with curve"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return len([obj for obj in context.selected_objects if obj.type == 'MESH']) and len([obj for obj in context.selected_objects if obj.type == 'CURVE' and obj != context.active_object])
    
    def convert_curve(self, obj, context):
        speedsculpt = context.scene.speedsculpt

        prefs = get_addon_preferences()

        context.view_layer.objects.active = obj
        
        #save Temp
        if prefs.auto_save:
            save_tmp()
        
        obj.select_set(state=True)
        
        if not speedsculpt.direct_cut :
            bpy.ops.object.mode_set(mode='EDIT') 
            bpy.ops.curve.cyclic_toggle()
            bpy.ops.object.mode_set(mode='OBJECT') 
            bpy.ops.object.convert(target='MESH')
            bpy.ops.object.mode_set(mode='EDIT')  
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.edge_face_add()
            
            bpy.ops.object.mode_set(mode='OBJECT')
            mod_solidify = context.object.modifiers.new("Solidify", 'SOLIDIFY')
            mod_solidify.use_even_offset = True
            mod_solidify.offset = 0
            mod_solidify.thickness = 10

            # bpy.ops.object.modifier_add(type='SOLIDIFY')
            # context.object.modifiers["Solidify"].use_even_offset = True
            # context.object.modifiers["Solidify"].offset = 0
            # context.object.modifiers["Solidify"].thickness = 10
            if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier=mod_solidify)
                # bpy.ops.object.modifier_apply(modifier="Solidify")
            else:
                bpy.ops.object.modifier_apply(apply_as='DATA', modifier=mod_solidify)
                # bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Solidify")
        else:
            context.object.data.extrude = 100
            bpy.ops.object.convert(target='MESH')

        obj.select_set(state=True)
        
    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        
        act_obj = context.active_object
        # on recupere seulement l'objet curve
        curve = [obj for obj in context.selected_objects if obj.type == 'CURVE']
        # on recupere tout les autres objets selectionnees
        obj_list = [obj for obj in context.selected_objects if obj.type == "MESH"]
        
        bpy.ops.object.select_all(action='DESELECT')
        
        # on convertit la curve en mesh grace a la fonction cree dans la class, d'ou le besoin de mettre self devant
        self.convert_curve(curve[0], context)

        for obj in obj_list:
            # mise en place du boolean DIFFERENCE sur l'obj  faisant partie de la selection
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

            mod_boolean = obj.modifiers.new("Boolean", 'BOOLEAN')
            mod_boolean.object = curve[0]
            mod_boolean.operation = 'DIFFERENCE'

            if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier=mod_boolean)
            else:
                bpy.ops.object.modifier_apply(apply_as = 'DATA', modifier=mod_boolean)
            obj.select_set(state=False)

        # suppression de l obj curve
        for coll in curve[0].users_collection:
            coll.objects.unlink(curve[0])
        bpy.data.objects.remove(curve[0])

        # selection des objs de la selection
        for obj in obj_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

            prefs = get_addon_preferences()
            add_remesh = prefs.add_remesh
            if add_remesh:
                bpy.ops.object.simple_remesh()
                clean_and_convert(obj)
                separate_objects()

            # if update_detail_flood_fill:
            if prefs.dyntopo_or_remesh == "dyntopo":
                #Update Dyntopo
                CheckDyntopo()
            elif prefs.dyntopo_or_remesh == "remesh":
                bpy.ops.object.speedsculpt_remesh_selection()
            # if smooth_mesh:
            CheckSmoothMesh()

            if speedsculpt.direct_cut :
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.normals_make_consistent(inside=False)
                bpy.ops.object.mode_set(mode='OBJECT')


        context.view_layer.objects.active = act_obj



        return {"FINISHED"}

class SPEEDSCULPT_OT_cut_boolean_rebool(Operator):
    bl_idname = "object.cut_boolean_rebool"
    bl_label = "Cut Boolean Rebool"
    bl_description = "Slice object with curve"
    bl_options = {"REGISTER", "UNDO"}
 
    @classmethod
    def poll(cls, context):
        return len([obj for obj in context.selected_objects if obj.type == 'MESH']) and len([obj for obj in context.selected_objects if obj.type == 'CURVE' and obj != context.active_object])
        
    
    def convert_curve(self, obj, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()
        context.view_layer.objects.active = obj
        
        #save Temp
        if prefs.auto_save:
            save_tmp()
        
        obj.select_set(state=True)
        
        if not speedsculpt.direct_cut :
            bpy.ops.object.mode_set(mode='EDIT') 
            bpy.ops.curve.cyclic_toggle()
            bpy.ops.object.mode_set(mode='OBJECT') 
            bpy.ops.object.convert(target='MESH')
            bpy.ops.object.mode_set(mode='EDIT')  
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.edge_face_add()
            
            bpy.ops.object.mode_set(mode='OBJECT')
            mod_solidify = context.object.modifiers.new("Solidify", 'SOLIDIFY')
            mod_solidify.use_even_offset = True
            mod_solidify.offset = 0
            mod_solidify.thickness = 10

            if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier=mod_solidify)
            else:
                bpy.ops.object.modifier_apply(apply_as='DATA', modifier=mod_solidify)
        else:
            bpy.context.object.data.extrude = 30
            bpy.ops.object.convert(target='MESH')

        self.cut_obj = context.active_object
        obj.select_set(state=True)
        
    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        RB_list = []  #a utiliser si tu veux faire une action sur les objs rebool
        act_obj = context.active_object
        # on recupere seulement l'objet curve
        curve = [obj for obj in context.selected_objects if obj.type == 'CURVE']
        # on recupere tout les autres objets selectionnees
        obj_list = [obj for obj in context.selected_objects if obj.type == "MESH"]
        
        bpy.ops.object.select_all(action='DESELECT')
        
        # on convertit la curve en mesh grace a la fonction cree dans la class, d'ou le besoin de mettre self devant
        self.convert_curve(curve[0], context)

        bpy.ops.object.select_all(action='DESELECT')

        for obj in obj_list:
            # mise en place du boolean DIFFERENCE sur l'obj  faisant partie de la selection
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

            mod_boolean = obj.modifiers.new("Boolean", 'BOOLEAN')
            mod_boolean.object = curve[0]
            mod_boolean.operation = 'DIFFERENCE'

            # creation de l'obj rebool
            bpy.ops.object.duplicate_move()
            RB_obj = context.active_object
            RB_list.append(RB_obj) #a utiliser si tu veux faire une action sur les objs rebool
            
            # changement d'operation en INTERSECT + application du boolean INTERSECT
            RB_obj.modifiers["Boolean"].operation = 'INTERSECT'
            bpy.ops.object.convert(target='MESH')
            # bpy.ops.object.modifier_apply(apply_as = 'DATA', modifier = 'Boolean')
            RB_obj.select_set(state=False)
            
            # on repasse sur l'obj faisant parti de la selection et on applique le boolean DIFFERENCE
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            bpy.ops.object.convert(target='MESH')
            # bpy.ops.object.modifier_apply(apply_as = 'DATA', modifier = 'Boolean')
            obj.select_set(state=False)

        # suppression de l obj curve
        for coll in curve[0].users_collection:
            coll.objects.unlink(curve[0])
        bpy.data.objects.remove(curve[0])



        for obj in obj_list + RB_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

        prefs = get_addon_preferences()
        add_remesh = prefs.add_remesh
        if add_remesh:
            bpy.ops.object.simple_remesh()
            clean_and_convert(obj)
            separate_objects()
            # bpy.ops.object.apply_separate()

        for obj in obj_list + RB_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

            if prefs.dyntopo_or_remesh == "dyntopo":
                CheckDyntopo()
            elif prefs.dyntopo_or_remesh == "remesh":
                bpy.ops.object.speedsculpt_remesh_selection()

            CheckSmoothMesh()

            if speedsculpt.direct_cut :
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.normals_make_consistent(inside=False)
                bpy.ops.object.mode_set(mode='OBJECT')

            obj.select_set(state=True)
            context.view_layer.objects.active = obj

        # selection des objs de la selection
        for obj in obj_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj



        return {"FINISHED"}

CLASSES =  [SPEEDSCULPT_OT_cut_boolean_rebool,
            SPEEDSCULPT_OT_cut_boolean,
            SPEEDSCULPT_OT_Convert_Curve_To_Skin,
            SPEEDSCULPT_OT_create_curve,
            SPEEDSCULPT_OT_bbox,
            SPEEDSCULPT_OT_create_empty,
            SPEEDSCULPT_OT_create_lathe,
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)