# -*- coding:utf-8 -*-

# ProFlow Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
from bpy.props import (StringProperty, 
                       BoolProperty, 
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty)

from .operators import (CheckDyntopo,
                        CheckSmoothMesh)
# from . import get_addon_preferences
from .functions import get_addon_preferences

class SPEEDSCULPT_OT_add_custom_primitives(bpy.types.Operator):
    bl_idname = "object.add_custom_primitives"
    bl_label = "Add Custom Primitives"
    bl_description = "\nAdd primitives to your Scene"
    bl_options = {"REGISTER", "UNDO"}

    primitive: EnumProperty(
        items=(('sphere', "Sphere", "Add a Sphere", "MESH_UVSPHERE", 0),
               ('cylinder', "Cylinder", "Add a Cylinder", "MESH_CYLINDER", 1),
               ('cube', "Cube", "Add a Cube", "MESH_CUBE", 2),
               ('cone', "Cone", "Add a Cone", "MESH_CONE", 3),
               ('torus', "Torus", "Add a Torus", "MESH_TORUS", 4)),
        default='sphere') # type: ignore

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()
        cursor_location = context.scene.cursor.location.copy()
        cursor_rotation = context.scene.cursor.rotation_euler.copy()

        if context.object is None or not context.object.visible_get(view_layer=context.view_layer) :
            speedsculpt.primitives_parenting = False
            speedsculpt.add_mirror = False
        else:
            act_obj = context.active_object
            bpy.ops.object.mode_set(mode = 'OBJECT')

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
        elif speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_cursor_to_selected()
        
        if context.object is None and not speedsculpt.ref_obj :
            speedsculpt.add_mirror = False
               
        if self.primitive == 'sphere':
            bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=5, radius=1, enter_editmode=False)

        elif self.primitive == 'cylinder':
            bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=1, depth=2, end_fill_type='TRIFAN',
                                                align='WORLD', enter_editmode=True)
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.edges_select_sharp(sharpness=0.523599)
            bpy.ops.transform.edge_crease(value=1) 
            bpy.ops.object.mode_set(mode = 'OBJECT')  
        elif self.primitive == 'cube':
            bpy.ops.mesh.primitive_cube_add(align='WORLD', enter_editmode=False)
        elif self.primitive == 'cone':
            bpy.ops.mesh.primitive_cone_add(vertices=128, radius1=1, radius2=0, depth=2, end_fill_type='TRIFAN', enter_editmode=False)
        else:
            bpy.ops.mesh.primitive_torus_add(align='WORLD',
                                             major_segments=120, minor_segments=64, mode='MAJOR_MINOR',
                                             major_radius=1, minor_radius=0.25, abso_major_rad=1.25,
                                             abso_minor_rad=0.75)

        new_obj = context.active_object
        if speedsculpt.create_primitives == 'cursor':
            if speedsculpt.copy_cursor_orientation:
                new_obj.rotation_euler = context.scene.cursor.rotation_euler.copy()

        elif speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        elif speedsculpt.create_primitives == 'origin':
            context.scene.cursor.location[:] = (0,0,0)
            context.scene.cursor.rotation_euler[:] = (0,0,0)
            new_obj.location[:] = (0,0,0)

        if prefs.dyntopo_or_remesh == "remesh":
            if prefs.update_remesh:
                bpy.ops.object.speedsculpt_remesh_selection()

        elif prefs.dyntopo_or_remesh == "dyntopo":
            CheckDyntopo()
            CheckSmoothMesh()

        # Add Mirror
        if speedsculpt.add_mirror:
            bpy.ops.object.speedsculpt_add_mirror()

        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                act_obj.select_set(state=True)
                context.view_layer.objects.active = act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                act_obj.select_set(state=False)
                new_obj.select_set(state=True)
                context.view_layer.objects.active = new_obj

        bpy.ops.object.mode_set(mode='SCULPT')
        bpy.context.scene.tool_settings.sculpt.detail_type_method = 'CONSTANT'
        bpy.ops.object.mode_set(mode='OBJECT')

        if bpy.app.version < (4, 1, 0):
            context.object.data.use_auto_smooth = False

        if prefs.remesh_mesh_smooth_normals:
            bpy.ops.object.shade_smooth()
        else:
            bpy.ops.object.shade_flat()

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.transform.translate('INVOKE_DEFAULT')

        context.scene.cursor.location[:] = cursor_location
        context.scene.cursor.rotation_euler[:] = cursor_rotation
        
        return {"FINISHED"}
    
class SPEEDSCULPT_OT_add_metaballs(bpy.types.Operator):

    bl_idname = "object.add_custom_metaballs"
    bl_label = "Custom Add Metaballs"
    bl_description = "Create Metaballs"
    bl_options = {"REGISTER", "UNDO"}
    
    metaballs : EnumProperty(
        items = (('ball', "Ball", ""),
                 ('capsule', "Capsule", ""),
                 ('plane', "Plane", ""),
                 ('hellipsoid', "Hellipsoid", ""),
                 ('cube', "Cube", "")),
                 default = 'ball'
                 ) # type: ignore

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()
        cursor_location = context.scene.cursor.location.copy()
        cursor_rotation = context.scene.cursor.rotation_euler.copy()
        
        if context.object is None or not context.object.visible_get(view_layer=context.view_layer) :
            speedsculpt.primitives_parenting = False
            speedsculpt.add_mirror = False
        else:
            act_obj = context.active_object
            bpy.ops.object.mode_set(mode = 'OBJECT')

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')

        elif speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_cursor_to_selected()
       
        if self.metaballs == 'ball':
            bpy.ops.object.metaball_add(type='BALL', radius=0.5)
        elif self.metaballs == 'capsule':
            bpy.ops.object.metaball_add(type='CAPSULE', radius=0.5)
        elif self.metaballs == 'hellipsoid':
            bpy.ops.object.metaball_add(type='ELLIPSOID', radius=0.5)
        elif self.metaballs == 'cube':
            bpy.ops.object.metaball_add(type='CUBE', radius=0.5)
        else:
            bpy.ops.object.metaball_add(type='PLANE', radius=0.5)

        new_obj = context.active_object
        
        context.object.data.elements[0].use_negative = True
        speedsculpt.metaballs_pos_neg = "positive"
        context.object.data.resolution = 0.02
        context.object.data.threshold = 0.01
        context.object.data.update_method = 'HALFRES'

        if speedsculpt.create_primitives == 'cursor':
            if speedsculpt.copy_cursor_orientation:
                new_obj.rotation_euler = context.scene.cursor.rotation_euler.copy()

        elif speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        elif speedsculpt.create_primitives == 'origin':
            context.scene.cursor.location[:] = (0,0,0)
            context.scene.cursor.rotation_euler[:] = (0,0,0)
            new_obj.location[:] = (0,0,0)


        # Mirror
        if speedsculpt.add_mirror:

            context.scene.cursor.location[:] = (0, 0, 0)
            context.scene.cursor.rotation_euler[:] = (0, 0, 0)
            new_obj.location[:] = (0, 0, 0)

            bpy.ops.object.duplicate_move_linked()

            if speedsculpt.mirror_x:
                bpy.ops.transform.resize(value=(-1, 1, 1))

            elif speedsculpt.mirror_y:
                bpy.ops.transform.resize(value=(1, -1, 1))

            elif speedsculpt.mirror_z:
                bpy.ops.transform.resize(value=(1, 1, -1))

            if speedsculpt.mirror_x and speedsculpt.mirror_y:
                bpy.ops.transform.resize(value=(-1, -1, 1))

            if speedsculpt.mirror_x and speedsculpt.mirror_z:
                bpy.ops.transform.resize(value=(-1, 1, -1))

            if speedsculpt.mirror_y and speedsculpt.mirror_z:
                bpy.ops.transform.resize(value=(1, -1, -1))

            bpy.ops.object.select_all(action='DESELECT')

            new_obj.select_set(state=True)
            bpy.context.view_layer.objects.active = new_obj

            bpy.ops.object.mode_set(mode='EDIT')

            if speedsculpt.create_primitives == 'mouse':
                bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
                bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                act_obj.select_set(state=True)
                context.view_layer.objects.active = act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                act_obj.select_set(state=False)
                new_obj.select_set(state=True)
                context.view_layer.objects.active = new_obj

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.transform.translate('INVOKE_DEFAULT')
        
        context.scene.cursor.location[:] = cursor_location
        context.scene.cursor.rotation_euler[:] = cursor_rotation
        return {"FINISHED"}

def UpdateMetaballs(self, context):  
    if context.object.data.elements[0].use_negative :
        context.object.data.elements[0].use_negative = False
    else:
        context.object.data.elements[0].use_negative = True

class SPEEDSCULPT_OT_clean_metaballs(bpy.types.Operator):
    bl_idname = "object.clean_metaballs"
    bl_label = "Clean Metaballs"
    bl_description = "Remove all the metaballs from the scene"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        actObj = context.active_object
        bpy.ops.object.select_all(action='DESELECT')
        for x in bpy.data.objects :
            if x.type == 'META':
                x.select_set(state=True)
                context.view_layer.objects.active = x
                bpy.ops.object.delete()

                actObj.select_set(state=True)
                context.view_layer.objects.active = actObj
        return {"FINISHED"}             

class SPEEDSCULPT_OT_add_skin(bpy.types.Operator):
    bl_idname = "object.add_skin"
    bl_label = "ADD SKIN"
    bl_description = "ADD SKIN\n\nCreate Skin Object, a single Vertex with a Skin Modifier.\n\nYou can go in Edit Mode to Edit it.\n\nCTRL A to Scale the Vertex"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        if context.object is None or not context.object.visible_get(view_layer=context.view_layer) :
            speedsculpt.primitives_parenting = False
            speedsculpt.add_mirror = False
        else:
            act_obj = context.active_object
            bpy.ops.object.mode_set(mode = 'OBJECT')

        context.space_data.overlay.show_retopology = False

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')

        bpy.ops.mesh.primitive_plane_add(size=1, align='WORLD', enter_editmode=True)
        bpy.ops.mesh.merge(type='CENTER')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.select_all(action='SELECT')

        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        new_obj = context.active_object

        #Add Skin modifier
        mod_skin = new_obj.modifiers.new("Skin", 'SKIN')
        mod_skin.use_smooth_shade = True
        mod_skin.branch_smoothing = 1

        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.object.skin_root_mark()
        bpy.ops.object.mode_set(mode = 'OBJECT')

        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                act_obj.select_set(state=True)
                context.view_layer.objects.active = act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                act_obj.select_set(state=False)
                new_obj.select_set(state=True)
                context.view_layer.objects.active = new_obj
        
        # Add Subdiv
        mod_subsurf = new_obj.modifiers.new("Subdivision", 'SUBSURF')
        mod_subsurf.levels = 3

        #Enter in edit mode
        bpy.ops.object.mode_set(mode = 'EDIT')

        shading = context.space_data.shading
        shading.show_xray = True

        # Add Mirror
        if speedsculpt.add_mirror:
            bpy.ops.object.speedsculpt_add_mirror()

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.transform.translate('INVOKE_DEFAULT') 
          
        return {"FINISHED"}

class SPEEDSCULPT_OT_create_gp_lines(bpy.types.Operator):
    bl_idname = "object.speedsculpt_create_gp_line"
    bl_label = "Create GP Lines"
    bl_description = "Create Surface with Greape Pencil and Bsurface"
    bl_options = {"REGISTER", "UNDO"}


    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        selected = context.selected_objects
        actObj = context.active_object if context.object is not None else None

        bpy.ops.preferences.addon_enable(module="mesh_bsurfaces")

        # prepare GP
        context.scene.tool_settings.annotation_stroke_placement_view3d = 'SURFACE'
        context.scene.bsurfaces.SURFSK_shade_smooth = True
        context.scene.bsurfaces.SURFSK_edges_U = 6
        context.scene.bsurfaces.SURFSK_edges_V = 4

        #Create Empty mesh
        bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=True, align='WORLD')
        gp_surface = context.active_object
        context.active_object.name= "GP_Surface"
        bpy.ops.mesh.delete(type='VERT')    
        bpy.ops.object.mode_set(mode = 'OBJECT')
        if bpy.app.version < (4, 1, 0):
            bpy.ops.object.shade_smooth(use_auto_smooth=True)
        else:
            bpy.ops.object.shade_smooth_by_angle()


        # Add Mirror
        bpy.ops.object.speedsculpt_add_mirror()

        # if speedsculpt.add_mirror :
        #     mod_mirror = gp_surface.modifiers.new("Mirror", 'MIRROR')
        #     mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
        #     for prop, axis_index in mirror_axes.items():
        #         if getattr(speedsculpt, prop):
        #             mod_mirror.use_axis[axis_index] = True
        #     # if speedsculpt.mirror_x:
        #     #     mod_mirror.use_axis[0] = True
        #     # if speedsculpt.mirror_y:
        #     #     mod_mirror.use_axis[1] = True
        #     # if speedsculpt.mirror_z:
        #     #     mod_mirror.use_axis[2] = True
        #
        #     mod_mirror.use_mirror_merge = False
        #
        #     if speedsculpt.ref_obj:
        #         mod_mirror.mirror_object = speedsculpt.ref_obj
        #     elif len([obj for obj in context.selected_objects]) == 1:
        #         mod_mirror.mirror_object = actObj
        #     else :
        #         bpy.ops.object.modifier_remove(modifier="Mirror")

        #Add Solidify
        mod_solidify = gp_surface.modifiers.new("Solidify", 'SOLIDIFY')
        mod_solidify.thickness = 0.4
        mod_solidify.offset = 0
        mod_solidify.use_quality_normals = True
        mod_solidify.use_even_offset = True

        #Add subsurf
        mod_subsurf = gp_surface.modifiers.new("Subsurf", 'SUBSURF')
        mod_subsurf.levels = 3

        #Add Shrinkwrap
        if selected :
            mod_shrinkwrap = gp_surface.modifiers.new("Shrinkwrap", 'SHRINKWRAP')
            mod_shrinkwrap.target = actObj

            bpy.ops.object.modifier_move_to_index(modifier=mod_shrinkwrap.name, index=0)

            # bpy.ops.object.modifier_move_up(modifier=mod_shrinkwrap.name)
            # bpy.ops.object.modifier_move_up(modifier=mod_shrinkwrap.name)
            # bpy.ops.object.modifier_move_up(modifier=mod_shrinkwrap.name)
            # bpy.ops.object.modifier_move_up(modifier=mod_shrinkwrap.name)

        context.scene.bsurfaces.SURFSK_object_with_retopology = gp_surface
        context.scene.bsurfaces.SURFSK_mesh = gp_surface

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.wm.tool_set_by_id(name="builtin.annotate")
        return {"FINISHED"}
               
def ClippingMerge(self, context):
    
    obj = context.active_object  
    for mod in obj.modifiers :
        if mod.type == 'MIRROR':
            if mod.use_mirror_merge == True :
                mod.name = "Mirror"
                mod.use_mirror_merge = False
                mod.use_clip = False
            
            else :
                mod.name = "Mirror_Skin"
                mod.use_mirror_merge = True
                mod.use_clip = True

class SPEEDSCULPT_OT_remove_bevel(bpy.types.Operator):
    bl_idname = "object.remove_bevel"
    bl_label = "Remove Bevel"
    bl_description = "Delete the Bevel modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        mirror = context.object.modifiers.get("Bevel")
        if mirror :
            bpy.ops.object.modifier_remove(modifier="Bevel")
        return {"FINISHED"}

class SPEEDSCULPT_OT_remove_solidify(bpy.types.Operator):
    bl_idname = "object.remove_solidify"
    bl_label = "Remove Solidify"
    bl_description = "Delete the Solidify modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        solidify = context.object.modifiers.get("Solidify")
        if solidify :
            bpy.ops.object.modifier_remove(modifier="Solidify")
        return {"FINISHED"}

class SPEEDSCULPT_OT_remove_shrinkwrap(bpy.types.Operator):
    bl_idname = "object.remove_shrinkwrap"
    bl_label = "Remove Shrinkwrap"
    bl_description = "Delete the Shrinkwrap modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        shrinkwrap = context.object.modifiers.get("Shrinkwrap")
        if shrinkwrap :
            bpy.ops.object.modifier_remove(modifier="Shrinkwrap")
        return {"FINISHED"}    

class SPEEDSCULPT_OT_remove_mirror(bpy.types.Operator):
    bl_idname = "object.speedsculpt_remove_mirror"
    bl_label = "Remove Mirror"
    bl_description = "Delete the Mirror modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        mirror = context.object.modifiers.get("Mirror")
        mirror_skin = context.object.modifiers.get("Mirror_Skin")

        selected_objects = bpy.context.selected_objects

        # Loop through each object
        for obj in selected_objects:
            # Set the object as the active object
            context.view_layer.objects.active = obj

            # Remove the Mirror modifier if it exists
            # if "Mirror" in [modifier.name for modifier in obj.modifiers]:
            #     bpy.ops.object.modifier_remove(modifier="Mirror")


            if mirror:
                bpy.ops.object.modifier_remove(modifier="Mirror")

            if mirror_skin:
                bpy.ops.object.modifier_remove(modifier="Mirror_Skin")
        return {"FINISHED"}

class SPEEDSCULPT_OT_add_mirror(bpy.types.Operator):
    bl_idname = "object.speedsculpt_add_mirror"
    bl_label = "Add Mirror Modifier"
    bl_description = "Add Mirror Modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        obj = context.object

        mode = context.object.mode

        if speedsculpt.ref_obj == obj:
            speedsculpt.ref_obj = None
            self.report({'WARNING'}, "The Active Object is the Ref Object")
            # return {'CANCELLED'}

        bpy.ops.object.mode_set(mode = 'OBJECT')

        skin = context.object.modifiers.get("Skin")
        mirror = context.object.modifiers.get("Mirror")

        # if speedsculpt.add_mirror :
        for obj in context.selected_objects:
            mod_mirror = obj.modifiers.new("Mirror", 'MIRROR')

            # Axes
            mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
            for prop, axis_index in mirror_axes.items():
                if getattr(speedsculpt, prop):
                    mod_mirror.use_axis[axis_index] = True
                    # if skin:
                    #     mod_mirror.use_bisect_axis[axis_index] = True
                else:
                    mod_mirror.use_axis[axis_index] = False

            # Ref Object
            if speedsculpt.ref_obj:
                mod_mirror.mirror_object = speedsculpt.ref_obj
            else:
                mod_mirror.mirror_object = None
                speedsculpt.ref_obj = None

            if skin:
                mod_mirror.use_mirror_merge = True
                # mod_mirror.use_bisect_axis[0] = True
                mod_mirror.use_clip = True

            else:
                mod_mirror.use_mirror_merge = False

            
            if obj.modifiers.get("GeometryNodes_Geomesh"):
                bpy.ops.object.modifier_move_to_index(modifier=mod_mirror.name, index=len(obj.modifiers)-1)
                mod_mirror.use_pin_to_last = True
            else:
                bpy.ops.object.modifier_move_to_index(modifier=mod_mirror.name, index=0)

            if speedsculpt.ref_obj is not None:
                bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')

        bpy.ops.object.mode_set(mode=mode)

        return {"FINISHED"}

def is_symmetric(bone1, bone2, threshold=0.1):
    # Check if the bones are symmetric along the X-axis
    return abs(bone1.head.x + bone2.head.x) < threshold and \
           abs(bone1.head.y - bone2.head.y) < threshold and \
           abs(bone1.head.z - bone2.head.z) < threshold

class SPEEDSCULPT_OT_skin_armature(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_skin_armature'
    bl_label = "Create Armature from Skin"
    bl_options = {'REGISTER'}
    bl_description = "Create an Armature from the Skin Modifier.\n\nNote: It will apply the Mirror Modifier."


    def execute(self, context):
        act_obj = context.active_object
        mode = act_obj.mode

        if act_obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Remove Vgroups
        if act_obj.vertex_groups:
            bpy.ops.object.vertex_group_remove(all=True)

        for mod in act_obj.modifiers:
            if mod.type == 'MIRROR':
                bpy.ops.object.modifier_apply(modifier=mod.name)

        bpy.ops.object.skin_armature_create(modifier="Skin")
        for mod in act_obj.modifiers:
            if mod.type == 'ARMATURE':
                mod.use_multi_modifier = True


        armature = context.active_object.data
        context.view_layer.objects.active = context.active_object

        # Must be in Edit mode to change bone names
        bpy.ops.object.mode_set(mode='EDIT')

        # Find symmetric bones
        bones = armature.edit_bones
        for bone in bones:
            for potential_mirror in bones:
                if bone != potential_mirror and is_symmetric(bone, potential_mirror):
                    base_name = bone.name.rsplit('_', 1)[0]  # Remove any existing suffix
                    if bone.head.x < 0:  # Assuming negative X is left
                        bone.name = base_name + '_L'
                        potential_mirror.name = base_name + '_R'
                    else:
                        bone.name = base_name + '_R'
                        potential_mirror.name = base_name + '_L'
                    break

        # bpy.ops.object.mode_set(mode='EDIT')
        # bpy.ops.armature.select_all(action='SELECT')
        # bpy.ops.armature.autoside_names(type='XAXIS')
        # bpy.ops.armature.select_all(action='DESELECT')
        # bpy.ops.object.mode_set(mode="POSE")
        # # Rename of the bones
        # armature = context.active_object.data
        # for bone in armature.bones:
        #     bone.name = bone.name.replace('.', '_')





        bpy.ops.object.mode_set(mode=mode)

        context.object.name = act_obj.name + "_Armature"
        bpy.ops.object.mode_set(mode="POSE")
        context.object.pose.use_mirror_x = True

        return {'FINISHED'}

class SPEEDSCULPT_OT_apply_skin_armature(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_apply_skin_armature'
    bl_label = "Apply Armature from Skin"
    bl_options = {'REGISTER'}
    bl_description = "Apply the Armature from the Skin Modifier."

    def execute(self, context):
        act_obj = context.active_object
        mode = act_obj.mode

        for mod in act_obj.modifiers:
            if mod.type == 'ARMATURE':
                bpy.ops.object.modifier_apply(modifier=mod.name)
            if mod.type == 'SKIN':
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.object.skin_loose_mark_clear(action='MARK')
                bpy.ops.object.mode_set(mode=mode)

        # Remove Vgroups
        if act_obj.vertex_groups:
            bpy.ops.object.vertex_group_remove(all=True)

        bpy.ops.object.mode_set(mode=mode)

        # REMOVE ARMATURE
        armature = context.scene.objects.get(act_obj.name + "_Armature")
        if armature:
            bpy.data.objects.remove(armature, do_unlink=True)
        return {'FINISHED'}

class SPEEDSCULPT_OT_remove_skin_armature(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_remove_skin_armature'
    bl_label = "Remove Armature from Skin"
    bl_options = {'REGISTER'}
    bl_description = "Remove the Armature from the Skin Modifier."

    def execute(self, context):
        act_obj = context.active_object
        mode = act_obj.mode

        # Remove Vgroups
        if act_obj.vertex_groups:
            bpy.ops.object.vertex_group_remove(all=True)

        for mod in act_obj.modifiers:
            if mod.type == 'ARMATURE':
                bpy.ops.object.modifier_remove(modifier=mod.name)

        bpy.ops.object.mode_set(mode=mode)

        # REMOVE ARMATURE
        armature = context.scene.objects.get(act_obj.name + "_Armature")
        if armature:
            bpy.data.objects.remove(armature, do_unlink=True)
        return {'FINISHED'}

class SPEEDSCULPT_OT_apply_mirror(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_apply_mirror'
    bl_label = "Apply Mirror Modifier"
    bl_options = {'REGISTER'}

    def execute(self, context):
        self.act_obj = context.active_object

        for obj in context.selected_objects:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            for mod in obj.modifiers:
                if mod.type == 'MIRROR':
                    bpy.ops.object.modifier_apply(modifier=mod.name)

        self.act_obj.select_set(state=True)
        context.view_layer.objects.active = self.act_obj
        return {'FINISHED'}

class SPEEDSCULPT_OT_add_gp_bevel(bpy.types.Operator):
    bl_idname = "object.add_gp_bevel"
    bl_label = "Add Bevel Modifier"
    bl_description = "Add Bevel Modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        mode = context.object.mode
        bpy.ops.object.mode_set(mode = 'OBJECT')

        bevel = context.object.modifiers.get("Bevel")
        if not bevel:
            mod_bevel = context.object.modifiers.new("Bevel", 'BEVEL')
            mod_bevel.show_in_editmode = True
            mod_bevel.limit_method = 'ANGLE'
            mod_bevel.segments = 4
            mod_bevel.angle_limit = 1.53589
            mod_bevel.use_clamp_overlap = False
            bpy.ops.object.modifier_move_up(modifier=mod_bevel.name)

        bpy.ops.object.mode_set(mode=mode)
        return {"FINISHED"}

class SPEEDSCULPT_OT_add_smooth_skin(bpy.types.Operator):
    bl_idname = "object.add_smooth_skin"
    bl_label = "Add Smooth Skin"
    bl_description = "Smooth the skin wire"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        act_obj = context.active_object

        smooth_skin = context.object.modifiers.get("Smooth_skin")
        if not smooth_skin:
            subsurf_mod = act_obj.modifiers.new("Smooth_skin","SUBSURF")
            subsurf_mod.levels = 2
            subsurf_mod.show_only_control_edges = False

            bpy.ops.object.modifier_move_to_index(modifier=subsurf_mod.name, index=0)

        return {"FINISHED"}

class SPEEDSCULPT_OT_Remove_Smooth_Skin(bpy.types.Operator):
    bl_idname = "object.remove_smooth_skin"
    bl_label = "Remove Smooth skin"
    bl_description = "Delete the Smooth skin modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):  
        
        smooth_skin = context.object.modifiers.get("Smooth_skin")
        if smooth_skin :
            bpy.ops.object.modifier_remove(modifier="Smooth_skin")
        
        return {"FINISHED"}

CLASSES =  [SPEEDSCULPT_OT_Remove_Smooth_Skin,
            SPEEDSCULPT_OT_add_smooth_skin,
            SPEEDSCULPT_OT_add_gp_bevel,
            SPEEDSCULPT_OT_add_mirror,
            SPEEDSCULPT_OT_remove_mirror,
            SPEEDSCULPT_OT_remove_shrinkwrap,
            SPEEDSCULPT_OT_remove_solidify,
            SPEEDSCULPT_OT_remove_bevel,
            # SPEEDSCULPT_OT_shrinkwrap_gp_lines,
            SPEEDSCULPT_OT_create_gp_lines,
            SPEEDSCULPT_OT_add_skin,
            SPEEDSCULPT_OT_clean_metaballs,
            SPEEDSCULPT_OT_add_metaballs,
            SPEEDSCULPT_OT_add_custom_primitives,
            SPEEDSCULPT_OT_apply_mirror,
            SPEEDSCULPT_OT_skin_armature,
            SPEEDSCULPT_OT_apply_skin_armature,
            SPEEDSCULPT_OT_remove_skin_armature
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)