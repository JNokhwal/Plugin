'''-*- coding:utf-8 -*-

ProFlow Add-on
Copyright (C) 2020 Cedric Lepiller aka Pitiwazou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

<pep8 compliant>'''

import bpy
from bpy.types import Panel, Operator, UIList, Menu
from .operators import *
from .lattice import *
from .curves import *
from .functions import get_addon_preferences
from .preview import *
import os
from .icon.icons import load_icons
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper

def is_bsurface_activated():
    return any('bsurface' in addon.lower() for addon in bpy.context.preferences.addons.keys())

def is_looptools_activated():
    return any('looptools' in addon.lower() for addon in bpy.context.preferences.addons.keys())


# -----------------------------------------------------------------------------
#    Help
# -----------------------------------------------------------------------------
class SPEEDSCULPT_MT_help_dyntopo_remesh(Operator):
    bl_idname = "speedsculpt.help_dyntopo_remesh"
    bl_label = ""

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):
        layout = self.layout

        icons = load_icons()
        prefs = get_addon_preferences()

        layout = self.layout

        layout.prop(prefs, 'show_help', text="Show Addon Help")
        layout.separator()
        layout.label(text="With Blender you can now choose Between Remesh or Dyntopo.")
        layout.separator()
        layout.label(text="REMESH -", icon='MESH_UVSPHERE')
        layout.label(text="Remeshing is a technique that automatically rebuilds the geometry")
        layout.label(text="with a more uniform topology.")
        layout.label(text="Remeshing can either add or remove the amount of topology")
        layout.label(text="depending on a defined resolution.")
        layout.label(text="This technique is especially useful for sculpting,")
        layout.label(text="to generate better topology")
        layout.label(text="after blocking out the initial shape.")
        layout.separator()
        layout.label(text="DYNTOPO -", icon='MESH_ICOSPHERE')
        layout.label(text="Dyntopo is a dynamic tessellation sculpting method,")
        layout.label(text="adds and removes details on-the-fly,")
        layout.label(text="whereas regular sculpting only affects the shape of a mesh.")
        layout.separator()
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="Both are great, but Remesh gives better results and performances.")
        layout.label(text="The best is to use Remesh to make the base of your model.")
        layout.label(text="Once ok, start using Dyntopo to be able to add details.")

        row = layout.row(align=True)
        row.scale_y = 1.3
        icon = icons.get("icon_youtube")
        row.operator("wm.url_open", text="DOCUMENTATION",
                            icon_value=icon.icon_id).url = "https://youtu.be/6BFCV7jobrM"

        # layout.separator()
        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Remesh / Dyntopo video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

class SPEEDSCULPT_MT_help_dyntopo_remesh_setting(Operator):
    bl_idname = "speedsculpt.help_remesh_dyntopo_settings"
    bl_label = ""

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):
        layout = self.layout

        icons = load_icons()
        layout.label(text="REMESH/DYNTOPO - Settings")
        layout.separator()
        
        icon = icons.get("icon_s")
        layout.label(text="Will smooth the mesh to have better forms.", icon_value=icon.icon_id)
        
        icon = icons.get("icon_u")
        layout.label(text="Update, it will convert the mesh using Remesh or Dyntopo.",icon_value=icon.icon_id)
        
        layout.label(text="        REMESH")
        layout.label(text="        The resulting mesh will be remeshed with Quads.")
        
        layout.label(text="        DYNTOPO")
        layout.label(text="        The resulting mesh will be remeshed with Triangles.")
        
        icon = icons.get("icon_corrective_smooth")
        layout.label(text="Will smooth the mesh without updating the geometry.", icon_value=icon.icon_id)
        
        icon = icons.get("icon_options")
        layout.label(text="Options for each mode to edit the shading, fill holes, etc.", icon_value=icon.icon_id)

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Remesh / Dyntopo Settings video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

class SPEEDSCULPT_MT_help_dyntopo_remesh_value(bpy.types.Operator):
    bl_idname = "speedsculpt.help_remesh_dyntopo_value"
    bl_label = ""

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        layout.label(text="REMESH MODE - Remesh Value", icon='MESH_UVSPHERE')
        layout.separator()
        layout.label(text="The resolution or the amount of detail the remeshed mesh will have.")
        layout.label(text="The value is used to define the size, in object space, of the quads.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="Smaller value gives smaller quads.")
        layout.separator()
        layout.label(text="DYNTOPO Mode - Resolution", icon='MESH_ICOSPHERE')
        layout.separator()
        layout.label(text="The resolution or the amount of detail the remeshed mesh will have.")
        layout.label(text="The value is used to define the size, in object space, of the Triangles.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="Higher value gives smaller Triangles.")

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Remesh / Dyntopo Value video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

class SPEEDSCULPT_MT_help_shading(Menu):
    bl_label = "Help Shading"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="You can edit settings by clicking on the SHADING button")
        
        layout.separator()
        
        icon = icons.get("icon_shading")
        layout.label(text="SOLO", icon_value=icon.icon_id)
        layout.label(text="Make non selected objects transparent.")
        
        layout.separator()
        layout.label(text="CLICK - Solo the Selection.")
        layout.label(text="SHIFT+CLICK - Add the Selection.")
        layout.label(text="CTRL+CLICK - Remove the Selection.")
        layout.label(text="ALT+CLICK - Invert the Selection.")
        layout.label(text="CTRL+SHIFT+CLICK - Exit.")
        
        layout.separator()
        
        layout.label(text="STUDIO", icon='LIGHT_SPOT')
        layout.label(text="Studio Shading.")
        layout.separator()
        layout.label(text="CTRL+SHIFT+CLICK - Rotate the Environment.")
        
        layout.separator()
        
        layout.label(text="MATCAPS", icon='NODE_MATERIAL')
        layout.label(text="Basic Matcaps.")
        
        layout.separator()
        
        layout.label(text="SILOUHETE", icon='OUTLINER_OB_VOLUME')
        layout.label(text="Silhouete Shading to check your Mesh proportions.")
        layout.label(text="You can change the color in the SHADING part.")
        
        layout.separator()
        
        layout.label(text="WIREFRAME", icon='SHADING_WIRE')
        layout.label(text="Activate the Wireframe.")
        
        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Remesh / Dyntopo Shading video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_creation_tools(Menu):
    bl_label = "Help Creation Tools"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        icon = icons.get("icon_tools")         
        layout.label(text="Speedsculpt gives you a bunch of tools to simplify the creation of your assets.", icon_value=icon.icon_id)
        layout.label(text="You will have first the choose about how you will create the assets.")
        layout.separator()
        layout.label(text="MOUSE", icon='MOUSE_MMB')
        layout.label(text="The asset will be created on your mouse, you will directly move it where you want.")
        layout.separator()
        layout.label(text="Origin", icon='OBJECT_ORIGIN')
        layout.label(text="The asset will be created at the origin of the scene (center of the grid).")
        layout.separator()
        layout.label(text="CURSOR", icon='PIVOT_CURSOR')
        layout.label(text="The asset will be created at the Cursor location.")
        layout.label(text="If you activate the 'Cursor Rot' option, the asset will copy the Cursor Rotation.")
        layout.separator()
        layout.label(text="SELECTION", icon='RESTRICT_SELECT_OFF')
        layout.label(text="The asset will be created at the center of your selection.")
        layout.separator()
        layout.label(text="PARENT", icon='ORIENTATION_PARENT')
        layout.label(text="The new asset will be the child of your active object selected.")
        layout.label(text="This is usefull to create a hierarchy of objects")
        layout.label(text="and edit a bunch of objects at the same time.")
        layout.separator()
        layout.label(text="MIRROR", icon='MOD_MIRROR')
        layout.label(text="The new asset will have a mirror modifier.")
        layout.label(text="You will choose the Axis you want and the object as reference.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="All the tools created with speedsculpt will take these settings into account.")
        layout.label(text="It can be all the settings, or only Parent and Mirror.")

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Creation Tools video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_primitives(Menu):
    bl_label = "Help Primitives"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_primitives")         
        layout.label(text="Basic set of Primitives to make your assets.", icon_value=icon.icon_id)
        layout.label(text="Depending of the mode (REMESH/DYNTOPO), your primitives will be made of quads or triangles")
        layout.label(text="if you activate the Update Option.")
        layout.separator()
        layout.label(text="WORKFLOW")
        layout.label(text="- Select the MOUSE mode, click on a primitive and move it where you want.")
        layout.label(text="   You can now edit it with Sculpting tools and merge it with other objects.")
        layout.label(text="- If you have a selection, you can set the PARENT and MIRROR options and create your primitive.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="You can place Meshes primitives and Metaballs at the same time, the addon will convert them.")

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Creation Tools video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_asset_library(Menu):
    bl_label = "Help Assets Library"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_library")         
        layout.label(text="With the Assets Library, yout can add custom objects to your scene.", icon_value=icon.icon_id)
        layout.label(text="The Assets Library takes into account the options (MOUSE, CURSOR, ORIGIN, SELECTION, PARENT, MIRROR).")
        layout.label(text="This is the best solution to gain time on your sculpt with custom assets.")
        layout.separator()
        layout.label(text="You can add your own assets to the library.")
        layout.label(text="You can add Categories.")
        layout.separator()
        layout.label(text="If you bought the Asset Management Addon, you will be able to display some categories inside speedsculpt.")
        layout.label(text="To do this, go into the preferences of speedsculpt in the Blender Preferences > Add-ons > Speedscukpt.")
        layout.label(text="And go into the Option tab > ASSETS LIBRARY SETTINGS and click on the ADD NEW CATEGORY button.")
        layout.label(text="Go to you Asset Management library, enter inside a category and validate.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="You can check the information button for more insite.")

        icon = icons.get("icon_gumroad")
        layout.operator("wm.url_open",text="ASSET MANAGEMENT ADDON", icon_value=icon.icon_id).url = "https://gumroad.com/l/asset_management"

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Assets Library video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_draw_mesh(Menu):
    bl_label = "Help Draw Mesh"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_draw_mesh") 
        layout.label(text="The DRAW MESH tool is a really nice way to make objects.", icon_value=icon.icon_id)
        layout.label(text="It works with the Grease Pencil.")
        layout.separator()
        layout.label(text="Start by selecting the option you want, CURSOR or SURFACE.")
        layout.label(text="")
        layout.label(text="CURSOR", icon='PIVOT_CURSOR')
        layout.label(text="Will draw the Grease Pencil at the Cursor location.")
        layout.label(text="")
        layout.label(text="SURFACE", icon='SURFACE_NSURFACE')
        layout.label(text="Will draw the Grease Pencil on the surface of objects in the scene.")
        layout.label(text="")
        layout.label(text="DRAW SIZE", icon='SURFACE_NCYLINDER')
        layout.label(text="Will determine the widh of the mes created.")
        layout.separator()
        layout.label(text="Once the settings are OK, click on the Draw Mesh button and start to draw.")
        layout.label(text="You will be in a draw mode, you will have information at the bottom left of the 3DView.")
        layout.label(text="Press SPACE to validate and exit the Draw Mode.")

        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="- You can draw more than one line.")
        layout.label(text="- The tool works with the MIRROR option.")
        layout.label(text="- If you have a selection, the drawing will be merged with your selection.")
        layout.label(text="- If you have nothin selected, the drawing will creates a new object.")

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Draw Mesh video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_draw_surface(Menu):
    bl_label = "How to draw surfaces"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_surface") 
        layout.label(text="Create surfaces with Bsurface and Grease Pencil.", icon_value=icon.icon_id)
    
        layout.separator()
        layout.label(text="Edit the Settings & Click on DRAW SURFACE.")
        layout.label(text="Draw parrallel lines and press SPACE/ENTER.")
        layout.label(text="That will create an object and you will be able to edit it with the Thickness setting")
        layout.label(text="if you disable the Update and Smooth settings.")
        layout.label(text="You can add a Mirror and a Bevel Modifier too.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="- You need to create the lines in the same direction, check Bsurface videos on Youtube for more information.")
        layout.label(text="- To delete a drawing, press D + RIGHT MOUSE BUTTON and Drag.")

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Draw Surfaces video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_create_cut_tools(Menu):
    bl_label = "Help Create or cut tools"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        
        icon = icons.get("icon_cutter") 
        layout.label(text="CUTTER TOOLS is a suite of tool to create forms or to cut Meshes.", icon_value=icon.icon_id)

        layout.separator()
        
        layout.label(text="CREATE", icon='MESH_CUBE')
        layout.label(text="Set Width of the Mesh you will create.")
        layout.label(text="Select the tool you will use (RECTANGLE, CIRCLE, Line or Curve).")
        layout.label(text="You will enter in a modal, a mode with option at the bottom left corner of the 3DView.")
        layout.label(text="Click and drag to draw you cutting object.")

        layout.separator()
        
        layout.label(text="CUT", icon='MOD_BOOLEAN')
        layout.label(text="Select the operation you want to do, UNION, DIFFERENCE OR REBOOL.")
        layout.label(text="Select the tool you will use .")
        layout.label(text="You will enter in a modal.")
        layout.label(text="Click and drag to draw you cutting object.")

        layout.separator()
        
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="- The cutting part can take time on dense objects, be patient.")
        layout.label(text="- By pressing CTRL when clicking on an object, you will set the Cursor on the surface of the object.")
        layout.label(text="- The new mesh will follow the Cursor rotation.")

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Cutter tools video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_skin(Menu):
    bl_label = "Help Skin"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        layout.label(text="Create objects with skin Modifier.")
        layout.label(text="Perfect to create Characters or parts like Teeth, etc.")
        layout.separator()
        icon = icons.get("icon_draw_skin") 
        layout.label(text="DRAW SKIN", icon_value=icon.icon_id)
        layout.label(text="Click and trace the form you want.")
        layout.label(text="Go in edit mode to edit it.")
        layout.label(text="To scale a point, press CTRL + A.")
        layout.separator()
        icon = icons.get("icon_skin") 
        layout.label(text="ADD SKIN", icon_value=icon.icon_id)
        layout.label(text="When activating the tool, you will have only one vertex.")
        layout.label(text="place it where you want.")
        layout.label(text="To Extrude it, use E key or CTRL + RMB.")
        layout.label(text="To scale a point, press CTRL + A.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="When using a mirror modifier and Origin setting,")
        layout.label(text="The vertex will be at the center of the scene.")
        layout.label(text="To Extrude it, use CTRL + RMB and move your mouse.") 

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Assets Library video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_envelope(Menu):
    bl_label = "Help Envelope"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_enveloppe") 
        layout.label(text="Create Armature to make your character.", icon_value=icon.icon_id)
        
        layout.label(text="You can use the origin option from primitives to place it at the center of the grid.")
        layout.separator()
        layout.label(text="You can select and symmetrize bones.")
        layout.label(text="And use the X-Axis Mirror to tweak both sides.")
        layout.separator()
        layout.label(text="Change the Dyntopo or Remsh Value with Smooth Options/Update and Click on the Convert button.")
        layout.separator()
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="To scale a bone, press ALT + S.")
        layout.label(text="To extrude a bone, press E or CTRL + RMB.")

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Enveloppe video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_curves(Menu):
    bl_label = "Help Curves"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.separator()
        
        icon = icons.get("icon_lathe") 
        layout.label(text="LATHE", icon_value=icon.icon_id)
        layout.label(text="Create a Lathe by drawing in the 3Dview.")
        
        layout.separator()
        
        icon = icons.get("icon_curve") 
        layout.label(text="CURVE", icon_value=icon.icon_id)
        layout.label(text="Create a curve by drawing in the 3Dview.")
        layout.label(text="You can Edit the Resolution of the curve.")
        layout.label(text="You can convert the Curve into a skin Modifier.")
        
        layout.separator()
        
        layout.label(text="You can also make a mesh from it by clicking ont the BBox button.")
        layout.label(text="Edit the Settings for the Depth, Offset and Bevel.")
        
        layout.separator()
        
        layout.label(text="If you stay in Curve Mode, you can Edit the settings and the Curve itself.")
        layout.label(text="After that, you can convert it in REMESH or DYNTOPO.")
        # layout.separator()
        # layout.label(text="Examples :")
        # layout.operator("wm.url_open", text="Convert Curve to skin").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/convert_curve.gif"
        # layout.operator("wm.url_open", text="Slice/Cut/Rebool objects with curves").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/curves_slice.gif"

class SPEEDSCULPT_MT_help_symmetrize(Menu):
    bl_label = "Help Symmetrize"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_symmetrize") 
        layout.label(text="Symmetrize your selection.", icon_value=icon.icon_id)
        
        layout.separator()
        
        
        icon = icons.get("icon_sym_plus_x") 
        layout.label(text="You can choose the direction of the Symmetrize.", icon_value=icon.icon_id)
        layout.label(text="The mesh will be symmetrized.")
        layout.label(text="If you Activated the UPDATE button, the mesh will be remeshed")
        layout.label(text="depending of the mode you chose REMESH/DYNTOPO.")

        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Symmetrize video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"
        
class SPEEDSCULPT_MT_help_lattice(Menu):
    bl_label = "Help Lattice"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_lattice") 
        layout.label(text="Create Lattice and deform your mesh", icon_value=icon.icon_id)
        
        layout.separator()
        
        layout.label(text="You can Edit the Lattice and connect/Disconnect Objects from it")
        layout.label(text="You can also use Mask to create the Lattice on your Mesh")
        # layout.separator()
        # layout.label(text="Example :")
        # layout.operator("wm.url_open", text="Add Lattice and deform objects").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/lattices.gif"
        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Lattice video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_remesh(Menu):
    bl_label = "Help Remesh"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_remesh")        
        layout.label(text="REMESH", icon_value=icon.icon_id)
        
        layout.label(text="Add a Remesh Modifier.")
        layout.label(text="You can Edit the Settings and Apply/Remlove it.")
        
        layout.separator()
        
        icon = icons.get("icon_decimate")        
        layout.label(text="DECIMATE", icon_value=icon.icon_id)
        
        layout.label(text="Simplify your mesh or use mask to simplify a part of it")
        layout.label(text="You can Edit the Settings and Apply/Remlove it.")
        
        layout.separator()
        
        icon = icons.get("icon_quadriflow")        
        layout.label(text="QUADRIFLOW", icon_value=icon.icon_id)
        
        layout.label(text="It's a retopology tool")
        layout.label(text="Edit the Settings and click on OK.")
        
        # layout.separator()
        # layout.label(text="Examples :")
        # layout.operator("wm.url_open", text="Remesh object").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/remesh.gif"
        # layout.operator("wm.url_open", text="Decimate mesh with mask").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/decimate.gif"
        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Remesh video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_MT_help_extract_mask(Menu):
    bl_label = "Help Extract Mask"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_mask") 
        layout.label(text="Mask Operations to Extract, Cut, and Slice a part of your Mesh.", icon_value=icon.icon_id)

        layout.separator()
        layout.label(text="You will have to choose between Mask and Face Sets")
        layout.label(text="You will have 3 possible Operations")
        layout.label(text="EXTRACT - CUT - SLICE")
        
        layout.separator()
        layout.label(text="EXTRACT", icon='OVERLAY')
        layout.label(text="Create a new object from the mask or the Face Set")
        
        layout.separator()
        
        layout.label(text="CUT", icon='MOD_SUBSURF')
        layout.label(text="Cut the mesh from the mask or the Face Set")

        layout.label(text=" ")
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="It will add a hole in the mesh,")
        layout.label(text="You can use the Fill Hole setting in dyntopo to close it")
        
        layout.separator()
        
        layout.label(text="SLICE", icon='SEQ_STRIP_DUPLICATE')
        layout.label(text="It will Slice the mesh from the mask or the Face Set")

        layout.label(text=" ")
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="When Using Face Sets, you need to isolate the part you want to edit")
        layout.label(text="Using SHIFT + H")
        layout.label(text="ALT + H will reveal the hidden parts")
        
        layout.separator()


        layout.label(text="You will be able to Add a Thichness with a Solidify Modifier,")
        layout.label(text="and edit it's value")
        layout.label(text="After that you will be able to apply the solidify and go to Sculpt mod")

        layout.label(text=" ")
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="This tool work for Remesh and dyntopo")

class SPEEDSCULPT_MT_help_quickpose(Menu):
    bl_label = "Help Quick Pose"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_quick_pose") 
        layout.label(text="Make a quick pose of your model.", icon_value=icon.icon_id)
        layout.label(text="You can use mask to pose only a part")
        layout.separator()
        layout.label(text="Direct Pose", icon='POSE_HLT')
        layout.label(text="Click on Create Bones, place the vertice, extrude it")
        layout.label(text="Click on the Pose button and make your pose")
        layout.separator()
        layout.label(text="Mask Pose", icon='MOD_MASK')
        layout.label(text="Click on Use Mask and Add Mask")
        layout.label(text="Paint your mask")
        layout.label(text="Click on Create Bones, place the vertice, extrude it")
        layout.label(text="Click on the Pose button and make your pose")
        layout.separator()
        layout.label(text="You can Edit and smooth your mask")
        layout.separator()
        layout.label(text="The creation of the Armature don't work in Local View", icon='ERROR')
        
        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Quick Pose video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"
        # layout.separator()
        # layout.label(text="Example :")
        # layout.operator("wm.url_open", text="Quick Pose with mask").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/quick_pose_mask.gif"

class SPEEDSCULPT_MT_help_muscles(Menu):
    bl_label = "Help Muscles"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        layout.label(text="This tools allow you to edit the Muscles from the library")
        layout.separator()
        layout.label(text="You can edit the Thickness of the Muscle to change his form.")
        layout.label(text="You can change the Offset to make different type of Muscle.")
        layout.label(text="And also the Factor to change the tips Thickness.")
        layout.separator()
        layout.label(text="In Edit Mode, you will be abble to add vertices to the Vertex Group.")
        layout.label(text="That will allow you to put the selection in the vertex group")
        layout.label(text="and change the form of the Muscles.")
        layout.label(text="You can add or remove vertices from the Vertex Group with the buttons")
        layout.label(text="Assign and Remove, aslo select the vertices in the Vertex Group.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="This tool will only work with the Muscles from the library.")
        layout.label(text="Once you make a Remesh, you will not be able to edit the muscles no more.")
        
        # icon = icons.get("icon_youtube")
        # layout.operator("wm.url_open", text="Quick Pose video tutorial",
        #                 icon_value=icon.icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"
        # layout.separator()
        # layout.label(text="Example :")
        # layout.operator("wm.url_open", text="Quick Pose with mask").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/quick_pose_mask.gif"

class SPEEDSCULPT_MT_help_geomesh(Menu):
    bl_label = "Help Geomesh"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        icon = icons.get("icon_geomesh") 
        layout.label(text="Create Geomesh objects.", icon_value=icon.icon_id)
        layout.label(text="To create a Geomesh Object, you need to put the objects in a Collection")
        layout.label(text="Then you can create a Geomesh Object from the Collection")
        layout.separator()
        layout.label(text="1 - Click on the Geomesh button in the Creation Tools")
        layout.label(text="2 - Select the Collection you want to use")
        layout.label(text="3 - Add a name to the Geomesh Object")
        layout.label(text="4 - Click on Create Geomesh")
        layout.label(text="The Geomesh Object will be created at the root of the Collections")
        layout.separator()
        layout.label(text="In the UI, you will see the Geomesh Object in a List")
        layout.label(text="Within this List, you will be able to:")
        layout.label(text=" ")
        icon = icons.get("icon_geomesh")
        layout.label(text="Rename the Geomesh Object by clicking on the Icon", icon_value=icon.icon_id)
        layout.label(text="Select the Item in the list to Edit the Geomesh Object")
        layout.label(text="Show/Hide the Geomesh Object", icon='HIDE_OFF')
        layout.label(text="Select the Geomesh Object", icon='RESTRICT_SELECT_OFF')
        layout.label(text="Lock the Geomesh Object", icon='DECORATE_LOCKED')
        layout.label(text="Use Show In Front", icon='CLIPUV_DEHLT')
        layout.label(text="Toggle the Mirror Modifier", icon='HIDE_OFF')
        layout.label(text="Delete the Geomesh Object", icon='TRASH')
        layout.separator()
        layout.label(text="Once you select an item in the list, you will be able to:")
        layout.label(text="• Edit the Voxel Size (The density of the mesh), Smaller is more detailed")
        layout.label(text="• Smooth the Mesh")
        layout.label(text="• Activate the Shade Smooth")
        layout.label(text="• Use Booleans")
        layout.separator()
        layout.label(text="If the Boolean is activated, you will have to select a Collection")
        layout.label(text="The Boolean Mode used will be 'DIFFERENT' to Cut the Geomesh Object")
        layout.separator()
        layout.label(text="Show/Hide the Geomesh Object", icon='HIDE_OFF')
        layout.label(text="Use the Shortcut CTRL+SHIFT+Q to toggle the Geomesh Object visibility")
        layout.label(text="You can change it in the Preferences")

# -----------------------------------------------------------------------------  
# UI
# -----------------------------------------------------------------------------
def Options(self, context):
    layout = self.layout
    toolsettings = context.tool_settings
    sculpt = toolsettings.sculpt
    prefs = get_addon_preferences()
    icons = load_icons()

    
    if prefs.dyntopo_or_remesh == "dyntopo":
        box = layout.box()
        split = box.split()
        box = split.column(align=True)
        
        row = box.row(align=True)
        row.prop(prefs, "apply_mirror", text="Apply Mirror")
        
        row = box.row(align=True)
        row.prop(prefs, 'remesh_mesh_smooth_normals', text='Shade Smooth')
        
        row = box.row(align=True)
        row.prop(prefs, "fill_holes", text="Fill Holes")
            
        if not prefs.smooth_mesh:
            row = box.row(align=True)
            row.prop(prefs, "smooth_mesh", text="Smooth Mesh")
            if context.selected_objects:
                icon = icons.get("icon_corrective_smooth")
        else:
            row = box.row(align=True)
            row.prop(prefs, "smooth_mesh", text="")
            row.prop(prefs, "smooth_mesh_value", text="Smooth Mesh Value")
            if context.selected_objects:
                icon = icons.get("icon_corrective_smooth")
        
        if not prefs.add_remesh:
            row = box.row(align=True)
            row.prop(prefs, "add_remesh", text="Remesh Mesh")
        else:
            row = box.row(align=True)
            row.prop(prefs, "add_remesh", text="")
            row.prop(prefs, "remesh_value", text="Remesh Value")

    else:
        box = layout.box()
        split = box.split()
        box = split.column(align=True)
        
        row = box.row(align=True)
        row.prop(prefs, "apply_mirror", text="Apply Mirror")
        
        row = box.row(align=True)
        row.prop(prefs, 'remesh_mesh_smooth_normals', text='Shade Smooth')

        # if prefs.dyntopo_or_remesh == 'dyntopo':
        row = box.row(align=True)
        row.prop(prefs, "fill_holes", text="Fill Holes")
        
        row = box.row(align=True)
        if not prefs.smooth_mesh:
            row.prop(prefs, "smooth_mesh", text="Smooth Mesh")
            icon = icons.get("icon_corrective_smooth")

        else:
            row.prop(prefs, "smooth_mesh", text="")
            row.prop(prefs, "smooth_mesh_value", text="Smooth Mesh Value")
            if context.selected_objects:
                icon = icons.get("icon_corrective_smooth")
                
        box = layout.box()
        split = box.split()
        box = split.column(align=True)
        
        row = box.row(align=True)
        row.label(text="Remesh Settings")
        
        row = box.row(align=True)
        row.prop(prefs, 'remesh_mesh_voxel_adaptivity', text='Voxel Adaptivity')
        
        row = box.row(align=True)
        row.prop(prefs, 'remesh_mesh_fix_poles', text='Fix Poles')
        
        row = box.row(align=True)
        row.prop(prefs, 'remesh_mesh_use_remesh_preserve_volume', text='Preserve Volume')

        if bpy.app.version >= (4, 1, 0):
            row = box.row(align=True)
            row.prop(prefs, 'remesh_mesh_preserve_attributes', text='Preserve Attributes')

        if bpy.app.version < (4, 1, 0):
            row = box.row(align=True)
            row.prop(prefs, 'remesh_mesh_preserve_paint_mask', text='Preserve Paint Mask')
        
            row = box.row(align=True)
            row.prop(prefs, 'remesh_mesh_preserve_sculpt_face_sets', text='Preserve Sculpt Face Sets')

        if bpy.app.version >= (2, 90, 0):
            row = box.row(align=True)
            row.prop(prefs, 'remesh_mesh_preserve_vertex_colors', text='Preserve Vertex Color')

def AddPrimitives(self, context):
    icons = load_icons()
    """ Sub panel for the adding assets """
    layout = self.layout
    toolsettings = context.tool_settings
    sculpt = toolsettings.sculpt
    obj = context.active_object
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    wm = context.window_manager

    modifier_flags = {"SOLIDIFY": False, "MIRROR": False, "SHRINKWRAP": False, "BEVEL": False,  "SKIN": False}
    
    if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer):
        for mod in context.active_object.modifiers:
            if mod.type in modifier_flags:
                modifier_flags[mod.type] = True

    # Access the flags as needed
    solidify = modifier_flags["SOLIDIFY"]
    mirror = modifier_flags["MIRROR"]
    shrinkwrap = modifier_flags["SHRINKWRAP"]
    bevel = modifier_flags["BEVEL"]
    skin = modifier_flags["SKIN"]

    icon = icons.get("icon_tools")
    row=layout.row(align=True)
    row.prop(speedsculpt, "show_creation_tools", text="", icon_value=icon.icon_id)
    row.prop(speedsculpt, "show_creation_tools", text="CREATION TOOLS",
             icon='TRIA_UP' if speedsculpt.show_creation_tools else 'TRIA_RIGHT')


    if prefs.show_help:
        row.menu("SPEEDSCULPT_MT_help_creation_tools", text="", icon='HELP')

    if speedsculpt.show_creation_tools:
        box = layout.box()
        split = box.split()
        box = split.column(align=True)
        row = box.row(align=True)
        row.prop(speedsculpt, 'create_primitives', expand = True)
        
            # CURSOR
        if speedsculpt.create_primitives == 'cursor':
            row = box.row(align=True)
            row.prop(speedsculpt, "copy_cursor_orientation", text="Copy Cursor Rotation")

        if context.object is not None and context.selected_objects and context.active_object and context.object.visible_get(view_layer=context.view_layer):
            # PARENTING
            row = box.row(align=True)
            row.prop(speedsculpt, "primitives_parenting", text ="Set Selection as Parent")
    
        # MIRROR
        row = box.row(align=True)
        row.prop(speedsculpt, "add_mirror", text ="Add Mirror to the new Mesh")

        if speedsculpt.add_mirror :
            row = box.row(align=True)
            if speedsculpt.mirror_x:
                row.prop(speedsculpt, "mirror_x", text="", icon='EVENT_X')
            else:
                row.prop(speedsculpt, "mirror_x", text="", icon='EVENT_X')

            if speedsculpt.mirror_y:
                row.prop(speedsculpt, "mirror_y", text="", icon='EVENT_Y')
            else:
                row.prop(speedsculpt, "mirror_y", text="", icon='EVENT_Y')

            if speedsculpt.mirror_z:
                row.prop(speedsculpt, "mirror_z", text="", icon='EVENT_Z')
            else:
                row.prop(speedsculpt, "mirror_z", text="", icon='EVENT_Z')
            row.prop_search(speedsculpt, "ref_obj", bpy.data, 'objects', text="")
            
            if not mirror  and context.selected_objects:
                row = box.row(align=True)
                icon = icons.get("icon_symmetrize")
                row.operator("object.speedsculpt_add_mirror", text="Add Mirror", icon_value=icon.icon_id)
            # else:
            #     row = box.row(align=True)
            #     icon = icons.get("icon_symmetrize")
            #     row.operator("object.speedsculpt_add_mirror", text="Add Mirror", icon_value=icon.icon_id)

        if mirror:
            split = box.split()
            col = split.column(align=True)
            row = col.row(align=True)
            for mod in context.active_object.modifiers:
                if mod.type == 'MIRROR':
                    row.prop(mod, "show_viewport", text="Hide Mirror" if mod.show_viewport else "Show Mirror")
                    row.operator("object.speedsculpt_apply_mirror", text="", icon='FILE_TICK')
                    row.operator("object.speedsculpt_remove_mirror", text = "", icon='X')
                    row.prop(prefs,"mirror_settings", text = "", icon='SETTINGS')
                    if prefs.mirror_settings:
                        row = col.row(align=True)
                        row.label(text="Axis")
                        row.prop(mod, "use_axis", index=0, text="X", toggle = True)
                        row.prop(mod, "use_axis", index=1, text="Y", toggle = True)
                        row.prop(mod, "use_axis", index=2, text="Z", toggle = True)

                        row = col.row(align=True)
                        row.label(text="Bisect")
                        row.prop(mod, "use_bisect_axis", index=0, text="X", toggle = True)
                        row.prop(mod, "use_bisect_axis", index=1, text="Y", toggle = True)
                        row.prop(mod, "use_bisect_axis", index=2, text="Z", toggle = True)

                        row = col.row(align=True)
                        row.label(text="Flip")
                        row.prop(mod, "use_bisect_flip_axis", index=0, text="X", toggle = True)
                        row.prop(mod, "use_bisect_flip_axis", index=1, text="Y", toggle = True)
                        row.prop(mod, "use_bisect_flip_axis", index=2, text="Z", toggle = True)

                        row = col.row(align=True)
                        row.label(text="Mirror Object")
                        row.prop(mod, "mirror_object", text="" )

                        row = col.row(align=True)
                        row.prop(mod, "use_clip", text = "Clipping")

                        row = col.row(align=True)
                        row.prop(mod, "use_mirror_merge", text = "Merge")
                        if mod.use_mirror_merge:
                            row = col.row(align=True)
                            row.prop(mod, "merge_threshold", text = "Merge Threshold")

                        row = col.row(align=True)
                        row.prop(mod, "bisect_threshold", text = "Bisect Distance")

        # PRIMITIVES
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        icon = icons.get("icon_primitives")
        row.operator("object.add_custom_primitives", text = "", icon_value=icon.icon_id).primitive = "sphere"
        row.prop(speedsculpt, "show_basic_primitives", text="PRIMITIVES", icon='TRIA_UP' if speedsculpt.show_basic_primitives else 'TRIA_RIGHT')
        
        if prefs.show_help:
            row.menu("SPEEDSCULPT_MT_help_primitives", text="", icon='HELP')
            
        # PRIMITIVES
        if speedsculpt.show_basic_primitives:
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_x = 3
            row.operator("object.add_custom_primitives", text = "", icon = 'MATSPHERE').primitive = "sphere"
            row.operator("object.add_custom_primitives",text="", icon ='MESH_CYLINDER').primitive = "cylinder"
            row.operator("object.add_custom_primitives",text="", icon ='MESH_CUBE').primitive = "cube"
            row.operator("object.add_custom_primitives",text="", icon ='MESH_CONE').primitive = "cone"
            row.operator("object.add_custom_primitives",text="", icon ='MESH_TORUS').primitive = "torus"

            # Metaballs
            row = col.row(align=True)
            row.scale_x = 3
            row.operator("object.add_custom_metaballs", text = "", icon = 'META_BALL').metaballs = "ball"
            row.operator("object.add_custom_metaballs",text="", icon ='META_CAPSULE').metaballs = "capsule"
            row.operator("object.add_custom_metaballs",text="", icon ='META_CUBE').metaballs = "cube"
            row.operator("object.add_custom_metaballs",text="", icon ='META_ELLIPSOID').metaballs = "hellipsoid"
            row.operator("object.add_custom_metaballs",text="", icon ='META_PLANE').metaballs = "plane"

            if any([obj for obj in context.selected_objects if context.active_object.type == 'META']) and context.active_object.type == 'META':
                    split = box.split()
                    col = split.column(align=True)
                    col.label(text="Metaballs Options:")
                    row = col.row(align=True)
                    row.prop(bpy.context.object.data, "resolution", text="Resolution")
                    row = col.row(align=True)
                    row.prop(bpy.context.object.data, "threshold", text="Threshold")
                    row = col.row(align=True)
                    row.prop(speedsculpt, "metaballs_pos_neg", expand=True)

                    if len([obj for obj in context.selected_objects if obj.type == 'META' and obj.mode == "EDIT"]) == 1:
                        col.prop(bpy.context.object.data.elements.active, "stiffness", text="Stiffness")
                        col.prop(bpy.context.object.data.elements.active, "hide", text="Hide")

        # LIBRARY
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        icon = icons.get("icon_library")
        row.prop(speedsculpt, "show_asset_lib", text="", icon_value=icon.icon_id)
        row.prop(speedsculpt, "show_asset_lib", text="ASSETS LIBRARY",
                 icon='TRIA_UP' if speedsculpt.show_asset_lib else 'TRIA_RIGHT')
        if prefs.show_help:
            row.menu("SPEEDSCULPT_MT_help_asset_library", text="", icon='HELP')
        if speedsculpt.show_asset_lib:
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = 1
            row.prop(speedsculpt, "ui_categories", text="")
            row = col.row(align=True)
            col = row.column()
            col.template_icon_view(wm, "speedsculpt_previews", show_labels=prefs.preview_show_labels,
                                   scale=prefs.preview_scale,
                                   scale_popup=prefs.preview_scale_popup)
            # col = row.column(align=True)
            # col.prop(speedsculpt, "snap_to_faces", text="", icon='SNAP_ON')
            split = box.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.2
            icon = icons.get("icon_import")
            row.operator("object.speedsculpt_add_assets_to_scene", text="Import Asset", icon_value=icon.icon_id)

        # GEOMESH
        Geomesh(self, context)

        # DRAW MESH
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        icon = icons.get("icon_draw_mesh")
        row.operator("object.speedsculpt_draw_remesh", text="", icon_value=icon.icon_id)
        # icon = icons.get("icon_blanck")
        row.prop(speedsculpt, "show_draw_mesh", text="DRAW MESH",
                 icon='TRIA_UP' if speedsculpt.show_draw_mesh else 'TRIA_RIGHT')
        # row.prop(speedsculpt, "show_draw_mesh", text="DRAW MESH", icon_value=icon.icon_id)
        if prefs.show_help:
            row.menu("SPEEDSCULPT_MT_help_draw_mesh", text="", icon='HELP')
        if speedsculpt.show_draw_mesh:
            if is_bsurface_activated():
                row = col.row(align=True)
                row.label(text='Placement')
                row = col.row(align=True)
                row.prop(speedsculpt, 'draw_remesh_placement', expand=True)
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.prop(speedsculpt, 'draw_remesh_size', text="Draw Size")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = 1.2
                icon = icons.get("icon_draw_mesh")
                row.operator("object.speedsculpt_draw_remesh", text="Draw Mesh", icon_value=icon.icon_id)
            else:
                row = col.row()
                row.scale_y = 1.3
                row.alert = True
                row.operator("object.speedsculpt_set_bsurface_info",text="Install or Active Bsurface", icon='ERROR')

        # DRAW SURFACE
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        icon = icons.get("icon_surface")
        row.operator("object.speedsculpt_draw_surface", text="", icon_value=icon.icon_id)
        row.prop(speedsculpt, "show_draw_surface", text="DRAW SURFACE",
                 icon='TRIA_UP' if speedsculpt.show_draw_surface else 'TRIA_RIGHT')
        if prefs.show_help:
            row.menu("SPEEDSCULPT_MT_help_draw_surface", text="", icon='HELP')
        if speedsculpt.show_draw_surface:

            if context.selected_objects and "Solidify" in obj.modifiers:
                # Solidify
                if solidify:
                    row = col.row(align=True)
                    row.scale_y = 1
                    row = col.row(align=True)
                    solidify_mod = context.object.modifiers.get("Solidify")
                    row.prop(solidify_mod, "thickness", text="Thickness")
                    # row.prop(solidify_mod, "show_viewport", text="")
                    row = col.row(align=True)
                    col.prop(solidify_mod, "offset", text="Offset")

                if shrinkwrap:
                    row = col.row(align=True)
                    shrinkwrap_mod = context.object.modifiers.get("Shrinkwrap")
                    if shrinkwrap_mod.show_viewport:
                        row.prop(shrinkwrap_mod, "show_viewport",
                                 text="Hide Shrinkwrap")
                    else:
                        row.prop(shrinkwrap_mod, "show_viewport",
                                 text="Show Shrinkwrap")
                    row.operator("object.remove_shrinkwrap", text="", icon='X')

                # Bevel
                if not bevel:
                    row = col.row(align=True)
                    icon = icons.get("icon_bevel")
                    row.operator("object.add_gp_bevel", text="Add Bevel", icon_value=icon.icon_id)

                else:
                    row = col.row(align=True)
                    bevel_mod = context.object.modifiers.get("Bevel")
                    if bevel_mod.show_viewport:
                        row.prop(bevel_mod, "show_viewport", text="Hide Bevel")
                    else:
                        row.prop(bevel_mod, "show_viewport", text="Show Bevel")

                    row.operator("object.remove_bevel", text="", icon='X')
                    if bevel_mod.show_viewport:
                        row = col.row(align=True)
                        row.prop(bevel_mod, "width", text="Bevel Offset")
                        row = col.row(align=True)
                        row.prop(bevel_mod, "angle_limit", text="Bevel Angle Limit")
                        row = col.row(align=True)
                        row.prop(bevel_mod, "segments", text="Bevel Segments")

            else:
                if is_bsurface_activated():
                    
                    row = col.row(align=True)
                    row.label(text='Placement')
                    row = col.row(align=True)
                    row.prop(speedsculpt, 'draw_surface_placement', expand=True)
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.prop(speedsculpt, 'draw_surface_thickness', text='Thickness')
                    row = col.row(align=True)
                    row.prop(speedsculpt, 'draw_surface_offset', text='Offset')

                    if not prefs.smooth_mesh and not prefs.update_remesh:
                        row = col.row(align=True)
                        row.prop(context.scene.bsurfaces, "SURFSK_edges_U")
                        row = col.row(align=True)
                        row.prop(context.scene.bsurfaces, "SURFSK_edges_V")

                    row = col.row(align=True)
                    row.prop(speedsculpt, 'draw_surface_update_remesh', text="Remesh the Object")

                    row = col.row(align=True)
                    row.scale_y = 1.2
                    icon = icons.get("icon_surface")
                    row.operator("object.speedsculpt_draw_surface", text="DRAW SURFACE", icon_value=icon.icon_id)
                else:
                    row = col.row()
                    row.scale_y = 1.3
                    row.alert = True
                    row.operator("object.speedsculpt_set_bsurface_info",text="Install or Active Bsurface", icon='ERROR')

        # CUTTER
        if prefs.dyntopo_or_remesh == 'remesh':
            box = layout.box()
            split = box.split()
            col = split.column(align=True)
            row = col.row(align=True)
            icon = icons.get("icon_cutter")
            row.prop(speedsculpt, "show_cutter", text="",icon_value=icon.icon_id)
            row.prop(speedsculpt, "show_cutter", text="CUTTER TOOLS",
                     icon='TRIA_UP' if speedsculpt.show_cutter else 'TRIA_RIGHT')

            if prefs.show_help:
                row.menu("SPEEDSCULPT_MT_help_create_cut_tools", text="", icon='HELP')

            if speedsculpt.show_cutter:
                row = col.row()
                row.separator()
                row = col.row()
                row.scale_y = 1

                if context.selected_objects and context.object.visible_get(view_layer=context.view_layer):
                    row.prop(speedsculpt, 'cutter_create_boolean', expand=True)
                # else:
                #     speedsculpt.cutter_create_boolean = 'create'
                #     row.prop_enum(speedsculpt, 'cutter_create_boolean', 'create')

                row = col.row()
                row.scale_y = 1
                row.prop(speedsculpt, 'cutter_view_surface', expand=True)
                if context.selected_objects and context.object.visible_get(view_layer=context.view_layer):
                    if speedsculpt.cutter_create_boolean == 'boolean':
                        row = col.row()
                        row.scale_y = 1
                        row.prop(speedsculpt, 'boolean_operation', expand=True)

                        if speedsculpt.boolean_operation == 'union':
                            row = col.row()
                            row.scale_y = 1
                            row.prop(speedsculpt, 'cutter_creation_width', text="Mesh Width")

                elif speedsculpt.cutter_create_boolean == 'create':
                    row = col.row()
                    row.scale_y = 1
                    row.prop(speedsculpt, 'cutter_creation_width', text="Mesh Width")
                row = col.row()
                row.separator()
                row = col.row(align=True)
                row.scale_y = 1
                row.operator("object.speedsculpt_cutter_primitives", text=" ", icon='MESH_PLANE').launch_cutter_primitives = "rectangle"
                row.operator("object.speedsculpt_cutter_primitives", text=" ", icon='MESH_CIRCLE').launch_cutter_primitives = "circle"
                row.operator("object.speedsculpt_cutter_primitives", text=" ", icon='HANDLE_VECTOR').launch_cutter_primitives = "vertex"
                row.operator("object.speedsculpt_cutter_primitives", text=" ", icon='MOD_CURVE').launch_cutter_primitives = "curve"

        # Skin
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)

        icon = icons.get("icon_draw_skin")
        row.operator("object.speedsculpt_draw_skin", text="DRAW SKIN", icon_value=icon.icon_id)

        icon = icons.get("icon_skin")
        row.operator("object.add_skin",text="ADD SKIN", icon_value=icon.icon_id)

        if prefs.show_help :
            row.menu("SPEEDSCULPT_MT_help_skin",text="", icon='HELP')

        if context.object is not None and context.object.visible_get(view_layer=context.view_layer):
            skin = False
            bevel = False
            subsurf = False
            armature = False
            for mod in context.active_object.modifiers:
                if mod.type == "SKIN":
                    skin = True
                if mod.type == 'BEVEL':
                    bevel = True
                if mod.type == 'SUBSURF':
                    subsurf = True
                if mod.type == 'ARMATURE':
                    armature = True

            # SKIN
            if skin and context.object.mode == "EDIT":
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.operator("object.skin_root_mark", text='Mark Root', icon='PIVOT_CURSOR')
                row = col.row(align=True)
                row.operator("object.skin_loose_mark_clear", text='Mark Loose').action='MARK'
                row.operator("object.skin_loose_mark_clear", text='Clear Loose').action='CLEAR'
                row = col.row(align=True)
                row.operator("object.skin_radii_equalize", text="Equalize Radii")
                for mod in context.active_object.modifiers:
                    if mod.type == 'SKIN':
                        row = col.row(align=True)
                        row.prop(mod, "branch_smoothing", text="Branch Smoothing")
                    if mod.type == 'SUBSURF' and "Subdivision" in obj.modifiers:
                        row = col.row(align=True)
                        row.prop(mod, "show_only_control_edges", text="Optimal Display", toggle=True)
            elif skin:
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                if not armature:
                    icon = icons.get("icon_pose")
                    row.operator("object.speedsculpt_skin_armature", text='Armature from skin', icon_value=icon.icon_id)
                else:
                    for mod in context.object.modifiers:
                        if mod.type == 'ARMATURE':
                            row.prop(mod, "show_viewport", text="Hide Armature" if mod.show_viewport else "Show Armature")
                            row.operator("object.speedsculpt_apply_skin_armature", text='', icon='FILE_TICK')
                            row.operator("object.speedsculpt_remove_skin_armature", text='', icon='X')


            #Bevel
            if skin and bevel:
                for mod in context.object.modifiers:
                    if mod.type == 'BEVEL':
                        split = box.split()
                        col = split.column(align=True)
                        row = col.row(align=True)
                        row.prop(mod, "show_viewport", text="Hide Bevel" if mod.show_viewport else "Show Bevel")
                        row.operator("object.remove_bevel", text="", icon='X')
                        row = col.row(align=True)
                        row.prop(context.active_object.modifiers[mod.name], "width", text="Bevel Width")
                        row = col.row(align=True)
                        row.prop(context.active_object.modifiers[mod.name], "angle_limit", text="Bevel Angle")
            elif skin:
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                icon = icons.get("icon_bevel")
                row.operator("object.add_gp_bevel", text="Add Bevel", icon_value=icon.icon_id)

            #Smooth Skin
            if skin and  subsurf and "Smooth_skin" in obj.modifiers:
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.prop(context.active_object.modifiers["Smooth_skin"], "show_viewport", text="Hide Smooth" if context.active_object.modifiers["Smooth_skin"].show_viewport else "Show Smooth")
                row.operator("object.remove_smooth_skin", text="", icon='X')
                row = col.row(align=True)
                row.prop(context.active_object.modifiers["Smooth_skin"], "levels", text="Smooth Level")
            elif skin:
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                icon = icons.get("icon_subsurf")
                row.operator("object.add_smooth_skin", text="Add Smooth", icon_value=icon.icon_id)

        box = layout.box()
        split = box.split()
        col = split.column(align=True)

        row = col.row(align=True)
        icon = icons.get("icon_lathe")
        row.operator("object.create_lathe", text="LATHE", icon_value=icon.icon_id)
        icon = icons.get("icon_curve")
        row.operator("object.speedsculpt_create_curve", text="CURVE", icon_value=icon.icon_id)


        if prefs.show_help :
            row.menu("SPEEDSCULPT_MT_help_curves",text="", icon='HELP')

        if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer):
            screw = False
            for mod in bpy.context.active_object.modifiers:
                if mod.type == "SCREW":
                    screw = True


            if not screw :
                if len(context.selected_objects) == 1:
                    obj1 = context.active_object
                    if obj1.type == 'CURVE' :

                        row = col.row(align=True)
                        row.prop(context.object.data,"resolution_u", text="Resolution")
                        row = col.row(align=True)
                        icon = icons.get("icon_draw_skin")
                        row.operator("object.convert_curve_to_skin", text="CONVERT TO SKIN", icon_value=icon.icon_id)


                if len(context.selected_objects) >= 2:
                    obj1 = context.active_object

                # Bbox
                if len(context.selected_objects) == 1:
                    obj1 = context.active_object
                    if obj1.type == 'CURVE' :
                        box = layout.box()
                        split = box.split()
                        col = split.column(align=True)

                        if context.object.data.bevel_depth == 0 :
                            row = col.row(align=True)
                            row.prop(speedsculpt, "bbox_bevel", text="Bevel")
                            row = col.row(align=True)
                            row.prop(speedsculpt, "bbox_offset", text="Offset")
                            row = col.row(align=True)
                            row.prop(speedsculpt, "bbox_depth", text="Depth")

                        elif context.object.data.bevel_depth > 0 :
                            row = col.row(align=True)
                            row.prop(context.object.data,"bevel_depth", text="Bevel")
                            row = col.row(align=True)
                            row.prop(context.object.data,"offset", text="Offset")
                            row = col.row(align=True)
                            row.prop(context.object.data,"extrude", text="Depth")

                        else:
                            pass
                        row = col.row()
                        row.prop(speedsculpt, "bbox_convert", text="Stay in curve Mode")
                        row = col.row()
                        row.prop(speedsculpt, "smooth_result", text="Smooth the mesh")
                        row = col.row()
                        row.operator("object.bbox", text="BBOX", icon='MOD_DYNAMICPAINT')
            else :
                for mod in bpy.context.active_object.modifiers:
                    if mod.type == "SCREW":
                        row = col.row(align=True)
                        row.scale_x=0.5
                        row.prop(context.active_object.modifiers[mod.name], "axis", text="Axis")
                        row = col.row(align=True)
                        row.prop(context.active_object.modifiers[mod.name], "steps", text="Steps")
                        row = col.row(align=True)
                        row.prop(context.active_object.modifiers[mod.name], "use_normal_flip", text="Flip Normals")


                if len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'CURVE']) == 1:
                    row = col.row(align=True)
                    icon = icons.get("icon_empty")
                    row.operator("object.speedsculpt_create_empty", text="Add empty", icon_value=icon.icon_id)

        # Envelope
        box = layout.box()
        split = box.split()
        box = split.column(align=True)

        row.scale_y = 1
        row = box.row(align=True)
        icon = icons.get("icon_enveloppe")
        row.operator("object.create_envelope", text="ENVELOPE", icon_value=icon.icon_id)
        if prefs.show_help:
            row.menu("SPEEDSCULPT_MT_help_envelope", text="", icon='HELP')

        if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
            obj = context.active_object
            if obj.type == 'ARMATURE' and  obj.mode == "EDIT":
                row = box.row(align=True)
                row.separator()
                row = box.row(align=True)
                row.operator("object.enveloppe_symmetrize", text="Symmetrize Bones", icon='MOD_MIRROR')
                arm = context.active_object.data
                row = box.row(align=True)
                row.prop(arm, "use_mirror_x")

def Symmetrize(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    toolsettings = context.tool_settings
    sculpt = toolsettings.sculpt
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    # Symmetrize
    if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
        if len([obj for obj in context.selected_objects if obj.type == 'MESH' if context.object.mode in ["OBJECT","SCULPT"] ]) >= 1:

            row = layout.row(align=True)

            icon = icons.get("icon_symmetrize")
            row.operator("object.symmetrize", text = "", icon_value=icon.icon_id).symmetrize_axis = "positive_x"
            row.prop(speedsculpt, "show_symmetrize", text="SYMMETRIZE",
                    icon='TRIA_UP' if speedsculpt.show_symmetrize else 'TRIA_RIGHT')

            if prefs.show_help :
                row.menu("SPEEDSCULPT_MT_help_symmetrize",text="", icon='HELP')
            if speedsculpt.show_symmetrize:
                box = layout.box()
                split = box.split()
                box = split.column(align=True)
                row = box.row(align=True)
                icon = icons.get("icon_sym_plus_x")
                row.operator("object.symmetrize", text = "+X to -X", icon_value=icon.icon_id).symmetrize_axis = "positive_x"
                icon = icons.get("icon_sym_minus_x")
                row.operator("object.symmetrize", text = "-X to +X", icon_value=icon.icon_id).symmetrize_axis = "negative_x"
                row = box.row(align=True)
                icon = icons.get("icon_sym_plus_y")
                row.operator("object.symmetrize", text = "+Y to -Y", icon_value=icon.icon_id).symmetrize_axis = "positive_y"
                icon = icons.get("icon_sym_minus_y")
                row.operator("object.symmetrize", text = "-Y to +Y", icon_value=icon.icon_id).symmetrize_axis = "negative_y"
                row = box.row(align=True)
                icon = icons.get("icon_sym_plus_z")
                row.operator("object.symmetrize", text = "+Z to -Z", icon_value=icon.icon_id).symmetrize_axis = "positive_z"
                icon = icons.get("icon_sym_minus_z")
                row.operator("object.symmetrize", text = "-Z to +Z", icon_value=icon.icon_id).symmetrize_axis = "negative_z"

def Lattice(self, context):
    """ Sub panel for the adding assets """
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()
    layout = self.layout

    if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
        obj = context.active_object

        if len([obj for obj in context.selected_objects if obj.type in ['MESH', 'LATTICE'] ]) >= 1:
            row = layout.row(align=True)
            icon = icons.get("icon_lattice")
            row.operator("object.add_lattice",text="", icon_value=icon.icon_id)
            row.prop(speedsculpt, "show_lattice", text="LATTICE",
                    icon='TRIA_UP' if speedsculpt.show_lattice else 'TRIA_RIGHT')
            if prefs.show_help :
                row.menu("SPEEDSCULPT_MT_help_lattice",text="", icon='HELP')
            if speedsculpt.show_lattice:
                if obj.type == 'MESH' :
                    lattice = False
                    for mod in obj.modifiers:
                        if mod.type == "LATTICE":
                            lattice = True

                    if not lattice:
                        box = layout.box()
                        split = box.split()
                        col = split.column(align=True)
                        row = col.row(align=True)
                        row.prop(speedsculpt, "copy_orientation", text="Don't Copy Orientation")
                        row = col.row(align=True)
                        row.prop(speedsculpt, "lattice_u", text="U:")
                        row = col.row(align=True)
                        row.prop(speedsculpt, "lattice_v", text="V:")
                        row = col.row(align=True)
                        row.prop(speedsculpt, "lattice_w", text="W:")
                        if context.object.mode == "SCULPT":
                            row = col.row(align=True)
                            row.separator()
                            row = col.row(align=True)
                            row.scale_y = 1.2
                            icon = icons.get("icon_mask")
                            row.operator("object.add_lattice", text="ADD LATTICE FROM MASK", icon_value=icon.icon_id)
                        else :
                            row = col.row(align=True)
                            row.separator()
                            row = col.row(align=True)
                            row.scale_y = 1.2
                            icon = icons.get("icon_lattice")
                            row.operator("object.add_lattice",text="ADD LATTICE", icon_value=icon.icon_id)

                    else :
                        box = layout.box()
                        split = box.split()
                        # box = split.column(align=True)
                        col = split.column(align=True)
                        row = col.row(align=True)
                        row.scale_y = 1.2
                        icon = icons.get("icon_lattice")
                        row.operator("object.apply_lattice_modifier", text="APPLY LATTICE", icon_value=icon.icon_id)
                        row.prop(speedsculpt, "hide_lattice", text="", icon='RESTRICT_VIEW_OFF' if speedsculpt.hide_lattice else 'RESTRICT_VIEW_ON')
                        row.operator("object.remove_lattice_modifier", text="", icon='X')


                        if context.object.mode == "OBJECT":
                            if context.object.vertex_groups:
                                for vgroup in context.object.vertex_groups:
                                    if vgroup.name.startswith("S"):
                                        if len(context.selected_objects) == 1:
                                            row = col.row(align=True)
                                            row.separator()
                                            row = col.row(align=True)
                                            icon = icons.get("icon_mask")
                                            row.operator("object.lattice_add_mask", text="Edit Mask", icon_value=icon.icon_id)
                                            row = col.row(align=True)
                                            row.operator("object.lattice_smooth_mask", text="Smooth Mask", icon='MOD_MASK')

                            else :
                                if len(context.selected_objects) == 1:
                                    row = col.row(align=True)
                                    row.scale_y = 1.2
                                    icon = icons.get("icon_mask")
                                    row.operator("object.lattice_add_mask", text="Add Mask", icon_value=icon.icon_id)

                        if context.object.mode == "SCULPT":

                                row = col.row(align=True)
                                row.scale_y = 1.2
                                icon = icons.get("icon_valid")
                                row.operator("object.valid_lattice_mask", text="Valid Mask", icon_value=icon.icon_id)


                elif len([obj for obj in context.selected_objects]) >= 2:
                    box = layout.box()
                    split = box.split()
                    box = split.column(align=True)
                    row.scale_y = 1.2
                    icon = icons.get("icon_lattice")
                    box.operator("object.connect_lattice", text="Connect To Lattice", icon_value=icon.icon_id)


                elif len([obj for obj in context.selected_objects if obj.type == 'LATTICE' ]) == 1:
                    box = layout.box()
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    row.scale_y = 1.2
                    icon = icons.get("icon_lattice")
                    row.operator("object.apply_lattice_objects", text="Apply Lattice", icon_value=icon.icon_id)
                    row.operator("object.remove_lattice_objects", text="", icon='X')
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.prop(context.object.data, "points_u")
                    row = col.row(align=True)
                    row.prop(context.object.data, "points_v")
                    row = col.row(align=True)
                    row.prop(context.object.data, "points_w")
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.prop(speedsculpt, "lattice_interp", text="")

def Remesh(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    # Remesh
    if context.object is not None and context.object.visible_get(view_layer=context.view_layer):
        obj = context.active_object

        if len([obj for obj in context.selected_objects if obj.type == 'MESH' if context.object.mode in ["OBJECT","SCULPT"]]) >= 1:
            row = layout.row(align=True)
            icon = icons.get("icon_remesh")
            row.prop(speedsculpt, "show_remesh", text="", icon_value=icon.icon_id)
            row.prop(speedsculpt, "show_remesh", text="REMESH/DECIMATE",
                    icon='TRIA_UP' if speedsculpt.show_remesh else 'TRIA_RIGHT')

            if prefs.show_help :
                row.menu("SPEEDSCULPT_MT_help_remesh",text="", icon='HELP')
            if speedsculpt.show_remesh:
                # Remesh
                remesh = False
                smooth = False
                for mod in context.active_object.modifiers:
                    if mod.type == "REMESH":
                        remesh = True
                    if mod.type == "SMOOTH":
                        smooth = True
                if not remesh :
                    if context.object.mode == "OBJECT":
                        box = layout.box()
                        split = box.split()
                        box = split.column(align=True)
                        icon = icons.get("icon_remesh")
                        box.operator("object.remesh", text="Remesh", icon_value=icon.icon_id)

                if remesh and smooth :
                    box = layout.box()
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    icon = icons.get("icon_valid")
                    row.operator("object.apply_remesh_smooth", text="Apply Remesh", icon_value=icon.icon_id)
                    row.prop(speedsculpt, "hide_remesh_smooth", text="", icon='RESTRICT_VIEW_OFF' if speedsculpt.hide_remesh_smooth else 'RESTRICT_VIEW_ON')
                    row.operator("object.remove_remesh_smooth", text="", icon='X')

                    if remesh:
                        row = col.row(align=True)
                        prefs = get_addon_preferences()
                        row.prop(prefs, "remesh_value", text="Remesh Depth:")

                    if smooth:
                        row = col.row(align=True)
                        row.prop(speedsculpt, "remesh_smooth_repeat", text="Smooth Repeat:")


                # Decimate
                decimate = False
                for mod in context.active_object.modifiers:
                    if mod.type == "DECIMATE":
                        decimate = True

                if not decimate :
                    if context.object.mode == "SCULPT":
                        box = layout.box()
                        split = box.split()
                        box = split.column(align=True)
                        icon = icons.get("icon_mask")
                        box.operator("object.decimate_mask", text="Mask Decimate", icon_value=icon.icon_id)

                    elif context.object.mode == "OBJECT":
                        box = layout.box()
                        split = box.split()
                        box = split.column(align=True)
                        icon = icons.get("icon_decimate")
                        box.operator("object.decimate", text="Decimate", icon_value=icon.icon_id)

                if decimate:
                    box = layout.box()
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    icon = icons.get("icon_valid")
                    row.operator("object.apply_decimate", text="Apply Decimate", icon_value=icon.icon_id)
                    row.prop(speedsculpt, "hide_decimate", text="",
                            icon='RESTRICT_VIEW_OFF' if speedsculpt.hide_decimate else 'RESTRICT_VIEW_ON')
                    row.operator("object.remove_decimate", text="", icon='X')

                    row = col.row(align=True)
                    row.prop(speedsculpt, "decimate_ratio", text="Ratio:")
                    row = col.row(align=True)

                    row.prop(context.active_object.modifiers["Decimate"], "face_count", text="Face Count:")

                    if len([obj for obj in context.selected_objects if obj.type == 'MESH' if context.object.mode == "OBJECT"]) == 1:
                        row = col.row(align=True)
                        if not context.object.modifiers["Decimate"].vertex_group :
                            icon = icons.get("icon_mask")
                            row.operator("object.add_mask", text="Add Mask", icon_value=icon.icon_id)

                        else :
                            row.operator("object.edit_decimate_mask", text="Edit Mask", icon='MOD_MASK')
                            row.prop(bpy.context.active_object.modifiers["Decimate"],"invert_vertex_group", text="", icon='ARROW_LEFTRIGHT')
                            row.operator("object.remove_mask", text="", icon='X')

                    elif context.object.mode == "SCULPT":
                        row = col.row(align=True)
                        icon = icons.get("icon_valid")
                        row.operator("object.valid_decimate_mask", text="Valid Mask", icon_value=icon.icon_id)


                box = layout.box()
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                icon = icons.get("icon_quadriflow")
                row.operator("object.quadriflow_remesh", text="QuadriFlow Remesh", icon_value=icon.icon_id)

def ExtractMask(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    toolsettings = context.tool_settings
    sculpt = toolsettings.sculpt
    obj = bpy.context.active_object
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    # Extract Mask
    if context.object is not None and context.object.visible_get(view_layer=context.view_layer):
        obj = context.active_object
        
        if len([obj for obj in context.selected_objects if obj.type == 'MESH' if context.object.mode == "SCULPT"]) == 1:

            row = layout.row(align=True)
            icon = icons.get("icon_mask")
            row.prop(speedsculpt, "show_extract", text="", icon_value=icon.icon_id)
            row.prop(speedsculpt, "show_extract", text="EXTRACT OPERATIONS",
                    icon='TRIA_UP' if speedsculpt.show_extract else 'TRIA_RIGHT')

            if prefs.show_help :
                row.menu("SPEEDSCULPT_MT_help_extract_mask",text="", icon='HELP')
            
            if speedsculpt.show_extract:
                if bpy.context.object.mode == "SCULPT":
                    if speedsculpt.face_set_or_mask_operation == 'FACE_SET':
                        self.extract = "extract_face_set"
                        self.cut = "cut_face_set"
                        self.slice = "slice_face_set"
                        self.icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('brush.sculpt.draw_face_sets')
                        self.setting_name = "Face Sets Settings"
                    elif speedsculpt.face_set_or_mask_operation == 'MASK':
                        self.extract = "extract_mask"
                        self.cut = "cut_mask"
                        self.slice = "slice_mask"
                        self.icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('brush.sculpt.mask')
                        self.setting_name = "Mask Settings"

                    box = layout.box()
                    split = box.split()
                    box = split.column(align=True)
                    row = box.row(align=True)
                    row.scale_y = 1.2
                    row.prop(speedsculpt, "face_set_or_mask_operation", expand=True)
                    
                    # SETTINGS
                    box = layout.box()
                    row = box.row(align=True)
                    row.scale_y = 1.2
                    row.prop(prefs, "show_face_set_settings", text=self.setting_name, icon_value=self.icon_id)
                    if prefs.show_face_set_settings:
                        split = box.split()
                        col = split.column(align=True)
                        icon = icons.get("icon_solidify")
                        col.prop(speedsculpt, "add_solidify", text="Add Solidify", icon_value=icon.icon_id)
                        solidify_mod = context.object.modifiers.get("Solidify")

                        if solidify_mod:
                            col.prop(solidify_mod, "thickness", text="Thickness")
                            col.prop(solidify_mod, "offset", text="Offset")
                        else:
                            if speedsculpt.add_solidify :
                                col.prop(speedsculpt, "solidify_thickness", text="Thickness")
                                col.prop(speedsculpt, "solidify_offset", text="Offset")

                        col.separator()

                        icon = icons.get("icon_u")
                        if prefs.dyntopo_or_remesh == "remesh":
                            if speedsculpt.add_solidify:
                                col.prop(prefs, "update_remesh", text="Apply Solidify & Remesh", icon_value=icon.icon_id)
                            else:
                                col.prop(prefs, "update_remesh", text="Remesh", icon_value=icon.icon_id)

                        elif prefs.dyntopo_or_remesh == "dyntopo":
                            if speedsculpt.add_solidify:
                                col.prop(prefs, 'update_detail_flood_fill', text="Apply Solidify & Dyntopo", icon_value=icon.icon_id)
                            else:
                                col.prop(prefs, 'update_detail_flood_fill', text="Update Dyntopo", icon_value=icon.icon_id)
                        

                        col.separator()
                        col.prop(speedsculpt, "comeback_in_sculpt_mode", text="Go To Sculpt", icon='SCULPTMODE_HLT')
                        

                    box = layout.box()
                    split = box.split()
                    box = split.column(align=True)
                    row = box.row(align=True)
                    row.scale_y = 1.2
                    row.operator("object.speedsculpt_extract_operation", text="Extract").face_set_mask_action = self.extract
                    row.operator("object.speedsculpt_extract_operation", text="Cut ").face_set_mask_action = self.cut

                    # INFO FACE SET
                    if speedsculpt.face_set_or_mask_operation == 'FACE_SET':
                        row = box.row(align=True)
                        row.label(text="Note: Isolate the Face Set", icon='INFO')
                        row = box.row(align=True)
                        row.label(text="         with Shift+H to make it work")

                elif bpy.context.object.mode == "OBJECT":

                    solidify = False
                    for mod in context.active_object.modifiers:
                        if mod.type == "SOLIDIFY":
                            solidify = True

                        if solidify:
                            box = layout.box()
                            split = box.split()
                            box = split.column(align=True)
                            box.operator("object.speedsculpt_clean_boundary", text="Clean Boundary Vertices", icon='MOD_OUTLINE')

                            box = layout.box()
                            split = box.split()
                            col = split.column(align=True)
                            col.label(text="Solidify Settings")
                            col.prop(mod, "thickness", text="Thickness")
                            col.prop(mod, "offset", text="Offset")
                            col.prop(mod, "use_rim_only", text="Only Rim")

                        else:
                            box = layout.box()
                            split = box.split()
                            box = split.column(align=True)
                            row = box.row(align=True)
                            row.scale_y=1.5
                            icon = icons.get("icon_mask")
                            row.operator("object.add_extract_mask", text="Add Mask", icon_value=icon.icon_id)

def QuickPose(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    obj = bpy.context.active_object
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    if len([obj for obj in context.selected_objects if obj.type == 'MESH']) == 1:
        row = layout.row(align=True)
        icon = icons.get("icon_quick_pose")
        row.prop(speedsculpt, "show_quickpose", text="", icon_value=icon.icon_id)

        row.prop(speedsculpt, "show_quickpose", text="QUICK POSE",
                 icon='TRIA_UP' if speedsculpt.show_quickpose else 'TRIA_RIGHT')

        if prefs.show_help :
            row.menu("SPEEDSCULPT_MT_help_quickpose",text="", icon='HELP')
        if speedsculpt.show_quickpose:
            # Armature
            armature = False
            for mod in bpy.context.active_object.modifiers:
                if mod.type == "ARMATURE":
                    armature = True

            if not armature :
                if bpy.context.object.mode == "SCULPT":
                    box = layout.box()
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    icon = icons.get("icon_mask")
                    row.operator("object.quick_pose_add_mask", text="Add Mask", icon_value=icon.icon_id)
                    icon = icons.get("icon_bones")
                    box.operator("object.quick_pose_create_bones", text="Create Bones", icon_value=icon.icon_id)

                elif bpy.context.object.mode == "OBJECT":
                    box = layout.box()
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row()
                    row.prop(speedsculpt, "use_mask", text="Use Mask")
                    row = col.row()
                    if speedsculpt.use_mask:
                        icon = icons.get("icon_mask")
                        row.operator("object.quick_pose_add_mask", text="Add Mask", icon_value=icon.icon_id)
                    else :
                        icon = icons.get("icon_bones")
                        box.operator("object.quick_pose_create_bones", text="Create Bones", icon_value=icon.icon_id)

                elif bpy.context.object.mode == 'EDIT':

                    bs_vertex = True
                    for obj in bpy.context.selected_objects:
                        if obj.name != "BS_Vertex" :
                            bs_vertex = False
                            break
                    if bs_vertex :
                        box = layout.box()
                        split = box.split()
                        col = split.column(align=True)
                        row = col.row()
                        icon = icons.get("icon_pose")
                        row.operator("object.quick_pose_convert_bones", text="Pose", icon_value=icon.icon_id)



            if armature:

                if bpy.context.object.mode == "OBJECT":
                    box = layout.box()
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    if not "Armature" in obj.modifiers:
                        if speedsculpt.use_mask:
                            icon = icons.get("icon_mask")
                            row.operator("object.quick_pose_add_mask", text="Add Mask", icon_value=icon.icon_id)
                        else :
                            icon = icons.get("icon_bones")
                            row.operator("object.quick_pose_create_bones", text="Create Bones",  icon_value=icon.icon_id)

                    else :
                        row.prop(bpy.context.active_object.modifiers["Armature"], "show_viewport", text="Hide Armature")
                        icon = icons.get("icon_valid")
                        row.operator("object.apply_quick_pose_modifier", text="", icon_value=icon.icon_id)
                        row.operator("object.remove_quick_pose_modifier", text="", icon='X')


                        if speedsculpt.use_mask:
                            row = col.row(align=True)
                            icon = icons.get("icon_mask")
                            row.operator("object.edit_quick_pose_mask", text="Edit Mask", icon_value=icon.icon_id)
                            if bpy.app.version < (4, 3, 0):
                                row = col.row(align=True)
                                row.operator("object.quick_pose_smooth_mask", text="Smooth Mask", icon='BRUSH_SMOOTH')
                            else:
                                row = col.row(align=True)
                                row.operator("object.quick_pose_smooth_mask", text="Smooth Mask", icon='MOD_MASK')

                elif bpy.context.object.mode == "SCULPT":
                    box = layout.box()
                    split = box.split()
                    row = split.row(align=True)
                    icon = icons.get("icon_valid")
                    row.operator("object.valid_quick_pose_mask", text="Valid Mask", icon_value=icon.icon_id)

def Muscles(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    

    # Check for solidify
    self.solidify = False
    self.has_muscles_prop = False

    if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
        obj = context.active_object

        if obj.type == 'MESH':
            for mod in obj.modifiers:
                if mod.type == "SOLIDIFY":
                    self.solidify = True

            if obj.get("speedsculpt_muscles"):
                self.has_muscles_prop = True


            if len([obj for obj in context.selected_objects if obj.type == 'MESH']) >= 1:

                if self.has_muscles_prop and self.solidify :

                    row = layout.row(align=True)
                    icon = icons.get("icon_muscles")
                    row.prop(speedsculpt, "show_muscles", text="", icon_value=icon.icon_id)
                    row.prop(speedsculpt, "show_muscles", text="MUSCLES",
                            icon='TRIA_UP' if speedsculpt.show_muscles else 'TRIA_RIGHT')
                    if prefs.show_help :
                        row.menu("SPEEDSCULPT_MT_help_muscles",text="", icon='HELP')
                    if speedsculpt.show_muscles:
                        box = layout.box()
                        split = box.split(align=True)
                        col = split.column(align=True)
                        row = col.row()
                        row.prop(speedsculpt, "hide_all_modifiers_prop", text='Show/Hide Modifiers', icon='MODIFIER', expand=True)
                        col.prop(speedsculpt, "edit_muscles_tickness", text="Thickness")
                        col.prop(speedsculpt, "edit_muscles_offset", text="Offset")
                        col.prop(speedsculpt, "edit_muscles_factor", text="Factor")

                        if obj.mode == 'EDIT':
                            row = col.row(align=True)
                            row.label(text='Vertex Groups')
                            col.prop(context.tool_settings, "vertex_group_weight", text="Weight")
                            row = col.row(align=True)
                            row.operator("object.vertex_group_assign", text="Assign")
                            row.operator("object.vertex_group_remove_from", text="Remove")
                            row = col.row(align=True)
                            row.operator("object.vertex_group_select", text="Select")
                            row.operator("object.vertex_group_deselect", text="Deselect")

def Speedsculpt_Shading(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    WM = context.window_manager
    act_obj = context.active_object
    prefs = get_addon_preferences()
    prefs.show_help = prefs.show_help
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    overlay = context.space_data.overlay
    shading = context.space_data.shading
    toolsettings = context.tool_settings
    view = context.space_data

    # if len([obj for obj in context.selected_objects if context.object is not None if obj.type in ['MESH','CURVE'] if
    #         bpy.context.object.mode in ["OBJECT", "SCULPT"]]) >= 1:


    row = layout.row(align=True)
    if len(context.visible_objects) >= 2:
        if context.selected_objects and context.object.type == 'MESH':
            icon = icons.get("icon_shading")
            row.operator("object.speedsculpt_solo", text="", icon_value=icon.icon_id)
    row.prop(speedsculpt, "shading_icons", expand=True)
    row.prop(overlay, "show_wireframes", text="", icon='SHADING_WIRE')
    row.prop(speedsculpt, "show_shading", text="SHADING",
             icon='TRIA_UP' if speedsculpt.show_shading else 'TRIA_RIGHT')
    if prefs.show_help:
        row.menu("SPEEDSCULPT_MT_help_shading", text="", icon='HELP')

    if speedsculpt.show_shading:
        box = layout.box()

        # Solo
        if len(context.visible_objects)>=2:
            split = box.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.2
            row.scale_x = 1
            icon = icons.get("icon_shading")
            row.operator("object.speedsculpt_solo", text="Solo", icon_value=icon.icon_id)

            row.scale_x = 0.5
            row.prop(prefs, "sc_solo_color", text="")

        # studio / matcap selection
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        # row.prop(view.shading, "light", expand=True)
        row.prop(speedsculpt, "shading", expand=True)
        if view.shading.light in ["STUDIO", "MATCAP"]:
            row = col.row(align=True)
            row.template_icon_view(view.shading, "studio_light", show_labels=True, scale=4, scale_popup=3)
        if view.shading.light == "STUDIO":
            row = col.row(align=True)
            row.prop(shading, "use_world_space_lighting", text="", icon='WORLD')
            row.prop(shading, "studiolight_rotate_z", text="Rotation")

        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.grid_flow(columns=3, align=True).prop(view.shading, "color_type", expand=True)
        if shading.light == 'FLAT':
            row = col.row(align=True)
            row.prop(shading, 'single_color', text="")

        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.prop(view.shading, "background_type", expand=True)
        if shading.background_type == 'VIEWPORT':
            row = col.row(align=True)
            row.prop(shading, 'background_color', text="")
        
        split = box.split()
        col = split.column(align=True)
        col.prop(overlay, "show_wireframes", text="Overlay Wireframe", icon='SHADING_WIRE')
        if overlay.show_wireframes:
            col.prop(overlay, "wireframe_threshold", text="")

# -----------------------------------------------------------------------------
#    Geomesh
# -----------------------------------------------------------------------------
class SPEEDSCULPT_OT_select_geomesh_in_list(Operator):
    bl_idname = "object.speedsculpt_select_geomesh_in_list"
    bl_label = "Select Geomesh"
    bl_description = "Select this Geomesh in the list"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore

    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt  
        speedsculpt = context.scene.speedsculpt
        # Met à jour directement l'index actif
        speedsculpt.geomesh_active_index = self.index
        return {'FINISHED'}

class SPEEDSCULPT_OT_rename_geomesh_item(Operator):
    bl_idname = "object.speedsculpt_rename_geomesh_item"
    bl_label = "Rename Geomesh"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore
    new_name: StringProperty() # type: ignore

    def invoke(self, context, event):
        self.new_name = self.object_name
        return context.window_manager.invoke_props_dialog(self, width=200)

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        item = speedsculpt.geomesh_objects[self.index]
        
        # Renomme l'item et l'objet
        obj = bpy.data.objects.get(item.name)
        if obj:
            new_name = self.new_name + "_Geomesh"
            obj.name = new_name
            obj.data.name = new_name
            item.name = new_name
            item.value = new_name
            
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "new_name", text="Name")

class SPEEDSCULPT_UL_geomesh(UIList):
    def __init__(self):
        self.use_filter_sort = True

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
    
        icons = load_icons()
        obj = bpy.data.objects.get(item.name)

        row = layout.row(align=True)
        
        # Display item name with rename icon and selectable label
        icon = icons.get("icon_geomesh")
        op = row.operator("object.speedsculpt_rename_geomesh_item", text="", icon_value=icon.icon_id, emboss=False)
        op.object_name = item.name
        op.index = index
        
        # Make the label activate the item in the list without selecting the object
        row.label(text=item.name)
        
        if obj:
            # Hide/Show button
            op = row.operator("object.speedsculpt_toggle_geomesh_visibility", text="", icon='HIDE_ON' if obj.hide_viewport else 'HIDE_OFF', emboss=False)
            op.object_name = item.name
            op.index = index

        # Add select button
        if obj and not obj.hide_select:
            op = row.operator("object.speedsculpt_select_geomesh", text="", icon='RESTRICT_SELECT_OFF', emboss=False)
            op.object_name = item.name
            op.index = index

        
        if obj:
            # Lock button
            op = row.operator("object.speedsculpt_lock_geomesh", text="", icon='LOCKED' if obj.hide_select else 'UNLOCKED', emboss=False)
            op.object_name = item.name
            op.index = index

            # Show in front button
            row.prop(obj, "show_in_front", text="", icon='CLIPUV_HLT' if obj.show_in_front else 'CLIPUV_DEHLT', emboss=False)

            # Mirror
            mirror_mod = obj.modifiers.get("Mirror")
            if mirror_mod:
                if mirror_mod.show_viewport:
                    icon = icons.get("icon_mirror_on")
                else:
                    icon = icons.get("icon_mirror_off")
                op = row.operator("object.speedsculpt_toggle_geomesh_mirror", text="", icon_value=icon.icon_id, emboss=False)
                op.object_name = item.name
                op.index = index
            else:
                icon = icons.get("icon_mirror_off")
                op = row.operator("object.speedsculpt_toggle_geomesh_mirror", text="", icon_value=icon.icon_id, emboss=False)
                op.object_name = item.name
                op.index = index

        # Delete button
        op = row.operator("object.speedsculpt_delete_geomesh", text="", icon='TRASH', emboss=False)
        op.object_name = item.name
        op.index = index

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        helper = bpy.types.UI_UL_list
        
        # Créer les flags pour tous les items
        flags = [self.bitflag_filter_item] * len(items)
        
        # Tri alphabétique
        order = helper.sort_items_by_name(items, "name")
        
        return flags, order
    
def Geomesh(self, context):
    prefs = get_addon_preferences()
    prefs.show_help = prefs.show_help
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()
    layout = self.layout
    obj = context.object

    box = layout.box()
    row = box.row(align=True)
    icon = icons.get("icon_geomesh")
    row.operator("object.speedsculpt_append_geomesh", text="", icon_value=icon.icon_id)
    row.prop(prefs, "show_geomesh", text="GEOMESH",
                icon='TRIA_UP' if prefs.show_geomesh else 'TRIA_RIGHT')

    if prefs.show_help :
        row.menu("SPEEDSCULPT_MT_help_geomesh",text="", icon='HELP')
    if prefs.show_geomesh:
        icon = icons.get("icon_geomesh")
        # box.operator("object.speedsculpt_append_geomesh", text="Create Geomesh", icon_value=icon.icon_id)
        box.operator("object.speedsculpt_append_geomesh", text="Create Geomesh", icon_value=icon.icon_id)

        # Vérifie si il y a des objets dans la collection
        if len(speedsculpt.geomesh_objects) > 0:
            box.template_list("SPEEDSCULPT_UL_geomesh", "", 
                            speedsculpt, "geomesh_objects", 
                            speedsculpt, "geomesh_active_index", 
                            rows=len(speedsculpt.geomesh_objects))
            # Récupère l'objet actif de la collection
            if speedsculpt.geomesh_active_index >= 0:
                active_item = speedsculpt.geomesh_objects[speedsculpt.geomesh_active_index]
                # Récupère l'objet Blender correspondant
                active_geomesh = bpy.data.objects.get(active_item.name)
                
                if active_geomesh:
                    modifier = active_geomesh.modifiers.get("GeometryNodes_Geomesh")
                    if modifier:
                        row = box.row(align=True)
                        icon = icons.get("icon_options")
                        row.label(text=active_geomesh.name, icon_value=icon.icon_id)

                        if modifier["Socket_7"]:
                            box.prop(modifier, '["Socket_8"]', text="Voxel Size")
                        else:
                            box.prop(modifier, '["Socket_4"]', text="Voxel Size")
                        box.prop(modifier, '["Socket_11"]', text="Adaptability") 
                        box.prop(modifier, '["Socket_5"]', text="Smooth") 
                        box.prop(modifier, '["Socket_10"]', text="Shade Smooth")
                        box.prop(modifier, '["Socket_7"]', text="Use Booleans")
                        if modifier["Socket_7"]:
                            box.prop_search(modifier, '["Socket_3"]', bpy.data, 'collections', text="")

                        icon = icons.get("icon_valid")
                        op = box.operator("object.speedsculpt_convert_geomesh_to_mesh", text="Convert Geomesh", icon_value=icon.icon_id)
                        op.object_name = active_geomesh.name
                        op.index = speedsculpt.geomesh_active_index
        
# -----------------------------------------------------------------------------
#    UI
# -----------------------------------------------------------------------------
def UI_Menus(self, context):
    layout = self.layout
    icons = load_icons()
    toolsettings = context.tool_settings
    sculpt = toolsettings.sculpt
    obj = context.active_object
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt

    # if context.object is not None and context.object.hide_viewport:
    # if context.object is not None and not context.object.visible_get(view_layer=context.view_layer):
    #     layout.label(text="", icon='ERROR')
    #     layout.label(text="Make selected object visible")
    #     layout.label(text="or select another visible object")

    if (context.object and context.object.visible_get(view_layer=context.view_layer)) and obj.type == 'ARMATURE' and context.object.mode == 'POSE' and not obj.name.startswith(
            "Envelope"):
        icon = icons.get("icon_symmetrize")
        layout.operator("object.symmetrize_bones", text="Symmetrize Bones", icon_value=icon.icon_id)

    elif (context.object and context.object.visible_get(view_layer=context.view_layer)) and context.object.mode == 'EDIT' and obj.type == 'ARMATURE' and not obj.name.startswith(
            "Envelope"):
        layout.operator("object.update_armature", text="Update Armature", icon='OUTLINER_OB_ARMATURE')

    else:
        if bpy.context.area.type == 'VIEW_3D':
            # if context.object is not None :
            row = layout.row(align=True)
            row.prop(prefs, 'dyntopo_or_remesh', expand=True)
            row.operator("speedsculpt.help_dyntopo_remesh", icon='HELP')

            split = layout.split()
            col = split.column(align=True)

            if prefs.dyntopo_or_remesh == "dyntopo":
                row = col.row(align=True)
                row.scale_y = 1.5
                row.scale_x = 1.5

                if sculpt.detail_type_method == 'RELATIVE':
                    row.prop(sculpt, "detail_size")

                elif sculpt.detail_type_method in {'CONSTANT','MANUAL'}:
                    row.prop(sculpt, "constant_detail_resolution", text="")

                elif sculpt.detail_type_method == 'BRUSH':
                    row.prop(sculpt, "detail_percent")

                if sculpt.detail_type_method in {'CONSTANT','MANUAL'}:
                    if context.object is not None and context.object.mode == 'SCULPT':
                        row.operator("sculpt.sample_detail_size", text="", icon='EYEDROPPER')

                    if context.selected_objects:
                        row.scale_y = 1.5
                        icon = icons.get("icon_valid")
                        row.operator("object.update_dyntopo", text="", icon_value=icon.icon_id)

                if prefs.show_help:
                    row.scale_x = 1
                    row.operator("speedsculpt.help_remesh_dyntopo_value", icon='HELP')

                if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
                    split = layout.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    row.prop(sculpt, "detail_type_method", text="")
                    row = col.row(align=True)
                    row.prop(sculpt, "detail_refine_method", text="")

            elif prefs.dyntopo_or_remesh == "remesh":
                row = col.row(align=True)
                row.scale_y = 1.5
                row.prop(prefs, 'remesh_mesh_value', text='')


                if context.selected_objects:
                    row.scale_x = 2
                    icon = icons.get("icon_valid")
                    row.operator("object.speedsculpt_pick_remesh_size", text="", icon='EYEDROPPER')
                    row.operator("object.speedsculpt_remesh_selection", text="", icon_value=icon.icon_id)

                if prefs.show_help:
                    row.scale_x = 1
                    row.operator("speedsculpt.help_remesh_dyntopo_value", icon='HELP')

            
            split = layout.split()
            col = split.column(align=True)
            row = col.row(align=True)

            row.scale_x = 3
            row.scale_y = 1.2
            icon = icons.get("icon_s")
            row.prop(prefs, 'smooth_mesh', text="", icon_value=icon.icon_id)
            icon = icons.get("icon_u")
            row.prop(prefs, 'update_remesh', text="", icon_value=icon.icon_id)

            if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
                if context.selected_objects:
                    icon = icons.get("icon_corrective_smooth")
                    row.operator('object.speedsculpt_smooth_mesh_only', text="", icon_value=icon.icon_id)

            icon = icons.get("icon_options")
            row.prop(speedsculpt, "show_options", text="", icon_value=icon.icon_id)
            if prefs.show_help:
                row.scale_x = 1
                row.operator("speedsculpt.help_remesh_dyntopo_settings",icon='HELP')

            if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
                if len([obj for obj in context.selected_objects]) == 1:
                    if not context.object.mode in ["SCULPT", "POSE"]:
                        if context.object.modifiers:
                            if "Mirror_primitive" in context.object.modifiers:
                                row = col.row(align=True)
                                row.scale_y = 1.5
                                icon = icons.get("icon_union")
                                row.operator("object.boolean_sculpt_union_difference", text="Union/Apply Modifiers",
                                             icon_value=icon.icon_id).operation_type = 'UNION'

                meta_objects = False
                if context.object is not None and context.object.type == 'META':
                    meta_objects = True

                no_modifiers = True
                if len(context.selected_objects) >= 2:
                    split = layout.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    row.scale_y = 1.2
                    row.prop(speedsculpt, 'boolean_operation', expand=True)

        if speedsculpt.show_options:
            Options(self, context)
        Speedsculpt_Shading(self, context)
        AddPrimitives(self, context)
        
        Symmetrize(self, context)
        Lattice(self, context)
        Remesh(self, context)
        # if context.object.mode == 'SCULPT':
        ExtractMask(self, context)
        QuickPose(self, context)
        Muscles(self, context)
        # Speedsculpt_References(self, context)

class SPEEDSCULPT_PT_panel(Panel):
    bl_label = "SPEEDSCULPT"
    bl_region_type = 'UI'
    bl_space_type = "VIEW_3D"
    bl_category = "Tools"

    def draw_header(self, context):
        layout = self.layout
        icons = load_icons()
        icon = icons.get("icon_speedsculpt")
        layout.label(text="", icon_value=icon.icon_id)

    def draw(self, context):
        layout = self.layout
        UI_Menus(self, context)

class SPEEDSCULPT_OT_print_path(bpy.types.Operator):
    '''  '''
    bl_idname = 'object.speedsculpt_printpath'
    bl_label = "Print"
    bl_options = {'REGISTER'}

    def execute(self, context):
        print(os.path.dirname(__file__))
        return {'FINISHED'}

# class SPEEDSCULPT_MT_bsurface_warning(Operator):
#     bl_idname = "speedsculpt.bsurface_warning"
#     bl_label = ""
#     bl_description = "BSurface is not yet compatible with Blender 4.3\n\nPlease wait for an update from the BSurface developer"

#     def execute(self, context):
#         return {'FINISHED'}

#     def check(self, context):
#         return True

#     def draw(self, context):
#         layout = self.layout
#         layout.label(text="BSurface is not yet compatible with Blender 4.3", icon='ERROR')
#         layout.label(text="Please wait for an update from the BSurface developer")
#         layout.separator()
#         layout.operator("wm.url_open", text="BSurface Documentation", 
#                      icon='URL').url = "https://extensions.blender.org/add-ons/bsurfaces-gpl-edition/"

#     def invoke(self, context, event):
#         dpi_value = bpy.context.preferences.view.ui_scale
#         coef = dpi_value * (-175) + 525
#         return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))
    
CLASSES =  [SPEEDSCULPT_OT_rename_geomesh_item,
            SPEEDSCULPT_OT_select_geomesh_in_list,
            SPEEDSCULPT_UL_geomesh,
            SPEEDSCULPT_OT_print_path,
            SPEEDSCULPT_PT_panel,
            SPEEDSCULPT_MT_help_primitives,
            SPEEDSCULPT_MT_help_skin,
            SPEEDSCULPT_MT_help_envelope,
            SPEEDSCULPT_MT_help_curves,
            SPEEDSCULPT_MT_help_draw_surface,
            SPEEDSCULPT_MT_help_lattice,
            SPEEDSCULPT_MT_help_symmetrize,
            SPEEDSCULPT_MT_help_remesh,
            SPEEDSCULPT_MT_help_extract_mask,
            SPEEDSCULPT_MT_help_quickpose,
            SPEEDSCULPT_MT_help_dyntopo_remesh,
            SPEEDSCULPT_MT_help_dyntopo_remesh_value,
            SPEEDSCULPT_MT_help_dyntopo_remesh_setting,
            SPEEDSCULPT_MT_help_creation_tools,
            SPEEDSCULPT_MT_help_asset_library,
            SPEEDSCULPT_MT_help_draw_mesh,
            SPEEDSCULPT_MT_help_create_cut_tools,
            SPEEDSCULPT_MT_help_shading,
            SPEEDSCULPT_MT_help_muscles,
            SPEEDSCULPT_MT_help_geomesh,
            # SPEEDSCULPT_MT_bsurface_warning
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)


