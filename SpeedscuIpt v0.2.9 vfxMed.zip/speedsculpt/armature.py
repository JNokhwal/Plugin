# -*- coding:utf-8 -*-

# ProFlow Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
from mathutils import Vector
from .functions import get_addon_preferences
import sys

class SPEEDSCULPT_OT_create_envelope(bpy.types.Operator):
    bl_idname = 'object.create_envelope'
    bl_label = "ENVELOPE"
    bl_description = "ENVELOPE\n\nCreate an Armature to make you object, it's like a Zsphere from ZBrush.\n\nConvert it when finish"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt

        if context.object is not None and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')

        if speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_cursor_to_selected()

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
            bpy.ops.object.armature_add(enter_editmode=False, align='WORLD')

        if speedsculpt.create_primitives == 'origin':
            bpy.context.scene.cursor.location[:] = (0,0,0)
            bpy.context.scene.cursor.rotation_euler[1] = 0
            bpy.context.scene.cursor.rotation_euler[2] = 0
            bpy.context.scene.cursor.rotation_euler[0] = 0
            bpy.ops.object.armature_add(enter_editmode=False, align='WORLD')

        if speedsculpt.create_primitives == 'cursor':
            if speedsculpt.copy_cursor_orientation:
                bpy.ops.object.armature_add(enter_editmode=False, align='CURSOR')
            else:
                bpy.ops.object.armature_add(enter_editmode=False, align='WORLD')
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        if speedsculpt.create_primitives == 'selection':
            bpy.ops.object.armature_add(enter_editmode=False, align='WORLD')
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        envelope = context.active_object
        envelope.name = "Envelope"
        context.object.data.display_type = 'ENVELOPE'

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_more()


        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.transform.translate('INVOKE_DEFAULT')

        return {'FINISHED'}
class SPEEDSCULPT_OT_enveloppe_symmetrize(bpy.types.Operator):
    bl_idname = 'object.enveloppe_symmetrize'
    bl_label = "Symmetrize"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.ops.armature.autoside_names(type='XAXIS')
        bpy.ops.armature.symmetrize()
        bpy.context.object.data.use_mirror_x = True
        bpy.ops.armature.select_all(action='DESELECT')

        return {'FINISHED'}
class SPEEDSCULPT_OT_convert_armature(bpy.types.Operator): # Code from Pentan https://gist.github.com/Pentan/3455286
    bl_idname = 'object.convert_armature'
    bl_label = "Convert Armature"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.ops.ed.undo_push()

        if context.object is not None :
            bpy.ops.object.mode_set(mode = 'OBJECT')

        for selobj in context.selected_objects:
            if selobj.type == 'ARMATURE':
                arm = selobj.data
                if len(arm.bones) <= 0:
                    print("Armature {} has no bones. skip it.".format(arm.name))
                    continue

                verts = []
                faces = []
                vgroups = []
                for abone in arm.bones:
                    head_r = abone.head_radius
                    tail_r = abone.tail_radius
                    bone_len = abone.length
                    tmpverts = [
                        Vector((-head_r, -head_r, head_r)),
                        Vector((head_r, -head_r, head_r)),
                        Vector((head_r, -head_r, -head_r)),
                        Vector((-head_r, -head_r, -head_r)),

                        Vector((-head_r, head_r, head_r)),
                        Vector((head_r, head_r, head_r)),
                        Vector((head_r, head_r, -head_r)),
                        Vector((-head_r, head_r, -head_r)),

                        Vector((-tail_r, bone_len - tail_r, tail_r)),
                        Vector((tail_r, bone_len - tail_r, tail_r)),
                        Vector((tail_r, bone_len - tail_r, -tail_r)),
                        Vector((-tail_r, bone_len - tail_r, -tail_r)),

                        Vector((-tail_r, bone_len + tail_r, tail_r)),
                        Vector((tail_r, bone_len + tail_r, tail_r)),
                        Vector((tail_r, bone_len + tail_r, -tail_r)),
                        Vector((-tail_r, bone_len + tail_r, -tail_r))
                    ]
                    tmpfaces = [
                        (3, 2, 1, 0),

                        (0, 1, 5, 4),
                        (1, 2, 6, 5),
                        (2, 3, 7, 6),
                        (3, 0, 4, 7),

                        (4, 5, 9, 8),
                        (5, 6, 10, 9),
                        (6, 7, 11, 10),
                        (7, 4, 8, 11),

                        (8, 9, 13, 12),
                        (9, 10, 14, 13),
                        (10, 11, 15, 14),
                        (11, 8, 12, 15),

                        (12, 13, 14, 15)
                    ]
                    voffset = len(verts)
                    tmpvgrp = {'name': abone.name, 'verts': []}
                    for i, v in enumerate(tmpverts):
                        verts.append(abone.matrix_local @ v)
                        tmpvgrp['verts'].append(i + voffset)
                    vgroups.append(tmpvgrp)
                    for f in tmpfaces:
                        faces.append((f[0] + voffset, f[1] + voffset, f[2] + voffset, f[3] + voffset))

                selobj.select_set(state=False)

                # create meshes
                newname = arm.name + "_mesh"
                newmesh = bpy.data.meshes.new(newname)
                newobj = bpy.data.objects.new(newname, newmesh)
                newobj.matrix_world = selobj.matrix_world

                context.scene.collection.objects.link(newobj)


                newmesh.from_pydata(verts, [], faces)
                newmesh.update(calc_edges=True)

                for vg in vgroups:
                    newvg = newobj.vertex_groups.new(name=vg['name'])
                    for vid in vg['verts']:
                        newvg.add([vid], 1.0, 'REPLACE')

                submod = newobj.modifiers.new('Subsurf', 'SUBSURF')
                submod.levels = 3


                # bpy.ops.object.hide_view_set(unselected=False)

                selobj.select_set(state=False)
                selobj.hide_set(state=True)

                newobj.select_set(state=True)
                context.view_layer.objects.active = newobj




                # bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Subsurf")



        # if prefs.dyntopo_or_remesh == 'dyntopo':
        #     bpy.ops.object.mode_set(mode='EDIT')
        #     bpy.ops.mesh.select_all(action='SELECT')
        #     bpy.ops.mesh.separate(type='LOOSE')
        #     bpy.ops.object.mode_set(mode='OBJECT')
        #     selection = context.selected_objects
        #
        #     bpy.ops.object.update_dyntopo()
        #
        #     for obj in selection:
        #         obj.select_set(state=True)
        #         context.view_layer.objects.active = obj
        #
        #     bpy.ops.object.boolean_sculpt_union_difference(operation_type='UNION')

        return {'FINISHED'}

CLASSES =  [SPEEDSCULPT_OT_convert_armature,
            SPEEDSCULPT_OT_enveloppe_symmetrize,
            SPEEDSCULPT_OT_create_envelope]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")


def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)


