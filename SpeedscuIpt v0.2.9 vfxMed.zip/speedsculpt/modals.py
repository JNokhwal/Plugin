import bpy
from bpy.props import IntProperty, FloatProperty,FloatVectorProperty
from bpy.types import Operator
from bpy.props import (
    BoolProperty,
    FloatProperty,
    IntProperty,
    StringProperty,
    PointerProperty,
    EnumProperty,
)
import blf
from mathutils import Matrix, Vector
from bpy_extras import object_utils
from math import radians
from .functions import get_addon_preferences
from .operators import fill_holes, CheckDyntopo, CheckSmoothMesh
import os
import sys
from .operators import save_tmp

class MyHandleClass:
    _handler = None

    @classmethod
    def add_handler(cls, function, args=()):
        cls._handler = bpy.types.SpaceView3D.draw_handler_add(
                function, args, 'WINDOW', 'POST_PIXEL'
                )

    @classmethod
    def remove_handler(cls):
        if cls._handler is not None:
            bpy.types.SpaceView3D.draw_handler_remove(cls._handler, 'WINDOW')
            cls._handler = None

def is_bsurface_activated():
    return any('bsurface' in addon.lower() for addon in bpy.context.preferences.addons.keys())

def is_looptools_activated():
    return any('looptools' in addon.lower() for addon in bpy.context.preferences.addons.keys())
# ----------------------------------------------------------------------------------------------------------------------
# DRAW TEXT ------------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------------------
font_info = {
    "font_id": 0,
    "handler": None,
}

def Speedsculpt_draw_callback_px(x, y, packed_strings, obj, active_area_hash):
    # Vérifier si nous sommes dans la vue active
    if hash(bpy.context.area) != active_area_hash:
        return

    # addon_pref = get_addon_preferences()

    text_size = 20
    font_id = 0
    dpi = 1
    if bpy.app.version < (4, 0, 0):
        blf.size(font_id, text_size, 72)
    else:
        blf.size(font_id, text_size * dpi)
    # blf.size(font_id, text_size, 72)
    x_offset = 0
    y_offset = 0
    shadow_color = (0, 0, 0, 0.2)
    shadow_x = 2
    shadow_y = -2
    text_pos_x = 0#addon_pref.text_pos_x
    text_pos_y = 80#addon_pref.text_pos_y
    overlap = bpy.context.preferences.system.use_region_overlap
    t_panel_width = 0
    text_shadow = True#addon_pref.text_shadow
    if overlap:
        for region in bpy.context.area.regions:
            if region.type == 'TOOLS':
                t_panel_width = region.width

    width = bpy.context.region.width
    height = bpy.context.region.height

    pos_x = min((width - t_panel_width - 250) * text_pos_x / 100 + t_panel_width, width - 250)
    pos_y = height / 3 + text_pos_y

    line_height = (blf.dimensions(font_id, "M")[1] )

    for command in packed_strings:
        if len(command) == 2:
            pstr, pcol = command
            blf.color(0, *pcol)
            text_width, text_height = blf.dimensions(font_id, pstr)
            if text_shadow:
                blf.enable(0, blf.SHADOW)
                blf.shadow_offset(0, shadow_x, shadow_y)
                blf.shadow(0, 3, shadow_color[0], shadow_color[1], shadow_color[2], shadow_color[3])
            blf.position(font_id, (pos_x + x_offset), (pos_y + y_offset), 0)
            blf.draw(font_id, pstr)
            x_offset += text_width
        else:
            x_offset = 0
            y_offset -= line_height

x = 0
y = 0
y1 = 100
RED = (1, 0, 0, 1)
GREEN = (0, 1, 0, 1)
BLUE = (0, 0, 1, 1)
WHITE = (1,1,1,1)

CR = "Carriage Return"

# DRAW MESH
ps =   [("DRAW MESH TOOL", WHITE),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("SHIFT + RMB: ", WHITE), ("Place Cursor", GREEN),CR,
        ("", WHITE),CR,
        ("CTRL + LMB: ", WHITE), ("Erase annotation", GREEN),CR,
        ("", WHITE),CR,
        ("1,2,3: ", WHITE), ("Annotation Tools", GREEN),CR,
        ("", WHITE),CR,
        ("Numpad 1,3,7: ", WHITE), ("Change View", GREEN),CR,
        ("", WHITE),CR,
        ("SPACE/ENTER: ", WHITE), ("Valid", GREEN),CR,
        ("", WHITE),CR,
        ("ESC: ", WHITE), ("Escape", GREEN)
      ]

# DRAW SKIN
ps1 =  [("DRAW SKIN", WHITE),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("CTRL + LMB: ", WHITE), ("Create on surface", GREEN),CR,
        ("", WHITE),CR,
        ("Numpad 1,3,7: ", WHITE), ("Change View", GREEN),CR,
        ("", WHITE),CR,
        ("SPACE/ENTER: ", WHITE), ("Valid", GREEN),CR,
        ("", WHITE),CR,
        ("ESC: ", WHITE), ("Escape", GREEN)
      ]

# DRAW SURFACE
ps2 =  [("DRAW SURFACE", WHITE),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("Numpad 1,3,7: ", WHITE), ("Change View", GREEN),CR,
        ("", WHITE),CR,
        ("SPACE/ENTER: ", WHITE), ("Create surface", GREEN),CR,
        ("", WHITE),CR,
        ("ESC: ", WHITE), ("Escape", GREEN)
      ]

def clear_annotations():
    # Get the active scene
    scene = bpy.context.scene
    
    if bpy.app.version < (4, 3, 0):
        gpencil = 'GPENCIL'
    else:
        gpencil = 'GREASEPENCIL'
    if bpy.app.version < (4, 3, 0):
        # Iterate over all the objects in the scene
        for obj in scene.objects:
            # Check if the object has annotations
            if obj.type == gpencil:
                # Get the annotation data
                annotation_data = obj.grease_pencil
                # Clear the annotation layers
                for layer in annotation_data.layers:
                    annotation_data.layers.remove(layer)
    else:
        gpencil_data = bpy.context.scene.grease_pencil
        if gpencil_data is not None:
            annotation_layers = gpencil_data.layers
            for layer in annotation_layers:
                bpy.ops.gpencil.layer_annotation_remove()

class SPEEDSCULPT_OT_convert_annotations(Operator):
    bl_idname = "object.speedsculpt_convert_annotations"
    bl_label = "Convert Annotations"
    bl_description = ""
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        newCurve = bpy.data.curves.new('gpencil_curve', type='CURVE')
        newCurve.dimensions = '3D'
        CurveObject = object_utils.object_data_add(context, newCurve)
        
        if bpy.app.version < (4, 3, 0):
            grease_pencil = bpy.data.grease_pencils[0]
            strokes = grease_pencil.layers.active.active_frame.strokes
        else:
            gpencil_data = bpy.context.scene.grease_pencil
            if gpencil_data and gpencil_data.layers:
                layer = gpencil_data.layers[0]
                frame = layer.frames[0] 
                strokes = frame.strokes[0] 


        CurveObject.location = (0.0, 0.0, 0.0)
        CurveObject.rotation_euler = (0.0, 0.0, 0.0)
        CurveObject.scale = (1.0, 1.0, 1.0)

        if bpy.app.version < (4, 3, 0):
            for i, stroke in enumerate(strokes):
                stroke_points = strokes[i].points
                data_list = [(point.co.x, point.co.y, point.co.z)
                            for point in stroke_points]
                points_to_add = len(data_list) - 1

                flat_list = []
                for point in data_list:
                    flat_list.extend(point)

                spline = newCurve.splines.new(type='BEZIER')
                spline.bezier_points.add(points_to_add)
                spline.bezier_points.foreach_set("co", flat_list)

            for point in spline.bezier_points:
                point.handle_left_type = "AUTO"
                point.handle_right_type = "AUTO"
        else:
            if isinstance(strokes, bpy.types.GPencilStroke):
                strokes = [strokes]

            for stroke in strokes:
                stroke_points = stroke.points
                data_list = [(point.co.x, point.co.y, point.co.z) for point in stroke_points]
                points_to_add = len(data_list) - 1

                flat_list = [coord for point in data_list for coord in point]

                spline = newCurve.splines.new(type='BEZIER')
                spline.bezier_points.add(points_to_add)
                spline.bezier_points.foreach_set("co", flat_list)

            for point in spline.bezier_points:
                point.handle_left_type = "AUTO"
                point.handle_right_type = "AUTO"


        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.curve.select_all(action='SELECT')
        bpy.ops.curve.spline_type_set(type='POLY')

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        # annotation_layers = bpy.context.scene.grease_pencil
        # if annotation_layers and annotation_layers.data.layers:
        active_layer = bpy.context.active_annotation_layer
        if active_layer is not None:
            bpy.ops.gpencil.layer_annotation_remove()
        # clear_annotations()
        bpy.ops.object.convert(target='CURVE')
        return {"FINISHED"}

class SPEEDSCULPT_OT_draw_remesh(bpy.types.Operator):
    """Draw a mesh on a surface or on the view"""
    bl_idname = "object.speedsculpt_draw_remesh"
    bl_label = "Draw Remesh"

    def finalize(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()
        bpy.ops.object.speedsculpt_convert_annotations()

        self.new_obj = context.active_object
        context.object.data.bevel_depth = speedsculpt.draw_remesh_size
        context.object.data.bevel_resolution = 12
        context.object.data.splines[0].use_smooth = True
        bpy.ops.object.mode_set(mode='OBJECT')

        if not self.start_with_selection:
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

        bpy.ops.object.convert(target='MESH')
        fill_holes()

        new_obj = context.active_object

        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                self.act_obj.select_set(state=False)
                self.new_obj.select_set(state=True)
                context.view_layer.objects.active = self.new_obj

        if self.start_with_selection and not speedsculpt.add_mirror:
        # if self.start_with_selection :
            self.act_obj.select_set(state=True)
            context.view_layer.objects.active = self.act_obj

        speedsculpt.boolean_operation = 'union'
        bpy.ops.object.speedsculpt_remesh_selection()

        if prefs.dyntopo_or_remesh == 'dyntopo':
            if prefs.update_detail_flood_fill:
                bpy.ops.object.update_dyntopo()

        if self.sculpt:
           bpy.ops.object.mode_set(mode='SCULPT')

        if speedsculpt.add_mirror:
            mod_mirror = new_obj.modifiers.new("Mirror", 'MIRROR')
            mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
            for prop, axis_index in mirror_axes.items():
                if getattr(speedsculpt, prop):
                    mod_mirror.use_axis[axis_index] = True
            if speedsculpt.ref_obj:
                mod_mirror.mirror_object = speedsculpt.ref_obj
            elif len([obj for obj in context.selected_objects]) == 1:
                mod_mirror.mirror_object = self.act_obj

        speedsculpt.boolean_operation = self.boolean_mode

    def modal(self, context, event):
        if event.type == "Z" and event.ctrl:
            return {"RUNNING_MODAL"}

        # CURSOR
        if event.shift and event.type == 'RIGHTMOUSE':
            return {'PASS_THROUGH'}

        # VIEWS
        if event.type in {'NUMPAD_1', 'NUMPAD_3', 'NUMPAD_7', 'NUMPAD_5'} or event.ctrl and event.type in {'NUMPAD_1',
                                                                                                           'NUMPAD_3',
                                                                                                           'NUMPAD_7',
                                                                                                           'NUMPAD_5'}:
            return {'PASS_THROUGH'}

        if event.alt and event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
            return {'PASS_THROUGH'}

        if event.alt and event.type == 'MIDDLEMOUSE' and event.value == 'DRAG':
            return {'PASS_THROUGH'}

        if event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
            return {'PASS_THROUGH'}

        if event.shift and event.type == 'C' :
            return {'PASS_THROUGH'}

        if event.type == 'ONE' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate", cycle=False, space_type='VIEW_3D')

        elif event.type == 'TWO' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate_line", cycle=False, space_type='VIEW_3D')

        elif event.type == 'THREE' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate_polygon", cycle=False, space_type='VIEW_3D')


        if event.type in {'RET','SPACE','ENTER'} and event.value == 'PRESS':
            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            MyHandleClass.remove_handler()
            context.area.tag_redraw()
            self.finalize(context)


            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if self.start_with_selection:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj

            MyHandleClass.remove_handler()
            context.area.tag_redraw()
            
            active_layer = bpy.context.active_annotation_layer
            if active_layer is not None:
                bpy.ops.gpencil.layer_annotation_remove()

            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        bpy.ops.ed.undo_push()
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        # Stocker le hash de la vue active
        self.active_area_hash = hash(context.area)

        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()

        self.boolean_mode = speedsculpt.boolean_operation

        if context.area and context.area.type == 'VIEW_3D':
            self.sculpt = False
            self.act_obj = False
            self.start_with_selection = False

            if context.object is None or not context.object.visible_get(view_layer=context.view_layer) :
                speedsculpt.primitives_parenting = False
                speedsculpt.add_mirror = False
            else:
                self.act_obj = context.active_object

                if context.selected_objects:
                    self.start_with_selection = True

                if context.active_object.mode == 'SCULPT':
                    self.sculpt = True

                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.select_all(action='DESELECT')


            bpy.ops.wm.tool_set_by_id(name="builtin.annotate", cycle=False, space_type='VIEW_3D')
            
            if speedsculpt.draw_remesh_placement == 'cursor':
                context.scene.tool_settings.annotation_stroke_placement_view3d = 'CURSOR'
            elif speedsculpt.draw_remesh_placement == 'view':
                context.scene.tool_settings.annotation_stroke_placement_view3d = 'VIEW'
            elif speedsculpt.draw_remesh_placement == 'surface':
                context.scene.tool_settings.annotation_stroke_placement_view3d = 'SURFACE'

            MyHandleClass.remove_handler()
            MyHandleClass.add_handler(Speedsculpt_draw_callback_px, (x, y, ps, context.object, self.active_area_hash))
            context.area.tag_redraw()

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_draw_surface(bpy.types.Operator):
    """Draw a Surface on a mesh or on the view"""
    bl_idname = "object.speedsculpt_draw_surface"
    bl_label = "Draw Surface"

    start_with_selection = False
    active_area_hash = None  # Nouvelle propriété pour stocker le hash

    def draw_surface_start(self, context):

        # Vérifier si nous sommes dans la vue active
        if hash(bpy.context.area) != self.active_area_hash:
            return
    
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        # selected = (obj for obj in context.selected_objects if len(obj) == 1)
        actObj = context.active_object if context.object is not None else None

        if bpy.app.version < (4, 2, 0):
            bpy.ops.preferences.addon_enable(module="mesh_bsurfaces")

        # prepare GP
        if speedsculpt.draw_surface_placement == 'SURFACE':
            context.scene.tool_settings.annotation_stroke_placement_view3d = 'SURFACE'
        elif speedsculpt.draw_surface_placement == 'CURSOR':
            context.scene.tool_settings.annotation_stroke_placement_view3d = 'CURSOR'

        
        context.scene.bsurfaces.SURFSK_shade_smooth = True

        if not prefs.update_remesh or prefs.update_detail_flood_fill:
            context.scene.bsurfaces.SURFSK_edges_U = 8
            context.scene.bsurfaces.SURFSK_edges_V = 2
        else:
            context.scene.bsurfaces.SURFSK_edges_U = 6
            context.scene.bsurfaces.SURFSK_edges_V = 4

        # Create Empty mesh
        bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=False, align='WORLD')

        gp_surface = context.active_object
        context.active_object.name = "GP_Surface"

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.delete(type='VERT')
        bpy.ops.object.mode_set(mode='OBJECT')
        if bpy.app.version < (4, 1, 0):
            bpy.ops.object.shade_smooth(use_auto_smooth=True)
        else:
            bpy.ops.object.shade_smooth_by_angle()


        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                actObj.select_set(state=True)
                context.view_layer.objects.active = actObj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                actObj.select_set(state=False)
                gp_surface.select_set(state=True)
                context.view_layer.objects.active = gp_surface

        # Add Solidify
        mod_solidify = gp_surface.modifiers.new("Solidify", 'SOLIDIFY')
        mod_solidify.thickness = speedsculpt.draw_surface_thickness
        mod_solidify.offset = speedsculpt.draw_surface_offset
        mod_solidify.use_quality_normals = True
        mod_solidify.use_even_offset = True

        # Add subsurf
        mod_subsurf = gp_surface.modifiers.new("Subsurf", 'SUBSURF')
        mod_subsurf.levels = 3

        context.scene.bsurfaces.SURFSK_object_with_retopology = gp_surface
        context.scene.bsurfaces.SURFSK_mesh = gp_surface
        bpy.ops.object.mode_set(mode='EDIT')

    def finalize(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        bpy.ops.speedsculpt.add_bsurface()
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.mode_set(mode='OBJECT')

        if prefs.dyntopo_or_remesh == 'remesh':
            if not self.start_with_selection:
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

            # if prefs.update_remesh:
            if speedsculpt.draw_surface_update_remesh:
                bpy.ops.object.speedsculpt_remesh_selection()

            if self.start_with_selection:
                if self.sculpt:
                    bpy.ops.object.mode_set(mode='SCULPT')

        elif prefs.dyntopo_or_remesh == 'dyntopo':
            if not self.start_with_selection:
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

            if prefs.update_detail_flood_fill :
                bpy.ops.object.update_dyntopo()

            if self.start_with_selection:
                if self.sculpt:
                    bpy.ops.object.mode_set(mode='SCULPT')


        # ADD MIRROR
        if speedsculpt.add_mirror:
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')

            mod_mirror = context.object.modifiers.new("Mirror", 'MIRROR')
            mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
            for prop, axis_index in mirror_axes.items():
                if getattr(speedsculpt, prop):
                    mod_mirror.use_axis[axis_index] = True

            mod_mirror.use_mirror_merge = False

            if speedsculpt.ref_obj:
                mod_mirror.mirror_object = speedsculpt.ref_obj
            elif len([obj for obj in context.selected_objects]) == 1:
                mod_mirror.mirror_object = self.act_obj
            else:
                bpy.ops.object.modifier_remove(modifier="Mirror")

    def modal(self, context, event):
        if event.type == "Z" and event.ctrl:
            return {"RUNNING_MODAL"}

        # CURSOR
        if event.shift and event.type == 'RIGHTMOUSE':
            return {'PASS_THROUGH'}

        # VIEWS
        if event.type in {'NUMPAD_1', 'NUMPAD_3', 'NUMPAD_7', 'NUMPAD_5'} or event.ctrl and event.type in {'NUMPAD_1',
                                                                                                           'NUMPAD_3',
                                                                                                           'NUMPAD_7',
                                                                                                           'NUMPAD_5'}:
            return {'PASS_THROUGH'}

        if event.alt and event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
            return {'PASS_THROUGH'}

        if event.alt and event.type == 'MIDDLEMOUSE' and event.value == 'DRAG':
            return {'PASS_THROUGH'}

        if event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
            return {'PASS_THROUGH'}

        if event.shift and event.type == 'C' :
            return {'PASS_THROUGH'}

        if event.type == 'ONE' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate", cycle=False, space_type='VIEW_3D')

        elif event.type == 'TWO' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate_line", cycle=False, space_type='VIEW_3D')

        elif event.type == 'THREE' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate_polygon", cycle=False, space_type='VIEW_3D')


        if event.type in {'RET','SPACE','ENTER'} and event.value == 'PRESS':
            MyHandleClass.remove_handler()
            context.area.tag_redraw()
            self.finalize(context)

            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')

            clear_annotations()
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if context.selected_objects:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.delete()

            if self.start_with_selection:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj

            MyHandleClass.remove_handler()
            context.area.tag_redraw()
            # bpy.data.grease_pencils['Annotations'].layers['Note'].clear()
            clear_annotations()
            active_layer = bpy.context.active_annotation_layer
            if active_layer is not None:
                bpy.ops.gpencil.layer_annotation_remove()

            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):

        # Stocker le hash de la vue active
        self.active_area_hash = hash(context.area)

        bpy.ops.ed.undo_push()
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()


        if context.area and context.area.type == 'VIEW_3D':
            if context.object is None or not context.object.visible_get(view_layer=context.view_layer) :
                speedsculpt.primitives_parenting = False
                speedsculpt.add_mirror = False
            else:
                self.act_obj = context.active_object

                if context.selected_objects:
                    self.start_with_selection = True


                self.sculpt = False
                if context.active_object.mode == 'SCULPT':
                    self.sculpt = True

                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.select_all(action='DESELECT')

            self.draw_surface_start(context)

            bpy.ops.wm.tool_set_by_id(name="builtin.annotate", cycle=False, space_type='VIEW_3D')


            MyHandleClass.remove_handler()
            MyHandleClass.add_handler(Speedsculpt_draw_callback_px, (x, y, ps2, context.object, self.active_area_hash))
            context.area.tag_redraw()

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_draw_skin(bpy.types.Operator):
    bl_idname = "object.speedsculpt_draw_skin"
    bl_label = "DRAW SKIN"
    bl_description = "DRAW SKIN\n\nDraw a line in the 3Dview, it will add a Skin Modifier.\n\nYou will be able to Go in Edit Mode and Edit it.\n\nCTRL A to Scale a Vertex"

    prim_curve = False
    start_with_selection = False
    on_surface = False
    active_area_hash = None  # Nouvelle propriété pour stocker le hash

    def create_curve(self, context):
        speedsculpt = context.scene.speedsculpt

        bpy.ops.curve.primitive_bezier_curve_add(enter_editmode=False, align='VIEW')
        self.curve = context.active_object
        speedsculpt.primitive_created = True
        self.prim_curve = True

        context.space_data.overlay.display_handle = 'NONE'
        context.space_data.overlay.show_curve_normals = False

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.curve.delete(type='VERT')

    def create_skin(self, context):
        bpy.ops.object.convert(target='MESH')
        mod_skin = context.object.modifiers.new("Skin", 'SKIN')
        mod_skin.use_smooth_shade = True
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.mesh.unsubdivide()

        if not self.on_surface :
            bpy.ops.mesh.unsubdivide()

        if is_looptools_activated():
            bpy.ops.mesh.looptools_space(influence=100, input='selected', interpolation='cubic', lock_x=False, lock_y=False, lock_z=False)

        if not self.on_surface:
            bpy.ops.object.add_smooth_skin()
        bpy.ops.object.skin_root_mark()
        context.tool_settings.mesh_select_mode = (True, False, False)
        bpy.ops.object.mode_set(mode='OBJECT')

        # Add Subdiv
        mod_subsurf = context.object.modifiers.new("Subsurf", 'SUBSURF')
        mod_subsurf.levels = 3

    def finalize(self, context):
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        context.scene.tool_settings.curve_paint_settings.depth_mode = 'CURSOR'
        self.new_obj = context.active_object


        bpy.ops.object.mode_set(mode='OBJECT')
        context.object.data.dimensions = '2D'
        context.object.data.resolution_u = 3
        new_obj = context.active_object

        self.create_skin(context)

        if speedsculpt.add_mirror:
            mod_mirror = new_obj.modifiers.new("Mirror_Skin", 'MIRROR')
            mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
            for prop, axis_index in mirror_axes.items():
                if getattr(speedsculpt, prop):
                    mod_mirror.use_axis[axis_index] = True
 
            if speedsculpt.ref_obj:
                mod_mirror.mirror_object = speedsculpt.ref_obj
            elif len([obj for obj in context.selected_objects]) == 1:
                mod_mirror.mirror_object = self.act_obj

        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                self.act_obj.select_set(state=False)
                new_obj.select_set(state=True)
                context.view_layer.objects.active = new_obj
        
        bpy.ops.object.mode_set(mode='EDIT')

        MyHandleClass.remove_handler()
        context.area.tag_redraw()

        bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')

    def modal(self, context, event):
        if event.type == "Z" and event.ctrl:
            return {"RUNNING_MODAL"}

        # CURSOR
        if event.shift and event.type == 'RIGHTMOUSE':
            return {'PASS_THROUGH'}

        # VIEWS
        if event.type in {'NUMPAD_1', 'NUMPAD_3', 'NUMPAD_7', 'NUMPAD_5'} or event.ctrl and event.type in {'NUMPAD_1',
                                                                                                           'NUMPAD_3',
                                                                                                           'NUMPAD_7',
                                                                                                           'NUMPAD_5'}:
            return {'PASS_THROUGH'}

        # if event.type =='MIDDLEMOUSE':
        #     return {'PASS_THROUGH'}

        # if event.alt and event.type == 'MIDDLEMOUSE' and event.value == 'DRAG':
        #     return {'PASS_THROUGH'}

        # if event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
        #     return {'PASS_THROUGH'}

        if event.shift and event.type == 'C' :
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS' :
            self.create_curve(context)

            if event.ctrl:
                self.on_surface = True
                context.scene.tool_settings.curve_paint_settings.depth_mode = 'SURFACE'
            else:
                context.scene.tool_settings.curve_paint_settings.depth_mode = 'CURSOR'

            bpy.ops.wm.tool_set_by_id(name="builtin.draw")
            bpy.ops.curve.draw('INVOKE_DEFAULT', error_threshold=0.05, fit_method='SPLIT', corner_angle=60,
                               use_cyclic=False,
                               stroke=[],
                               wait_for_input=False)

        if event.value == 'RELEASE' and self.prim_curve:
            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            self.finalize(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            MyHandleClass.remove_handler()
            context.area.tag_redraw()
            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        bpy.ops.ed.undo_push()
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        # Stocker le hash de la vue active
        self.active_area_hash = hash(context.area)

        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()

        if context.area and context.area.type == 'VIEW_3D':

            if context.object is None or not context.object.visible_get(view_layer=context.view_layer) :
                speedsculpt.primitives_parenting = False
                speedsculpt.add_mirror = False
            else:
                self.act_obj = context.active_object
                if context.selected_objects:
                    self.start_with_selection = True
                    bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.select_all(action='DESELECT')

            MyHandleClass.remove_handler()
            MyHandleClass.add_handler(Speedsculpt_draw_callback_px, (x, y, ps1, context.object, self.active_area_hash))
            context.area.tag_redraw()

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_assets_on_surface(bpy.types.Operator):
    """Move an object with the mouse, example"""
    bl_idname = "object.speedsculpt_assets_on_surface"
    bl_label = "Assets on Surface"

    first_mouse_x: IntProperty() # type: ignore
    x_value: FloatProperty() # type: ignore
    first_mouse_y: IntProperty() # type: ignore
    primitive_created = False

    def get_spin(self):
        obj = bpy.context.object
        return obj.rotation_euler.to_matrix().to_euler('ZYX').z

    def set_spin(self, value):
        obj = bpy.context.object
        rot = obj.rotation_euler.to_matrix().to_euler('ZYX')
        rot.z = value
        obj.rotation_euler = rot.to_matrix().to_euler(obj.rotation_mode)

    def get_scale_x(self):
        obj = bpy.context.active_object
        return obj.scale.x

    def set_scale_x(self, value):
        obj = bpy.context.active_object
        obj.scale.x = value

    def get_scale_y(self):
        obj = bpy.context.active_object
        return obj.scale.y

    def set_scale_y(self, value):
        obj = bpy.context.active_object
        obj.scale.y = value

    def get_scale_z(self):
        obj = bpy.context.active_object
        return obj.scale.z

    def set_scale_z(self, value):
        obj = bpy.context.active_object
        obj.scale.z = value

    spin: FloatProperty(
        unit='ROTATION',
        get=get_spin,
        set=set_spin, ) # type: ignore

    scaling_x: FloatProperty(
        unit='ROTATION',
        get=get_scale_x,
        set=set_scale_x, ) # type: ignore

    scaling_y: FloatProperty(
        unit='ROTATION',
        get=get_scale_y,
        set=set_scale_y, ) # type: ignore

    scaling_z: FloatProperty(
        unit='ROTATION',
        get=get_scale_z,
        set=set_scale_z, ) # type: ignore

    def create_cube(self, context):
        bpy.ops.object.speedsculpt_add_assets_to_scene('INVOKE_DEFAULT')
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
        context.object.rotation_euler = self.cursor_rot
        self.primitive_created = True
        self.act_obj = context.active_object

        bpy.ops.wm.tool_set_by_id(name="builtin.select")

    def finalize(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        if prefs.dyntopo_or_remesh == 'remesh':
            if prefs.update_remesh:
                if self.start_with_selection:
                    self.start_obj.select_set(state=True)
                    context.view_layer.objects.active = self.start_obj
                speedsculpt.boolean_operation = 'union'
                bpy.ops.object.speedsculpt_remesh_selection()

        elif prefs.dyntopo_or_remesh == 'dyntopo':
            if prefs.update_detail_flood_fill:
                if self.start_with_selection:
                    self.start_obj.select_set(state=True)
                    context.view_layer.objects.active = self.start_obj
                bpy.ops.object.update_dyntopo()

        if self.sculpt:
           bpy.ops.object.mode_set(mode='SCULPT')


    def modal(self, context, event):
        prefs = get_addon_preferences()

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and not self.primitive_created:
            # CURSOR
            bpy.ops.wm.tool_set_by_id(name="builtin.cursor")
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT', use_depth=True, orientation='GEOM')
            self.cursor_rot = context.scene.cursor.rotation_euler.copy()
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            context.object.rotation_euler = self.cursor_rot
            bpy.ops.wm.tool_set_by_id(name="builtin.select")
            self.primitive_created = True
            self.act_obj = context.active_object
            # self.create_cube(context)

        if self.primitive_created:

            if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
                delta_y = self.first_mouse_y + event.mouse_y
                speed = 0.33 if event.shift else 1

                # ROTATE
                self.spin = delta_y * 0.005 * speed * 0.85

                # SCALE
                self.scaling_x = self.act_obj.scale.x + (event.mouse_x - event.mouse_prev_x) * 0.05 * speed
                self.scaling_y = self.act_obj.scale.y + (event.mouse_x - event.mouse_prev_x) * 0.05 * speed
                self.scaling_z = self.act_obj.scale.z + (event.mouse_x - event.mouse_prev_x) * 0.05 * speed

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':


            self.finalize(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:

            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        bpy.ops.ed.undo_push()
        if context.area and context.area.type == 'VIEW_3D':

            self.first_mouse_x = event.mouse_x
            self.first_mouse_y = event.mouse_y

            self.sculpt = False
            self.start_obj = False
            self.start_with_selection = False

            if context.object is not None and context.selected_objects:
                self.start_with_selection = True
                self.start_obj = context.active_object

                if context.active_object.mode == 'SCULPT':
                    self.sculpt = True

                bpy.ops.object.mode_set(mode='OBJECT')

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:

            return {'CANCELLED'}

class SPEEDSCULPT_OT_smooth_modal(bpy.types.Operator):
    """Move an object with the mouse, example"""
    bl_idname = "object.speedsculpt_smooth_modal"
    bl_label = "Smooth Modal Operator"

    first_mouse_x: IntProperty() # type: ignore
    first_value: FloatProperty() # type: ignore

    def modal(self, context, event):

        if event.type in 'MOUSEMOVE':
            delta = self.first_mouse_x - event.mouse_x

            if event.shift:
                delta = delta / 2

            self.act_mod.iterations = int(self.first_value - delta * 0.1)

        if event.type == 'LEFTMOUSE':
            bpy.ops.object.modifier_apply(modifier=self.act_mod.name)
            if self.prefs.sculpt_mode:
                bpy.ops.object.mode_set(mode='SCULPT')

            return {'FINISHED'}

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            bpy.ops.object.modifier_remove(modifier=self.act_mod.name)
            if self.prefs.sculpt_mode:
                bpy.ops.object.mode_set(mode='SCULPT')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        bpy.ops.ed.undo_push()
        if bpy.context.selected_objects:
            self.prefs = get_addon_preferences()
            self.first_mouse_x = event.mouse_x

            self.act_obj = bpy.context.active_object
            self.sel = [o for o in bpy.context.selected_objects]


            if context.object.mode == 'SCULPT':
                self.prefs.sculpt_mode = True
            else:
                self.prefs.sculpt_mode = False

            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')

            for obj in self.sel:
                obj.select_set(state=True)
                bpy.context.view_layer.objects.active = obj

                has_smooth = bpy.context.object.modifiers.get("Smooth_Modal")

                if has_smooth:
                    self.smooth_mod = has_smooth
                else:
                    self.smooth_mod = obj.modifiers.new('Smooth_Modal', 'SMOOTH')
                    self.smooth_mod.factor = 1
                    self.smooth_mod.iterations = 0

            for obj in self.sel:
                obj.select_set(state=True)

            bpy.context.view_layer.objects.active = self.act_obj

            self.act_mod = self.smooth_mod
            self.first_value = self.smooth_mod.iterations

            self.mod_created = True

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

tmp_verts = []
tmp_verts_storage = []

class SPEEDSCULPT_OT_scale(bpy.types.Operator):
    """Scale mesh with mouse"""
    bl_idname = "object.speedsculpt_scale"
    bl_label = "Simple Modal Operator"
    bl_options = {'GRAB_CURSOR','BLOCKING'}

    first_mouse_x: IntProperty() # type: ignore
    first_value: FloatProperty() # type: ignore
    action_scale = False

    obj_matrix_save = None
    start_end_cap = False
    random = False

    def modal(self, context, event):
        prefs = get_addon_preferences()

        if event.type == 'MOUSEMOVE' :
            speed = 0.01 if event.shift else 0.5
            # delta = 1. - 0.01 * (self.first_mouse_x - event.mouse_x) * speed #* addon_pref.modal_speed
            for mesh in self.meshes:
                obj = mesh["obj"]
                matrix = mesh["matrix"]

                delta = 0.05 * (event.mouse_x - self.first_mouse_x) * speed / 100
                obj.matrix_world = matrix @ Matrix.Scale(1 + delta, 4)
            # else:
            #     for i, v in enumerate(context.object.data.vertices):
            #         if event.ctrl:
            #             v.co.x = delta* tmp_verts[i][0]
            #             v.co.y = delta* tmp_verts[i][1]
            #             v.co.z = delta* tmp_verts[i][2]
            #         else:
            #             v.co.x = (delta - delta % 0.1) * tmp_verts[i][0]
            #             v.co.y = (delta - delta % 0.1) * tmp_verts[i][1]
            #             v.co.z = (delta - delta % 0.1) * tmp_verts[i][2]

        elif event.type in {'LEFTMOUSE', 'SPACE'} :
            if prefs.dyntopo_or_remesh == "remesh":
                if prefs.update_remesh:
                    bpy.ops.object.speedsculpt_remesh_selection()

            elif prefs.dyntopo_or_remesh == "dyntopo":
                CheckDyntopo()
                CheckSmoothMesh()
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            context.view_layer.objects.active = self.act_obj
            self.act_obj.select_set(state=True)

            context.object.location.x = self.first_value
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.act_obj = context.active_object

        self.meshes = []
        for obj in self.sel:
            obj.select_set(state=True)
            self.meshes.append({
                "obj": obj,
                "matrix": obj.matrix_world.copy()
            })

            self.first_mouse_x = event.mouse_x

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}

        else:
            self.report({'WARNING'}, "PROUT")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_ibl_manupilate(Operator):
    """ Rotates the environement """
    bl_idname = 'speedsculpt.ibl_manipulate'
    bl_label = "IBL manupulate"
    bl_options = {'REGISTER', "BLOCKING", "GRAB_CURSOR"}

    mouse_pos_x: IntProperty() # type: ignore
    mouse_pos_y: IntProperty()  # type: ignore
    initial_strength: FloatProperty()  # type: ignore
    shading_rotation: FloatProperty() # type: ignore
    end_position = 0
    tmp_pos_x = 0
    rotation_value: FloatProperty(default=0.0)  # type: ignore
    strength_value: FloatProperty(default=1.0)  # type: ignore
    movement_mode: StringProperty(default='NONE')  # type: ignore
    initial_mouse_pos: FloatVectorProperty(size=2, default=(0.0, 0.0))  # type: ignore

    def ibl_rotation_info(self, context, _region):

        # Define colors
        color_orange = (1, 0.522, 0, 1)
        color_white = (1.0, 1.0, 1.0, 1.0)

        # Font settings
        font_id = 0
        font_size_title = 24
        font_size_text = 20
        blf.size(font_id, font_size_title)

        # Calculate position
        height = bpy.context.area.height  # Utiliser bpy.context au lieu de context
        t_panel_width = 0
        if bpy.context.preferences.system.use_region_overlap:  # Utiliser bpy.context ici aussi
            for region in bpy.context.area.regions:  # Et ici
                if region.type == 'TOOLS':
                    t_panel_width = region.width

        # Starting position
        y = height / 2 + 100
        x = t_panel_width + 20

        # Draw Rotation value
        rotation_text = "ROTATION: "
        # Convertir la valeur de radians en degrés et la formater
        rotation_degrees = (self.rotation_value * 180.0 / 3.14159) % 360
        rotation_value = f"{rotation_degrees:.1f}°"

        blf.position(font_id, x, y, 0)
        blf.color(font_id, *color_orange)
        blf.draw(font_id, rotation_text)

        blf.position(font_id, x + blf.dimensions(font_id, rotation_text)[0], y, 0)
        blf.color(font_id, *color_white)
        blf.draw(font_id, rotation_value)

        # Draw Strength value
        y -= 40
        strength_text = "STRENGTH: "
        strength_value = f"{self.strength_value:.2f}"

        blf.position(font_id, x, y, 0)
        blf.color(font_id, *color_orange)
        blf.draw(font_id, strength_text)

        blf.position(font_id, x + blf.dimensions(font_id, strength_text)[0], y, 0)
        blf.color(font_id, *color_white)
        blf.draw(font_id, strength_value)

        # Draw instructions
        y -= 40
        blf.size(font_id, font_size_text)

        instructions = {
            "MOUSE X: ": "Rotate HDRI",
            "MOUSE Y: ": "Adjust Strength",
            "RELEASE: ": "Confirm"
        }


        for key, description in instructions.items():
            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_orange)
            blf.draw(font_id, key)
            
            blf.position(font_id, x + 100, y, 0)
            blf.color(font_id, *color_white)
            blf.draw(font_id, description)
            
            y -= font_size_text

    def get_background_node(self, world):
        nodes = world.node_tree.nodes
        background_node = self.get_node_from_type(nodes, "BACKGROUND")
        if not background_node:
            group_node = self.get_node_from_type(nodes, "GROUP")
            if group_node:
                background_node = self.get_node_from_type(
                    group_node.node_tree.nodes, "BACKGROUND"
                )
        return background_node

    def get_node_from_type(self, nodes, nType):
        for node in nodes:
            if node.type == nType:
                return node

        return None

    def get_mapping_node(self, world):
        nodes = world.node_tree.nodes
        
        mapping_node = self.get_node_from_type(nodes, "MAPPING")
        if not mapping_node:
            group_node = self.get_node_from_type(nodes, "GROUP")
            if group_node:
                mapping_node = self.get_node_from_type(
                    group_node.node_tree.nodes, "MAPPING"
                )

        return mapping_node

    def get_shading_type(self, shading):
        if shading.type != "WIREFRAME" or \
                (shading.type == "SOLID" and shading.light == "STUDIO") or \
                shading.type in {"MATERIAL", "RENDERED"}:
            return shading.type
        return

    def set_shading_rotation(self, mapping_node):
        self.shading_rotation = mapping_node.inputs[2].default_value[2]

    def set_z_axis(self, mapping_node, value):
        mapping_node.inputs[2].default_value[2] = value

    def modal(self, context, event):

        if event.type == "MOUSEMOVE":
            # Calculate both offsets
            offset_x = abs(event.mouse_x - self.initial_mouse_pos[0])
            offset_y = abs(event.mouse_y - self.initial_mouse_pos[1])
            
            # If no mode is set, determine it based on the first significant movement
            if self.movement_mode == 'NONE':
                if max(offset_x, offset_y) > 10:  # Seuil de détection
                    self.movement_mode = 'ROTATION' if offset_x > offset_y else 'STRENGTH'
                    # Mettre à jour la position de référence pour le mode choisi
                    if self.movement_mode == 'ROTATION':
                        self.mouse_pos_x = event.mouse_x
                    else:
                        self.mouse_pos_y = event.mouse_y
            
            # Apply changes based on mode
            if self.movement_mode == 'ROTATION':
                offset_x = (event.mouse_x - self.mouse_pos_x) / 300
                # Handle horizontal movement (rotation)
                if (self.shading_type == "MATERIAL" and self.shading.use_scene_world) or (self.shading_type == "RENDERED" and self.shading.use_scene_world_render): 
                    self.set_z_axis(
                        self.mapping_node, self.shading_rotation - offset_x
                    )
                else:
                    self.shading.studiolight_rotate_z = self.shading_rotation - offset_x
                    
                    if round(self.shading.studiolight_rotate_z, 4) == -3.1416:
                        self.end_position = -3.1416
                    if round(self.shading.studiolight_rotate_z, 4) == 3.1416:
                        self.end_position = 3.1416

                    if self.end_position:
                        if not self.tmp_pos_x:
                            self.tmp_pos_x = event.mouse_x
                        if self.end_position == -3.1416 and event.mouse_x > self.tmp_pos_x:
                            self.shading.studiolight_rotate_z = self.shading_rotation = 3.14159
                            self.end_position = self.tmp_pos_x = 0
                            self.mouse_pos_x = event.mouse_x
                        elif self.end_position == 3.1416 and event.mouse_x < self.tmp_pos_x:
                            self.shading.studiolight_rotate_z = self.shading_rotation = -3.14159
                            self.end_position = self.tmp_pos_x = 0
                            self.mouse_pos_x = event.mouse_x
            
            # if context.space_data.shading.light != 'STUDIO':
            elif self.movement_mode == 'STRENGTH':
                # Handle vertical movement (background strength)
                if self.background_node:
                    offset_y = (event.mouse_y - self.mouse_pos_y) / 300
                    new_strength = max(0, self.initial_strength + offset_y * 2)
                    self.background_node.inputs[1].default_value = new_strength
            
            # Update display values
            if self.background_node:
                self.strength_value = self.background_node.inputs[1].default_value
            if (self.shading_type == "MATERIAL" and self.shading.use_scene_world) or (self.shading_type == "RENDERED" and self.shading.use_scene_world_render):
                self.rotation_value = self.mapping_node.inputs[2].default_value[2]
            else:
                self.rotation_value = self.shading.studiolight_rotate_z

            context.area.tag_redraw()
         
        if event.type == "ESC":
            if (self.shading_type == "MATERIAL" and self.shading.use_scene_world) or (self.shading_type == "RENDERED" and self.shading.use_scene_world_render):
                self.set_z_axis(
                    self.mapping_node, self.shading_rotation
                )
                if self.background_node:
                    self.background_node.inputs[1].default_value = self.initial_strength
            else:
                self.shading.studiolight_rotate_z = self.shading_rotation
            
            context.space_data.draw_handler_remove(self._handle, 'WINDOW')
            context.area.tag_redraw()
            return {"FINISHED"}

        if event.value == "RELEASE":
            context.space_data.draw_handler_remove(self._handle, 'WINDOW')
            context.area.tag_redraw()
            return {"FINISHED"}

        return {"RUNNING_MODAL"}

    def invoke(self, context, event):
        self.shading = context.space_data.shading
        self.shading_type = self.get_shading_type(self.shading)
        world = context.scene.world
        # Initialize movement tracking
        self.movement_mode = 'NONE'
        self.initial_mouse_pos = (event.mouse_x, event.mouse_y)
        self.mapping_node = self.get_mapping_node(world)

        if self.shading_type:
            if self.shading_type == "SOLID":
                self.shading.use_world_space_lighting = True

                if context.space_data.shading.light == 'STUDIO':
                    self.shading_rotation = self.shading.studiolight_rotate_z
                else:
                    return {'CANCELLED'}

            elif (self.shading_type == "MATERIAL" and self.shading.use_scene_world)  or (self.shading_type == "RENDERED" and self.shading.use_scene_world_render):
                if not hasattr(context.scene.world, "node_tree"):
                    self.report({'WARNING'}, "No environment")
                    return {'CANCELLED'}

                if not self.mapping_node:
                    self.report({'WARNING'}, "Mapping node not found")
                    return {'CANCELLED'}
                self.set_shading_rotation(self.mapping_node)
            else:
                return {'CANCELLED'}

            self.event_key = context.window_manager.keyconfigs.user.keymaps["3D View Generic"].keymap_items[
                "speedsculpt.ibl_manipulate"].type
            
            self.background_node = self.get_background_node(world)
            if self.background_node:
                self.initial_strength = self.background_node.inputs[1].default_value
            self.mouse_pos_y = event.mouse_y

            self.mouse_pos_x = event.mouse_x
            context.window_manager.modal_handler_add(self)

            # Store initial values
            if self.background_node:
                self.strength_value = self.background_node.inputs[1].default_value
            self.rotation_value = self.shading_rotation

            # Add the drawing callback
            args = (self, context)
            self._handle = context.space_data.draw_handler_add(self.ibl_rotation_info, args, 'WINDOW', 'POST_PIXEL')

            return {'RUNNING_MODAL'}

        self.report({'WARNING'}, "Invalid shading type")
        return {"CANCELLED"}

CLASSES =  [SPEEDSCULPT_OT_draw_remesh,
            SPEEDSCULPT_OT_convert_annotations,
            SPEEDSCULPT_OT_draw_skin,
            SPEEDSCULPT_OT_draw_surface,
            SPEEDSCULPT_OT_ibl_manupilate,
            SPEEDSCULPT_OT_assets_on_surface,
            SPEEDSCULPT_OT_smooth_modal,
            SPEEDSCULPT_OT_scale
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)
