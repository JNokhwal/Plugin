# -*- coding:utf-8 -*-

# SPEEDSCULPT Add-on
# Copyright (C) 2018 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>


import os
import bpy
import bpy.utils.previews
from bpy.types import Operator, Menu, Panel, PropertyGroup, AddonPreferences, Scene, WindowManager, BlendData

speedsculpt_collection = {}

def speedsculpt_get_image_preview(aName, thumb_dir):
    """
    Find the corresponding image name of the asset
    :param aName: String, asset name
    :param thumb_dir: String, path of the thumbnail directory
    :return: String, name of the image corresponding to the asset
    """
    extensions = (".jpeg", ".jpg", ".png")

    thumbnails = [fn for fn in os.listdir(thumb_dir) if
                  fn.lower().endswith(extensions)]

    for img in thumbnails:
        if img.rsplit(".", 1)[0] != aName.rsplit(".", 1)[0]:
            continue
        return img
    return None

# Append
class SPEEDSCULPT_OT_assets_Add(Operator):
    bl_idname = "object.speedsculpt_assets_add"
    bl_label = "Add Assets"
    bl_description = "Append the selected Assets"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')
        wm = context.window_manager
        filepath = wm.speedsculpt_previews

        with bpy.data.libraries.load(filepath) as (data_from, data_to):
            data_to.objects = [name for name in data_from.objects]
        for obj in data_to.objects:
            context.collection.objects.link(obj)
            context.view_layer.objects.active = obj
            obj.select_set(True)

        return{'FINISHED'}

# Previews
def speedsculpt_generate_previews(self, context):
    speedsculpt = context.scene.speedsculpt

    icons_directory = os.path.join(speedsculpt.ui_categories, 'icons')
    files_directories = os.path.join(speedsculpt.ui_categories, 'files')

    pcoll = speedsculpt_collection["main"]
    if icons_directory == pcoll.images_location:
        return pcoll.speedsculpt_previews
    # Generate the thumbnails
    enum_items = []
    for i, assets in enumerate(sorted(os.listdir(files_directories))):
        assets_path = os.path.join(files_directories, assets)
        images_name = speedsculpt_get_image_preview(assets, icons_directory)
        image_path = os.path.join(icons_directory, images_name)
        icon = pcoll.get(images_name)
        if not icon:
            thumb = pcoll.load(images_name, image_path, 'IMAGE')
        else:
            thumb = pcoll[images_name]
        enum_items.append((assets_path, assets, "", thumb.icon_id, i))

    pcoll.speedsculpt_previews = enum_items
    pcoll.images_location = icons_directory
    context.window_manager['speedsculpt_previews'] = 0
    return enum_items



# -----------------------------------------------------
# REGISTER/UNREGISTER
# -----------------------------------------------------
CLASSES =  [SPEEDSCULPT_OT_assets_Add
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")


def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES:
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)


