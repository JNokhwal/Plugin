import bpy.types
from ..utils.pref_utils import get_keyops_prefs

def add_tablet_navigation():
    prefs = get_keyops_prefs()

    if prefs.maya_navigation_tablet_navigation:
        wm = bpy.context.window_manager
        km = wm.keyconfigs.active.keymaps['3D View']
        km.keymap_items.new('view3d.zoom', 'LEFTMOUSE', 'CLICK_DRAG', ctrl=True, alt=True)
        km.keymap_items.new('view3d.move', 'LEFTMOUSE', 'CLICK_DRAG', alt=True, shift=True)

def remove_tablet_navigation():
    wm = bpy.context.window_manager
    km = wm.keyconfigs.active.keymaps['3D View']
    items_to_remove = []
    for kmi in km.keymap_items:
        if kmi.idname == 'view3d.zoom':
            if kmi.ctrl and kmi.alt and kmi.type == 'LEFTMOUSE' and kmi.value == 'CLICK_DRAG':
                items_to_remove.append(kmi)
        if kmi.idname == 'view3d.move':
            if kmi.alt and kmi.shift and kmi.type == 'LEFTMOUSE' and kmi.value == 'CLICK_DRAG':
                items_to_remove.append(kmi)

    for kmi in items_to_remove:
        km.keymap_items.remove(kmi)

def update_tablet_navigation(self, context):
    if self.maya_navigation_tablet_navigation:
        add_tablet_navigation()
    else:
        remove_tablet_navigation()


class MayaNavigation(bpy.types.Operator):
    bl_idname = "keyops.maya_navigation"
    bl_label = "KeyOps: Maya Navigation"
    bl_options = {'INTERNAL'}

    def register():
        add_tablet_navigation()
        
    def unregister():
        remove_tablet_navigation()