# Based on the excellent Polycount Addon by Vinc3r
# https://github.com/Vinc3r/Polycount
# I used this addon a lot and really liked it, but I feelt it could be improved in terms of performance, ui and usability when working in big production scenes.
# Its now about 1000-5000x times faster than the original addon, it has a realtime mode by defualt and more streamlined ui along with some new features.
""""
TODO:
auto refresh option - DONE
fix category can't be set as defaults - DONE
dont refresh when just selecting an object in name mode - DONE
total poly count - DONE
Does not work correclty in edit modes, skips counting object if in edit mode - DONE
Cant select objects from list in edit mode - DONE

Show both selected objects and active object in list - DONE
Option to show by Collection in List Category - DONE
Option to Limit to a Collection or Collections - DONE
Show the object type icon in the list - DONE
Show poly count for instaced collections - DONE
Max UI length, if more than x objects - DONE
Smarter update, Only update on dependency graph change? Option - 
Update once every x ms? Option - 
Limit to only update the selected objects, keep the rest in global polycount cache, dont clear the list -
"""

import bpy
from bpy.types import PropertyGroup
from bpy.props import (EnumProperty, BoolProperty, StringProperty, PointerProperty, IntProperty)

polycount = []
polycount_sorting_ascending = True
polycount_sorting = 'TRIS'
ev = []
total_tris = 0

class PolyCountProperties(PropertyGroup):
    polycount_use_selection_only: BoolProperty(  # type: ignore
        name="Use selected only",
        description="Compute stats only for selected objects",
        default=False
    )
    auto_update_polycount: BoolProperty(  # type: ignore
        name="Auto Update",
        description="Auto update the list, might be slow in big scenes",
        default=True
    )
    filter_list_show: EnumProperty(  # type: ignore
        name="List Show",
        description="Show",
        items=[
            ('TRIS', "Tris", "Tris", 'MESH_DATA', 1),
            ('VERT', "Vert", "Vert", 'VERTEXSEL', 2),
            ('EDGE', "Edge", "Edge", 'EDGESEL', 4),
            ('FACE', "Face", "Face", 'FACESEL', 8)
        ],
        options={'ENUM_FLAG'},
        default={'TRIS', 'VERT', 'FACE'}
    )
    show_total_tris: BoolProperty(  # type: ignore
        name="Show Total Tris",
        description="Show Total Tris in the list",
        default=True
    )
    filter_by: EnumProperty(  # type: ignore
        name="Filter",
        description="Filter",
        items=[
            ('ALL', "All", "", 'NONE', 0),
            ('VISIBLE', "Visible", "", 'HIDE_OFF', 1),
            ('COLLECTION', "Collection", "", '', 2)
        ],
        default='ALL'
    )
    my_collection: PointerProperty(name="Collection",type=bpy.types.Collection)  # type: ignore

    round_numbers: BoolProperty(  # type: ignore
        name="Round Numbers",
        description="Round the numbers, slower, but more readable",
        default=True
    )
    show_only_enabled_collections: BoolProperty(  # type: ignore
        name="Show Only Enabled Collections",
        description="Show only enabled collections",
        default=True
    )
    show_collection_instances: BoolProperty(  # type: ignore
        name="Show Collection Instances",
        description="Show collection instances",
        default=False
    )
    show_obj_type: BoolProperty(  # type: ignore
        name="Show Object Type",
        description="Warning: Slow in big scenes, shows the icon of the object type",
        default=False
    )
    max_list_length: IntProperty(  # type: ignore
        name="Max List Length",
        description="Maximum number of objects to show in the list",
        default=500,
        min=1
    )

def deselect_all(context):
    for obj in context.scene.objects:
        if obj.select_get():
            obj.select_set(False)
        
def sortList(item):
    if polycount_sorting == 'NAME':
        return item[0].casefold()
    elif polycount_sorting == 'TRIS':
        return item[1]
    elif polycount_sorting == 'VERTS':
        return item[2]
    elif polycount_sorting == 'EDGES':
        return item[3]
    elif polycount_sorting == 'FACES':
        return item[4]
    else:
        return item[1]

def get_poly_count(context):
    selection = None
    global total_tris
    c = context
    props = c.scene.polycount_props

    if props.filter_by == 'ALL':
        if props.show_only_enabled_collections:
            filter_type = c.view_layer.objects
        else:
            filter_type = c.scene.objects
    if props.filter_by == 'VISIBLE':
        filter_type = c.visible_objects
    if props.filter_by == 'COLLECTION':
        if props.my_collection is None:
            filter_type = c.collection.objects
        else:
            filter_type = bpy.data.collections[props.my_collection.name].objects
    if props.polycount_use_selection_only:
        filter_type = c.selected_objects

    selection = [obj for obj in filter_type if obj.type in {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}]

    # import time
    # start = time.time()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    show_collection_instances = props.show_collection_instances
    # replace mesh cache with just global polycount cache
    mesh_cache = {}

    if not show_collection_instances:
        for obj in selection:
            eval_obj = obj.evaluated_get(depsgraph)
            m = eval_obj.to_mesh()
            if m is not None:
                tris = len(m.loop_triangles)
                verts = len(m.vertices)
                edges = len(m.edges)
                faces = len(m.polygons)
                total_tris += tris
                selected = obj.select_get()
                yield obj.name, tris, verts, edges, faces, selected
                
    else:
        for obj in selection:
            eval_obj = obj.evaluated_get(depsgraph)
            if obj.name not in mesh_cache:
                m = eval_obj.to_mesh()
                if m is not None:
                    mesh_cache[obj.name] = (len(m.loop_triangles), len(m.vertices), len(m.edges), len(m.polygons))
    
            if obj.name in mesh_cache:
                tris, verts, edges, faces = mesh_cache[obj.name]
                total_tris += tris
                selected = obj.select_get()
                yield obj.name, tris, verts, edges, faces, selected

        for obj in c.scene.objects:
            if obj.instance_type == 'COLLECTION' and obj.instance_collection:
                collection_instance_name = obj.name
                collection_tris = 0
                collection_verts = 0
                collection_edges = 0
                collection_faces = 0
                collection_selected = obj.select_get()

                for ob_col in obj.instance_collection.objects:
                    if ob_col.type in {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}:
                        eval_obj = ob_col.evaluated_get(depsgraph)
                        if ob_col.name not in mesh_cache:
                            m = eval_obj.to_mesh()
                            if m is not None:
                                mesh_cache[ob_col.name] = (len(m.loop_triangles), len(m.vertices), len(m.edges), len(m.polygons))
                                eval_obj.to_mesh_clear()
                        if ob_col.name in mesh_cache:
                            tris, verts, edges, faces = mesh_cache[ob_col.name]
                            collection_tris += tris
                            collection_verts += verts
                            collection_edges += edges
                            collection_faces += faces

                yield collection_instance_name, collection_tris, collection_verts, collection_edges, collection_faces, collection_selected
    # print(time.time() - start)  

    if polycount_sorting == 'NAME':
        name_ascending = not polycount_sorting_ascending
        polycount.sort(key=sortList, reverse=name_ascending)
    else:
        polycount.sort(key=sortList, reverse=polycount_sorting_ascending)

    total_tris = 0
    for obj in polycount:
        total_tris += obj[1]

    return {'FINISHED'}

class PolyCountList(bpy.types.Operator):
    bl_idname = "keyops.poly_count_list"
    bl_label = "Poly Count List"
    bl_description = "Refresh the polycount list, only needed if auto update is off"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global polycount
        polycount.clear()
        for ob in get_poly_count(context):
            polycount.append(ob)
        return {'FINISHED'}
    
    def register():
        bpy.utils.register_class(PolyCountProperties)
        bpy.types.Scene.polycount_props = PointerProperty(type=PolyCountProperties)

        bpy.utils.register_class(KEYOPS_PT_poly_count_list_panel)
        bpy.utils.register_class(POLYCOUNT_OT_refresh)
        bpy.utils.register_class(POLYCOUNTILST_PT_Settings)
        # bpy.utils.register_class(POLYCOUNT_PT_AutoUpdate_Settings)

    def unregister():
        bpy.utils.unregister_class(PolyCountProperties)
        del bpy.types.Scene.polycount_props

        bpy.utils.unregister_class(KEYOPS_PT_poly_count_list_panel)
        bpy.utils.unregister_class(POLYCOUNT_OT_refresh)
        bpy.utils.unregister_class(POLYCOUNTILST_PT_Settings)
        # bpy.utils.unregister_class(POLYCOUNT_PT_AutoUpdate_Settings)

class KEYOPS_PT_poly_count_list_panel(bpy.types.Panel):
    bl_label = "Polycount List"
    bl_idname = "KEYOPS_PT_poly_count_list_panel"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "scene"

    def draw(self, context):
        layout = self.layout
        global polycount_sorting_ascending
        global polycount_sorting
        global polycount
        global total_tris

        props = context.scene.polycount_props

        if props.auto_update_polycount:
            polycount.clear()
            for ob in get_poly_count(context):
                polycount.append(ob)

        if props.show_total_tris:
            row = layout.row(align=True)
            if props.round_numbers:
                row.label(text="Total Tris: {}".format(trim_numbers(total_tris)))
            else:
                row.label(text="Total Tris: " + "{:,}".format(total_tris))

        row = layout.row(align=True)
        if len(polycount) > 500 and props.auto_update_polycount:
            row.label(text="Warning: > 500 objects, might be slow with auto update", icon="ERROR")

        row = layout.row(align=True)
        row.prop(props, "auto_update_polycount", text="Auto", icon="FILE_REFRESH", toggle=False)
        # row.popover(panel="POLYCOUNT_PT_AutoUpdate_Settings", icon="PREFERENCES", text="")
        row.operator("keyops.poly_count_list", text="Refresh", icon="FILE_REFRESH")
        row.prop(props, "polycount_use_selection_only", text="Only selected", icon="RESTRICT_SELECT_OFF", toggle=False)
        row.popover(panel="POLYCOUNTILST_PT_Settings", icon="FILTER", text="")

        col_flow = layout.column_flow(columns=0, align=True)
        row = col_flow.row(align=True)

        if polycount_sorting == 'NAME':
            if polycount_sorting_ascending:
                row.operator("keyops.polycount_user_interaction", text="Object", icon="TRIA_DOWN").poly_sort = 'NAME'
            else:
                row.operator("keyops.polycount_user_interaction", text="Object", icon="TRIA_UP").poly_sort = 'NAME'
        else:
            row.operator("keyops.polycount_user_interaction", text="Object").poly_sort = 'NAME'

        if 'TRIS' in props.filter_list_show:
            if polycount_sorting == 'TRIS':
                if polycount_sorting_ascending:
                    row.operator("keyops.polycount_user_interaction", text="Tris", icon="TRIA_DOWN").poly_sort = 'TRIS'
                else:
                    row.operator("keyops.polycount_user_interaction", text="Tris", icon="TRIA_UP").poly_sort = 'TRIS'
            else:
                row.operator("keyops.polycount_user_interaction", text="Tris").poly_sort = 'TRIS'

        if 'VERT' in props.filter_list_show:
            if polycount_sorting == 'VERTS':
                if polycount_sorting_ascending:
                    row.operator("keyops.polycount_user_interaction", text="Verts", icon="TRIA_DOWN").poly_sort = 'VERTS'
                else:
                    row.operator("keyops.polycount_user_interaction", text="Verts", icon="TRIA_UP").poly_sort = 'VERTS'
            else:
                row.operator("keyops.polycount_user_interaction", text="Verts").poly_sort = 'VERTS'

        if 'EDGE' in props.filter_list_show:
            if polycount_sorting == 'EDGES':
                if polycount_sorting_ascending:
                    row.operator("keyops.polycount_user_interaction", text="Edges", icon="TRIA_DOWN").poly_sort = 'EDGES'
                else:
                    row.operator("keyops.polycount_user_interaction", text="Edges", icon="TRIA_UP").poly_sort = 'EDGES'
            else:
                row.operator("keyops.polycount_user_interaction", text="Edges").poly_sort = 'EDGES'

        if 'FACE' in props.filter_list_show:
            if polycount_sorting == 'FACE':
                if polycount_sorting_ascending:
                    row.operator("keyops.polycount_user_interaction", text="Face", icon="TRIA_DOWN").poly_sort = 'FACE'
                else:
                    row.operator("keyops.polycount_user_interaction", text="Face", icon="TRIA_UP").poly_sort = 'FACE'
            else:
                row.operator("keyops.polycount_user_interaction", text="Face").poly_sort = 'FACE'
        # import time
        # start = time.time()
        if len(polycount) > 0:
            filter_list_show = props.filter_list_show
            round_numbers = props.round_numbers
            show_collection_instances = props.show_collection_instances
            show_obj_type = props.show_obj_type

            max_list_length = props.max_list_length
            for i, obj in enumerate(polycount):
                if i >= max_list_length:
                    break

                row = col_flow.row(align=True)
                selected = obj[5]

                if show_obj_type:
                    obj_name = obj[0]
                    obj_data = bpy.data.objects.get(obj_name)
                    object_type = obj_data.type if obj_data else 'OBJECT'
                    
                    # Check if the object is an instanced collection
                    if show_collection_instances and obj_data.instance_type == 'COLLECTION':
                        icon = 'OUTLINER_COLLECTION'
                    else:
                        icon = 'OUTLINER_OB_' + object_type if object_type in {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META', 'ARMATURE', 'CAMERA', 'LIGHT', 'LATTICE', 'EMPTY', 'SPEAKER', 'LIGHT_PROBE'} else 'OBJECT_DATAMODE'
        
                    row.operator("keyops.polycount_user_interaction", text=str(obj_name), icon=icon, depress=selected).make_active = obj_name
                else:
                    row.operator("keyops.polycount_user_interaction", text=str(obj[0]), depress=selected).make_active = obj[0]

                if 'TRIS' in filter_list_show:
                    tris_number = trim_numbers(obj[1]) if round_numbers else str("{:,.0f}".format(obj[1]))
                    row.label(text=tris_number)
                if 'VERT' in filter_list_show:
                    verts_number = trim_numbers(obj[2]) if round_numbers else str("{:,.0f}".format(obj[2]))
                    row.label(text=verts_number)
                if 'EDGE' in filter_list_show:
                    edge_number = trim_numbers(obj[3]) if round_numbers else str("{:,.0f}".format(obj[3]))
                    row.label(text=edge_number)
                if 'FACE' in filter_list_show:
                    faces_number = trim_numbers(obj[4]) if round_numbers else str("{:,.0f}".format(obj[4]))
                    row.label(text=faces_number)
                
                #add reached max list length warning
                if i == max_list_length - 1:
                    row = col_flow.row(align=True)
                    row.alignment = 'LEFT'
                    row.label(text="Max List Length Reached", icon="QUESTION")
                    row.prop(props, "max_list_length", text="Current:")
            # print(time.time() - start)

class POLYCOUNTILST_PT_Settings(bpy.types.Panel):
    bl_label = "Polycount Settings"
    bl_idname = "POLYCOUNTILST_PT_Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.polycount_props

        row = layout.row()
        row.label(text="Filter by:")
        row = layout.row(align=True)
        row.prop(props, "filter_list_show", text="Show")

        row = layout.row()
        row.label(text="Show:")
        row = layout.row()
        row.alignment = 'LEFT'
        row.prop(props, "show_total_tris", text="Total Tris")
        row.prop(props, "round_numbers", text="Round Numbers")
        row = layout.row()
        row.alignment = 'LEFT'
        row.prop(props, "show_obj_type", text="Object Type")
        row = layout.row()
        row.label(text="Max List Length:")
        row.prop(props, "max_list_length", text="")
        row = layout.row()
        row.label(text="Filter Objects by:")
        row = layout.row()
        row.prop(props, "filter_by", text="Object Visible", expand=True)

        if props.filter_by == 'ALL':
            row = layout.row()
            row.prop(props, "show_only_enabled_collections", text="Show Only Enabled Collections")

        if props.filter_by == 'VISIBLE':
            row = layout.row()
            row.label(text="Only Visible Objects are Now Shown")

        if props.filter_by == 'COLLECTION':
            row = layout.row()
            row.prop(props, "my_collection", text="Custom")
            row = layout.row()
            row.prop(props, "show_collection_instances", text="Include Collection Instances")

class POLYCOUNT_PT_AutoUpdate_Settings(bpy.types.Panel):
    bl_label = "Auto Update Settings"
    bl_idname = "POLYCOUNT_PT_AutoUpdate_Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.polycount_props

        row = layout.row()
        row.label(text="Auto Update Settings:")
        row = layout.row()
        row.prop(props, "auto_update_polycount", text="Auto Update")

class POLYCOUNT_OT_refresh(bpy.types.Operator):
    bl_idname = "keyops.polycount_user_interaction"
    bl_label = "Show polycount in Scene properties panel"
    bl_description = "Object Name"
    make_active: StringProperty(default="") # type: ignore
    poly_sort: EnumProperty(
        items=[
            ('NAME', "Name", ""),
            ('VERTS', "Verts", ""),
            ('EDGES', "Edges", ""),
            ('FACE', "Faces", ""),
            ('TRIS', "Tris", "")
        ], default='TRIS'
    ) # type: ignore
    refresh: BoolProperty(default=False) # type: ignore

    @classmethod
    def poll(cls, context):
        return len(context.view_layer.objects) > 0
    def invoke(self, context, event):
        global ev
        ev = []
        if event.shift:
            ev.append("Shift")
        if event.ctrl:
            ev.append("Ctrl")
        ev.append("Click")
        return self.execute(context)

    def execute(self, context):
        global polycount_sorting_ascending
        global polycount_sorting

        if self.refresh:
            self.refresh = False
            pass
        else:
            if self.make_active != "" and bpy.data.objects.get(str(self.make_active)) is not None:
                if context.mode == 'OBJECT':
                    if ev == ["Shift", "Click"]:
                        context.view_layer.objects.active = bpy.data.objects[str(self.make_active)]
                        context.view_layer.objects.active.select_set(True)
                    elif "Ctrl" in ev:
                        obj = bpy.data.objects[str(self.make_active)]
                        obj.select_set(not obj.select_get())
                    else:
                        deselect_all(context)
                        context.view_layer.objects.active = bpy.data.objects[str(self.make_active)]
                        context.view_layer.objects.active.select_set(True)
                else:
                    self.report({'WARNING'}, "Object not in an enabled collection or view layer")
            else:
                if self.poly_sort == polycount_sorting:
                    polycount_sorting_ascending = not polycount_sorting_ascending
                else:
                    polycount_sorting = self.poly_sort
            self.make_active = ""

        if polycount_sorting == 'NAME':
            name_ascending = not polycount_sorting_ascending
            polycount.sort(key=sortList, reverse=name_ascending)
        else:
            polycount.sort(key=sortList, reverse=polycount_sorting_ascending)

        return {'FINISHED'}

def trim_numbers(number):
    if number < 1000:
        return str(number)
    elif number < 1000000:
        return "{:,.2f}k".format(round(number / 1000, 2)).replace(",", " ")
    else:
        return "{:,.2f}m".format(round(number / 1000000, 2)).replace(",", " ")

