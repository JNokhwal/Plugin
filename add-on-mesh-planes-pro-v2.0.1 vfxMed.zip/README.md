What is Mesh Planes Pro?
The ultimate tool for seamless background removal and faster render times (up to 200%)! 🚀✨

Mesh Planes Pro Animation
Mesh Planes Pro eliminates the need for manual editing in Photoshop or other tools. With just a few clicks, it makes transparent backgrounds from various file types like JPGs, meaning no more hassle with fake PNGs! 🙌🎨

Background Removal
What's Inside?
🔹 Mesh Planes Lite:
Only works with black and white backgrounds—just what you need for basic tasks. Super simple to use!

Mesh Planes Lite Demo
🔸 Mesh Planes Core:
Expands Core’s functionality by handling colored backgrounds with ease! Perfect for quick workflows.

Mesh Planes Core Demo
🔥 Mesh Planes Pro:
Go all-in with full control over your images and shaders! Adjust Roughness, Normal, Fake Normals, Emission, and even HDR Emission (experimental) for ultimate flexibility. 🌟🎛️

Mesh Planes Pro Demo
🚀 Getting Started

Download the .zip file containing the addon.
Open Blender and navigate to:
Edit > Preferences > Add-ons > Install.
Locate the .zip file and click Install.
Activate the addon by ticking the checkbox next to it.
Press CTRL + A and select Import > Mesh Plane.
Select the plane, then Right-Click to open the Object Context Menu.
Choose Mesh Plane (_____) and voilà! 🎉
Go to the Shader Editor and adjust the sliders according to your image needs.
For PNGs with alpha channels, enable the "Turn on Alpha" option to use the built-in transparency.
🟠 Node Setup
Image - Connect the image texture to this node.
Alpha - Connect the alpha channel if available.
Turn on Alpha - Activate this node if the image already contains transparency.
🟢 Mask Settings
Color or Black & White Background
Unchecked for Color background.
Checked for Black & White background.
Invert (Input Image) - Flips the colors of the input image.
Invert (Mask Mode) - Highlights the masked area for easy identification.
Color Black Slider - Fine-tune the dark regions of the image.
Color White Slider - Fine-tune the bright regions of the image.
🔵 BSDF Settings
Mix Color Factor - Adjust how much the color slider influences the image.
Change Color - Modify the hue of your image.
Roughness - Control the surface roughness.
Metallic - Add metallic sheen to the surface.
🟣 Normal Settings
Normal - Plug in an existing normal map or generate a new one.
Fake Normals - Generate fake normals based on the image texture.
Normal Finetune - Adjust the strength and detail of the fake normals.
Bump Strength - Increase or decrease the bumpiness of the surface.
Invert Normal - Flip the direction of the normals for specific effects.
🔴 Emission Settings
Emission Strength - Control the brightness of the emission.
Turn on HDR - Enable the experimental HDR feature.
HDR Emission Strength - Fine-tune the HDR intensity.
Dark Values - Adjust how bright the dark areas should emit light.
Bright Values - Control the brightness of the lighter regions.


Nodes	Light	Core	Pro
Image	✅	✅	✅
Alpha	✅	✅	✅
Turn on Alpha	✅	✅	✅
Mask Settings			
Color or BW Background	❌	✅	✅
Invert (Input Image)	❌	✅	✅
Invert (Mask Mode)	✅	✅	✅
Color Black Slider	❌	✅	✅
Color White Slider	❌	✅	✅
BW Black Slider	✅	✅	✅
BW White Slider	✅	✅	✅
BSDF Settings			
Mix Color Factor	❌	❌	✅
Change Color	❌	❌	✅
Roughness	❌	❌	✅
Metallic	❌	❌	✅
Normal Settings			
Normal	❌	❌	✅
Fake Normals	❌	❌	✅
Normal Finetune	❌	❌	✅
Bump Strength	❌	❌	✅
Invert Normal	❌	❌	✅
Emission Settings			
Emission Strength	❌	❌	✅
Turn on HDR	❌	❌	✅
HDR Emission Strength	❌	❌	✅
HDR Finetune	❌	❌	✅
Dark Values	❌	❌	✅
Bright Values	❌	❌	✅


Questions?

Feel free to reach out through the "Ask a Question" button on Blender Market or shoot an email to ogprinceeagle@gmail.com ! 💬




INSTRUCTIONS:
🚀 Getting Started
Press CTRL + A and select Import > Mesh Plane.
Select the plane, then Right-Click to open the Object Context Menu.
Choose Mesh Plane (_____) and voilà! 🎉
Go to the Shader Editor and adjust the sliders according to your image needs.
For PNGs with alpha channels, enable the "Turn on Alpha" option to use the built-in transparency.
🟠 Node Setup
Image - Connect the image texture to this node.
Alpha - Connect the alpha channel if available.
Turn on Alpha - Activate this node if the image already contains transparency.
🟢 Mask Settings
Color or Black & White Background
Unchecked for Color background.
Checked for Black & White background.
Invert (Input Image) - Flips the colors of the input image.
Invert (Mask Mode) - Highlights the masked area for easy identification.
Color Black Slider - Fine-tune the dark regions of the image.
Color White Slider - Fine-tune the bright regions of the image.
🔵 BSDF Settings
Mix Color Factor - Adjust how much the color slider influences the image.
Change Color - Modify the hue of your image.
Roughness - Control the surface roughness.
Metallic - Add metallic sheen to the surface.
🟣 Normal Settings
Normal - Plug in an existing normal map or generate a new one.
Fake Normals - Generate fake normals based on the image texture.
Normal Finetune - Adjust the strength and detail of the fake normals.
Bump Strength - Increase or decrease the bumpiness of the surface.
Invert Normal - Flip the direction of the normals for specific effects.
🔴 Emission Settings
Emission Strength - Control the brightness of the emission.
Turn on HDR - Enable the experimental HDR feature.
HDR Emission Strength - Fine-tune the HDR intensity.
Dark Values - Adjust how bright the dark areas should emit light.
Bright Values - Control the brightness of the lighter regions.