import bpy
import os

# Function to load the node group from the .blend file
def load_node_group(blend_file, group_name):
    blend_file_path = os.path.join(os.path.dirname(__file__), blend_file)
    
    with bpy.data.libraries.load(blend_file_path, link=False) as (data_from, data_to):
        if group_name in data_from.node_groups:
            data_to.node_groups = [group_name]
    
    return bpy.data.node_groups.get(group_name)

# Function to change the material of the object
def change_material(obj, node_group):
    mat = obj.active_material

    if not mat:
        print("No active material found.")
        return

    for node in list(mat.node_tree.nodes):
        if node.name not in {"Image Texture", "Material Output"}:
            mat.node_tree.nodes.remove(node)

    img_node = mat.node_tree.nodes.get("Image Texture")

    if img_node:
        node_group_node = mat.node_tree.nodes.new('ShaderNodeGroup')
        node_group_node.node_tree = node_group
        node_group_node.location = (0, 0)

        mat.node_tree.links.new(img_node.outputs["Color"], node_group_node.inputs[0])

        if "Alpha" in img_node.outputs:
            mat.node_tree.links.new(img_node.outputs["Alpha"], node_group_node.inputs[1])

        material_output = mat.node_tree.nodes.get("Material Output")
        if material_output:
            mat.node_tree.links.new(node_group_node.outputs[0], material_output.inputs["Surface"])
        else:
            print("Material Output node not found.")
    else:
        print("No existing Image Texture node found.")

# Define the operator
class OBJECT_OT_my_operator(bpy.types.Operator):
    bl_idname = "object.my_operator"
    bl_label = "Mesh Planes Pro"

    def execute(self, context):
        obj = context.object

        blend_file = "Mesh_Plane_Pro.blend"
        node_group = load_node_group(blend_file, "Mesh Plane Pro")

        if node_group:
            change_material(obj, node_group)
        else:
            self.report({'ERROR'}, "Node group not found in the blend file.")
        
        return {'FINISHED'}

# Define the menu item
def menu_func(self, context):
    self.layout.operator(OBJECT_OT_my_operator.bl_idname)

def register():
    bpy.utils.register_class(OBJECT_OT_my_operator)
    bpy.types.VIEW3D_MT_object_context_menu.append(menu_func)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_my_operator)
    bpy.types.VIEW3D_MT_object_context_menu.remove(menu_func)

if __name__ == "__main__":
    register()
