If install add-on, ex: RetopoFlow, but after enabling change the name, ex: retopoflow, Blender's startup crashes and does not start up add-on

Traceback (most recent call last):
  File "/home/jon/software/blender-2.82a/2.82/scripts/modules/addon_utils.py", line 351, in enable
    mod = __import__(module_name)
ModuleNotFoundError: No module named 'RetopoFlow'
