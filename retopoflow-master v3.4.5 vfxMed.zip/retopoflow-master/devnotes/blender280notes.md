# Blender 2.80 Notes


[Blender 2.80 Python API Changes](https://wiki.blender.org/wiki/Reference/Release_Notes/2.80/Python_API)

[GPU Shader Module](https://docs.blender.org/api/blender2.8/gpu.html)

[GPU Types](https://docs.blender.org/api/blender2.8/gpu.types.html)

[Updating Scripts from 2.7x](https://en.blender.org/index.php/Dev:2.8/Source/Python/UpdatingScripts)

[UI Design](https://wiki.blender.org/wiki/Reference/Release_Notes/2.80/Python_API/UI_DESIGN)

[Update Addons with both Blender 2.8 and 2.7 Supoport | Moo-Ack!](https://theduckcow.com/2019/update-addons-both-blender-28-and-27-support/)